import React from "react";
import { MyHomePage } from "./VaheShop";
import "./index.css"

function App() {
  return (
   <>
   <MyHomePage />
    
   </>
  );
}

export default App;
