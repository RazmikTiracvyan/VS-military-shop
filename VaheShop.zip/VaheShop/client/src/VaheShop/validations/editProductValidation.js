import * as yup from 'yup';

export const yupResolver = (validationSchema) => async (values) => {
    try {
        await validationSchema.validate(values, { abortEarly: false });
        return {
            values,
            errors: {},
        };
    } catch (errors) {
        const yupErrors = {};
        errors.inner.forEach((error) => {
            yupErrors[error.path] = error.message;
        });
        return {
            values: {},
            errors: yupErrors,
        };
    }
};

export const useValidation = () => {
    return yup.object().shape({
        title: yup.string().required('Заполните поле title!'),
        price: yup.string().required('Заполните поле price!'),
        description: yup.string().required('Заполните поле description!'),
        img: yup
            .mixed()
            .test('fileSize', 'Файл слишком большой (макс. 10мб)', (value) => {
                if (!value || value.length === 0) return true; // Allow if file is not selected
                const fileSizeLimit = 10 * 1024 * 1024; // 5 MB
                return value[0].size <= fileSizeLimit;
            }),
    });
};