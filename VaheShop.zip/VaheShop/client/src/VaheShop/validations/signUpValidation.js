import * as yup from 'yup';

export const yupResolver = (validationSchema) => async (values) => {
    try {
        await validationSchema.validate(values, { abortEarly: false });
        return {
            values,
            errors: {},
        };
    } catch (errors) {
        const yupErrors = {};
        errors.inner.forEach((error) => {
            yupErrors[error.path] = error.message;
        });
        return {
            values: {},
            errors: yupErrors,
        };
    }
};

export const useValidation = () => {
    return yup.object().shape({
        name: yup.string().required('Заполните поле!'),
        lastName: yup.string().required('Заполните поле!'),
        email: yup.string().required('Заполните поле!')
        .email('Неправильная почта'),
        password: yup.string()
        .min(8, 'Пароль должен состоять от 8 до 16 букв')
        .max(16, 'Пароль должен состоять от 8 до 16 букв'),
        ageCheck: yup.boolean().oneOf([true], 'Обязательно для выбора'),
        privacyCheck: yup.boolean().oneOf([true], 'Обязательно для выбора'),
    });
};
