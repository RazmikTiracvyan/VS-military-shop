import * as yup from 'yup';
import { useTranslation } from 'react-i18next'
export const yupResolver = (validationSchema) => async (values) => {
    try {
        await validationSchema.validate(values, { abortEarly: false });
        return {
            values,
            errors: {},
        };
    } catch (errors) {
        const yupErrors = {};
        errors.inner.forEach((error) => {
            yupErrors[error.path] = error.message;
        });
        return {
            values: {},
            errors: yupErrors,
        };
    }
};

export const useValidation = () => {
const { t } = useTranslation()

    return yup.object().shape({
        email: yup.string().required(t("Заполните поле!")),
        password: yup.string()
        .min(8, 'Пароль должен состоять от 8 до 16 букв')
        .max(16, 'Пароль должен состоять от 8 до 16 букв'),
    });
};