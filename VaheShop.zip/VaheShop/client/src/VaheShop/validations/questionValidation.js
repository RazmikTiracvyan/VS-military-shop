import * as yup from 'yup';

export const yupResolver = (validationSchema) => async (values) => {
    try {
        await validationSchema.validate(values, { abortEarly: false });
        return {
            values,
            errors: {},
        };
    } catch (errors) {
        const yupErrors = {};
        errors.inner.forEach((error) => {
            yupErrors[error.path] = error.message;
        });
        return {
            values: {},
            errors: yupErrors,
        };
    }
};


export const useValidation = () => {
    return yup.object().shape({
        name: yup.string().required('Заполните поле!'),
        textarea: yup.string().required('Заполните поле!'),

        email: yup.string().required('Заполните поле!')
            .email('Неправильная почта'),
        

    });
};