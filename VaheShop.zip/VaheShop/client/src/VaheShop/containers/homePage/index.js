import React from "react"
import {
    HomeForm,
    Mec
} from "./styled"

import { Product } from "../productPage/index"
import Carousel from "../../components/carousel"
import Client from "../../components/Clients/Clients"
import { Basket } from "../../components/basket"
import { Chapter, Footer, Header, HistorProducts } from "../../components"
import { UserPage } from "../profile"


export const HomePage = () => {
    return (
        <>
            <HomeForm>
                <Carousel />
            </HomeForm>
            <Chapter />
            <Product />
            <Basket />
        </>
    )
}