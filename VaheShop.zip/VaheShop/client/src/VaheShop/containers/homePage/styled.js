import styled from "styled-components"

export const HomeForm = styled.div`
	height:auto;
	width:100%;
	
`


export const Mec = styled.div`
width: 100%;
color: white;
background-color: #191923;
`