import styled from "styled-components"

export const ContactMap = styled.iframe`
    width:100%;
    height:600px;
    margin-top:50px;
    

`
export const ContactDiv = styled.div`
    margin-top:20px;
    width:100%;
    height:500px;
    justify-content:space-around;
    display:flex;
    @media(max-width:726px){
        display:inline;
    }
`

export const ContactInfoDiv = styled.div`
    width:45%;
    height:100%;
    @media(max-width:726px){
        width:100%;
    }
`

export const ContactTitle = styled.h4`
    padding-top:20px;
    padding-left:20px;
    @media(max-width:302px){
        font-size:13px;

    }
`

export const ContactInfo = styled.p`
    padding-top:50px;
    padding-left:20px;
    @media(max-width:528px){
        font-size:12px;
        padding-left:5px;

    }
    @media(max-width:378px){
        font-size:8px;

    }
`

export const ContactLink = styled.a`
    cursor:pointer
`

export const ContactIcon = styled.div`
    width:100%;
    height:50px;
    margin-left:20px;
`



export const ContactImg = styled.img`
    margin-left:5px;
    cursor:pointer;
    transition:0.2s;
    &:hover{
        transform:scale(1.2);
    }


    @media(max-width:343px){
        width:40px;
    };
    @media(max-width:300px){
        width:30px;
        margin-left:2px;
    };
  
`
    

export const FooterContact = styled.div`
    width:100%;
    height:80px;
    display:flex;
    justify-content:space-around;
    @media(max-width:943px){
        display:inline;
    };
  
    
`
export const FooterDiv = styled.div`
    width:40%;
    height:80px;
    @media(max-width:943px){
        width:100%;
    }
    @media(max-width:315px){
        height:120px;
    }
    @media(max-width:726px){
        margin-top:100px;
    }
    
`

export const FooterTitle = styled.span`
    font-weight: bold;   
    margin-left:20px;
`




export const EmailInput = styled.input`
    height:40px;
    width:250px;
    border:none;
    outline:none;
    background-color: #e5e3e3;
    margin-top:10px;
    padding-left:5px;
    border-top-right-radius:0;
    border-bottom-right-radius:0;
     @media(max-width:943px){
        width:60%;
    }
    @media(max-width:726px){
        width:65%;
        border-radius:0;
        margin-left:20px;

    }

`

export const EmailButton = styled.button`
    width: 125px;
    height: 40px;
    border-radius:50px;
    transition: 0.5s;
    background-color:#5cb85c;
    border:none;
    color:white;
    border-top-left-radius:0;
    border-bottom-left-radius:0;
    &:hover{
    opacity:0.8;
    };
    @media(max-width:726px){
        width:27%;
        border-radius:0;
    }

`


export const ShareButtonFb = styled.button`
    height:30px;
    width:100px;
    background-color:#1560bd;
    color:white;
    text-align:center;
    border:none;
    border-radius:10px;

        transition:0.2s;
    &:hover{
        transform:scale(1.05);
    }
    @media(max-width:726px){
        margin-left:20px;
    }
    @media(max-width:334px){
    height:30px;
    width:80px;
    margin-left:5px;
    }

`
export const ShareButtonVk = styled.button`
    height:30px;
    width:100px;
    background-color:#6287ae;
    color:white;
    text-align:center;
    margin-top:10px;
    border:none;
    border-radius:10px;
    margin-left:5px;
        transition:0.2s;
    &:hover{
        transform:scale(1.05);
    }
    @media(max-width:334px){
    height:30px;
    width:80px;
    }
    
`

export const ShareButtonInst = styled.button`
    height:30px;
    width:100px;
    margin-left:5px;
    background: #f09433; 
    background: -moz-linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); 
    background: -webkit-linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); 
    background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); 
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f09433', endColorstr='#bc1888',GradientType=1 );
    color:white;
    text-align:center;
    border:none;
    border-radius:10px;
        transition:0.2s;
    &:hover{
        transform:scale(1.05);
    }
    @media(max-width:334px){
    height:30px;
    width:80px;
    }

   
`
export const BottomIcon = styled.span`
    
`