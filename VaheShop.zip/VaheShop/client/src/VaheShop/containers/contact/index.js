import React from 'react'
import {
    ContactMapDiv,
    ContactMap,
    ContactDiv,
    ContactInfoDiv,
    ContactTitle,
    ContactInfo,
    ContactLink,
    FooterContact,
    FooterDiv,
    FooterTitle,
    ShareButtonFb,
    BottomIcon,
    ContactIcon,
    ContactImg,
    ShareButtonVk,
    ShareButtonInst
} from './styled'
import { useTranslation } from 'react-i18next'

import fb from "../../img/socSeti/fb.png"
import tw from "../../img/socSeti/tw.png"
import inst from "../../img/socSeti/inst.png"
import yt from "../../img/socSeti/yt.png"
import lDin from "../../img/socSeti/in.png"
import google from "../../img/socSeti/google.png"
import { QuestionCntact, InputEmail } from "../../components/questionContact/"
import { BsFacebook } from "react-icons/bs"
import { SlSocialVkontakte } from "react-icons/sl"
import { BsInstagram } from "react-icons/bs"
import { Basket } from '../../components/basket'
import { Footer, Header } from '../../components'



export const Contact = () => {
    const { t } = useTranslation()
     return (
        <>
            <ContactDiv>
                <ContactInfoDiv>
                    <ContactTitle>{t("Address")}</ContactTitle>
                    <ContactInfo>{t("aAm")}<br /><br />
                        {t("aCall")} <ContactLink>+37493409047</ContactLink> , <ContactLink>+37498420244</ContactLink> <br />
                        {t("aMail")} <ContactLink>vaheshmavonyan@mail.ru</ContactLink>
                    </ContactInfo>
                    <ContactTitle>{t("aInt")}</ContactTitle>
                    <ContactIcon>
                        <a><ContactImg src={fb} /></a>
                        <a><ContactImg src={tw} /></a>
                        <a><ContactImg src={inst} /></a>
                        <a><ContactImg src={yt} /></a>
                        <a><ContactImg src={lDin} /></a>
                        <a><ContactImg src={google} /></a>
                    </ContactIcon>
                </ContactInfoDiv>

                <ContactInfoDiv>
                    <ContactTitle>{t("Question")}</ContactTitle>
                    <QuestionCntact />
                </ContactInfoDiv>
            </ContactDiv>
            <FooterContact>
                <InputEmail />
                <FooterDiv>
                    <FooterTitle>{t("share")}</FooterTitle><br />

                    <ShareButtonFb><BsFacebook /> Share</ShareButtonFb>
                    <ShareButtonVk>
                        <BottomIcon><SlSocialVkontakte />    Share
                        </BottomIcon>

                    </ShareButtonVk>
                    <ShareButtonInst>
                        <BsInstagram /> Share
                    </ShareButtonInst>

                </FooterDiv>
            </FooterContact>
            <ContactMap src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d48784.58647243744!2d44.30233599999999!3d40.1637376!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2sam!4v1696846325693!5m2!1sru!2sam" width="600" height="450" $allowfullscreen="" loading="lazy" $referrerpolicy="no-referrer-when-downgrade" />
        <Basket />
        </>
    )
}