import React, { useState, useEffect } from "react"
import { EmailInput, EmailInputDiv, ForgetButton, ForgetpasswordDiv, ForgetpasswordForm, IconDiv, InfoDiv, TimerSpan } from "./styled"
import { toast } from "react-toastify";
import { HiMiniPencilSquare } from "react-icons/hi2";
import { useLocation, useNavigate } from 'react-router-dom';
import { Footer, Header } from "../../components";

export const ForgetpasswordCode = () => {
    const [value, setValue] = useState("")
    const [password, setPassword] = useState(null)
    const [isButtonDisabled, setIsButtonDisabled] = useState(false);
    const [timer, setTimer] = useState(
        parseInt(localStorage.getItem('timer')) || 100
    );
    const location = useLocation();
    const navigate = useNavigate()

    const email = location.state || null;
    useEffect(() => {
        if(!email){
            navigate('/')
        }
    })
    const sendCode = async () => {
        if (value.length == 0) {
            return toast.warning('Запаолните поле')
        }
        try {
            const req = await fetch('http://localhost:3002/reset-password', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ email: email, code: value, password: password ? password : null })
            })

            if (req.status == 400) {
                return toast.warning('Неправильный код восстановления или код истек')
            }
            if (req.ok) {
                toast.success('Введите ваш новый пароль')
                startTimer();
                navigate('/forgetpassword/newpassword', { state: { email: email, code: value } })
            }
        }
        catch (err) {
            toast.error('Пользователь не найден')
            console.log(err);
        }

    }
    let interval;
    const startTimer = () => {
        setIsButtonDisabled(false);

        interval = setInterval(() => {
            setTimer(prevTimer => {
                if (prevTimer <= 1) {
                    clearInterval(interval);
                    localStorage.removeItem("timer")
                    setIsButtonDisabled(true);
                    return 0;
                }
                return prevTimer - 1;
            });
        }, 1000);
    };
    useEffect(() => {
        startTimer()
        localStorage.setItem('timer', timer.toString());

        return () => clearInterval(interval);
    }, [timer]);


    const sendCodeAgein = async () => {

        try {
            const req = await fetch('http://localhost:3002/forgot-password', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ email: email })
            })

            if (req.status == 404) {
                return toast.warning('Почта не зарегистрирована')
            }
            if (req.ok) {
                toast.success('Код восстановления отправлен на вашу почту')
                setIsButtonDisabled(false)
                setTimer(100)
                startTimer()

            }
        }
        catch (err) {
            toast.error('Пользователь не найден')
            console.log(err);
        }

    }
    return (
        <>
            <ForgetpasswordDiv>
                <ForgetpasswordForm>
                    <InfoDiv>
                        <span>Enter you email</span>
                    </InfoDiv>
                    <EmailInputDiv>
                        <EmailInput disabled placeholder="email" value={email} />
                        <IconDiv onClick={(() => navigate('/forgetpassword'))}>
                            <HiMiniPencilSquare />
                        </IconDiv>
                    </EmailInputDiv>
                    <EmailInput onChange={(e) => setValue(e.target.value)} />
                    <ForgetButton onClick={sendCode}>Send code</ForgetButton>
                    <br />{isButtonDisabled ? <TimerSpan onClick={sendCodeAgein} style={{ color: 'blue', cursor: 'pointer' }}>Отправить код повтороно</TimerSpan>
                        :
                        <TimerSpan>Подождите {timer} секунд перед следующей попыткой</TimerSpan>
                    }
                </ForgetpasswordForm>
            </ForgetpasswordDiv>
        </>
    )
}