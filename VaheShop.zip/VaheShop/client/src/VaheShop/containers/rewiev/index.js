import React, { useState, useEffect, useMemo } from "react";
import { AddReview, AddReviewButton, BGCdiv, RamkaDiv, ReviewButton, ReviewInput, ReviewTextarea, RewievPageDiv, Star, StarDiv, StarSpan, TitleReviews } from "./styled";
import { FaStar } from "react-icons/fa";
import { v4 as uuidv4 } from 'uuid';
import Client from "../../components/Clients/Clients"
import { toast } from "react-toastify";
import { Slide } from 'react-awesome-reveal';
import { useTranslation } from 'react-i18next'
import { Basket } from "../../components/basket";

export const MyRewievPage = React.memo(() => {
  const { t } = useTranslation()
  const [openReviews, setOpenReviews] = useState(false);
  const [stars, setStars] = useState(0);
  const [user, setUser] = useState()
  const [text, setText] = useState({
    disc: '',
    position: '',
    stars: '',
    id: '',
  });

  const arr = [1, 2, 3, 4, 5];

  const myOnChange = (e) => {
    const { name, value } = e.target;
    setText((prev) => {
      return { ...prev, [name]: value };
    });
  };



  const addRewiev = async () => {
    try {
      if (!token) {
        return toast.error("Вы не вошли в ваш аккаунт или не зарегистрированы");
      }

      text.stars = stars;
      text.name = user.name;
      text.lastName = user.lastName;
      text.id = user._id

      if (stars === 0) {
        return toast.error("поставьте вашу оценку");
      }
      if (!text.disc) {
        return toast.error("Поле 'отзыв' не может быть пустым");
      }
      if (!text.position) {
        return toast.error("Поле 'профессия' не может быть пустым!");
      }

      const req = await fetch('http://localhost:3002/rewievs', {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(text)
      });
      if (req.ok) {
        toast.success('Ваш отзыв отправлен на модерацию!');
        setText({
          disc: '',
          position: '',
          stars: '',
          id: '',
        })
      } else return toast.error('Ошибка при отправление отзыва')
      
    } catch (err) {
      console.log(err);
    }
  };

  const openReview = () => {
    setOpenReviews((e) => !e);
  };
  useEffect(() => {
    const checkToken = () => {
      if (!localStorage.getItem('token')) {
        return false;
      }
      return true;
    };

    const fetchData = async () => {
      if (!checkToken()) return;

      try {
        if (!token) {
          console.error('Token not found');
          return;
        }

        const req = await fetch(`http://localhost:3002/profile?token=${token}`);

        const res = await req.json();
        setUser(res.user);
      } catch (err) {
        console.error(err);
      }
    };

    fetchData();
  }, []);

  const token = localStorage.getItem('token')
  useEffect(() => {
    const checkToken = () => {
      if (!localStorage.getItem('token')) {
        return false;
      }
      return true;
    };

    const fetchData = async () => {
      if (!checkToken()) return;

      try {
        if (!token) {
          console.error('Token not found');
          return;
        }

        const req = await fetch(`http://localhost:3002/profile?token=${token}`);

        const res = await req.json();
        setUser(res.user);
      } catch (err) {
        console.error(err);
      }
    };

    fetchData();
  }, []);

  return (
    <><Basket />
      {openReviews ? <RamkaDiv>
        <TitleReviews>Добавить свой отзыв на сайте</TitleReviews>
        <ReviewInput placeholder="Ваша профессия" name="position" value={text.position} onChange={myOnChange} />
        <ReviewTextarea placeholder="Ваш отзыв" maxLength={300} name="disc" value={text.disc} onChange={myOnChange} />

        <Star>
          {arr.map((e, i) => {
            let count = i + 1;
            return (
              <StarSpan key={uuidv4()}><FaStar
                onClick={() => setStars(count)}
                color={count <= stars ? "yellow" : "gray"}
              /></StarSpan>
            );
          })}
        </Star>
        <ReviewButton onClick={addRewiev}>Добавить отзыв</ReviewButton>
      </RamkaDiv> : null}
      {openReviews ? <BGCdiv onClick={openReview} /> : null}
      <RewievPageDiv>
        <Client />
        <AddReview>
          <Slide duration={500} direction="left">
            <h1>Добавить свой отзыв на сайте</h1>
            <AddReviewButton onClick={openReview}>Добавить отзыв</AddReviewButton>
          </Slide>
        </AddReview>
      </RewievPageDiv>
    </>
  );
});

