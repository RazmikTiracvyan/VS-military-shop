import React, { useState, useEffect, useLayoutEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ProfileDiv } from './styled';
import { toast } from 'react-toastify';
import { Basket } from '../../components/basket';

export const User = () => {
    const { token } = useParams();
    const [user, setUser] = useState(null);
    const navigate = useNavigate(); // Rename loc to navigate for clarity
    console.log(1);

    useLayoutEffect(() => {
        const fetchData = async () => {
            try {
                if (!token || !user) {
                    console.error('Token not found');
                    return;
                }

                const req = await fetch(`http://localhost:3002/profile?token=${token}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                const res = await req.json();
                setUser(res.user);
                toast.success('Вы успешно авторизовались!');
            } catch (err) {
                console.error(err);
            }
        };

        fetchData();
    }, [token]);

    return (
        <div>
            <Basket />
            {
                user?.confirmed ? <ProfileDiv>
                    <div>anun {user.name}</div>
                    <div>azganun {user.lastName}</div>
                    <div>email {user.email}</div>
                    <h1>EJY DER PATRAST CHE</h1>
                </ProfileDiv> : null
            }

        </div>
    );
};

