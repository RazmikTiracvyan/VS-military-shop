import styled from "styled-components";


export const ProfileDiv = styled.div`
    width: 100%;
    min-height: 100vh;
    padding: 50px 20px;
    display: flex;
    justify-content: space-evenly;
    background-color: white;
`
export const ProfileSettingDiv = styled.div`
    width: 300px;
    min-height: 100vh;
    @media(max-width:1150px){
        z-index: 10;
        left: ${({ $resMenuOpen }) => $resMenuOpen === true ? "0" : "-300px"};
        top: 20px;
        transition: 0.5s;
        min-height: 10px;
        position: fixed;
    padding:50px 0 0 20px;



    }
    @media(max-width:400px){
        left: ${({ $resMenuOpen }) => $resMenuOpen === true ? "0" : "-400px"};

    width: 100%;

    padding: 0 20px 0 10px;
    position: fixed;

    }`

export const ProfileInfoDiv = styled.form`
    width: 70%;
    min-height: 100vh;
    background-color: #eee;
    border-radius: 20px;
    @media(max-width:1150px){
        width:100%;
        
    }
    `
export const ProfileInfoTitle = styled.div`
    width: 100%;
    height: 70px;
    border-bottom: 3px solid #C9C9C9;
    padding: 20px 0 0 10px;
`

export const ChangeDiv = styled.div`
    width: 100%;
    display: flex;
    justify-content:space-between;
    @media(max-width:675px){
    }
`

export const ChangeImg = styled.img`
    width: 150px;
    height: 150px;
    background-color: black;
    border-radius: 50%;
    margin-top: 20px;
    margin-left: 60px;
    @media(max-width:675px){
        width: 80px;
    height: 80px;

    }
`

export const ChangeInfo = styled.div`
    padding: 10px;
    font-size: 25px;
    color: blue;
    font-weight: bold;
    margin-top: 20px;
    word-wrap: break-word;

    cursor: pointer;
    &:hover{
        opacity: 0.5;
    }
    @media(max-width:675px){
    font-size: 14px;

    }
`

export const InfoDiv = styled.div`
    width: 100%;
    padding: 20px;
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    color: #999;
    
`

export const InfoInputDiv = styled.div`
    width: 45%;
    padding: 10px;
    @media(max-width: 500px){
        width: 100%;
    }
`
export const InfoInputDiv100 = styled.div`
    width: 95%;
    padding: 10px;
    @media(max-width: 500px){
        width: 100%;
    }
`

export const InfoInput = styled.input`
    width: 100%;
    height: 50px;
    border: none;
    outline: none;
    border-radius:10px;
    background-color: white;
    padding: 10px;
    font-size: 20px;
    border: ${({ $changeInfo }) => $changeInfo === true ? "1px solid black" : "none"}; 

    
`

export const InfoSelect = styled.select`
    width: 100%;
    height: 50px;
    border: none;
    outline: none;
    border-radius:10px;
    background-color: white;
    font-size: 20px;
    padding: 10px;
    

    
`
export const ChangeButton = styled.button`
	width: 300px;
	height: 40px;
	border-radius:50px;
	border: none;
	font-size: 19px;
	transition: 0.5s;
	background-color: #5cb85c;
    color: white;
    margin-top: 30px;
    opacity: ${({ $changeInfo }) => $changeInfo === true ? "1" : "0.5"}; 

	&:hover{
        box-shadow: ${({ $changeInfo }) => $changeInfo === true ? "rgb(38, 57, 77) 0px 10px 15px -5px;" : "none"}; 
        transform: ${({ $changeInfo }) => $changeInfo === true ? "scale(1.05);" : "none"}; 

	}
    @media(max-width: 500px){
        margin:  0 auto;
    }

	@media(max-width:196px){
		font-size:15px;
	}
    `


export const NameDiv = styled.div`
    width: 100%;
    padding: 10px 0 10px 10px;
    background-color: #eee;
    border-radius: 10px;
    display: flex;
    
`

export const ImgDiv = styled.div`
    width: 30%;
    margin: auto 0;
    
    
`
export const ImgTag = styled.img`
    width: 70%;
`

export const NameDivs = styled.div`
    width: 70%;
    height: auto;
    word-wrap: break-word;
    font-weight: bold;
    font-size: 20px;
    padding:  0 0 0 10px;
    border-left: 1px solid black;


`

export const PagesDiv = styled.div`
    width: 100%;
    height: 400px;
    background-color: #eee;
    margin-top: 20px;
    border-radius: 10px;
`


export const PageDiv = styled.div`
    width: 100%;
    height: 70px;
    cursor: pointer;
    background-color: ${({ $active }) => $active === true ? "#27ae60" : "none"};
    color: ${({ $active }) => $active === true ? "white" : "none"};
    border-bottom: 1px solid #C9C9C9;
    padding: 24px 10px 10px 10px;
    
`
export const PageTitleDiv = styled.div`
    width: 100%;
    min-height: 10px;

`

export const ResIconDiv = styled.div`
    width: 50px;
    height: 50px;
    position: absolute;
    right: 30px;
    top: 120px;
    font-size: 30px;
    cursor: pointer;
    display: none;
    position: fixed;
    text-align: center;
    color: white;
    background-color: #666;
    border-radius: 10px;
    z-index: 10;
    @media(max-width: 1150px){
        display: block;
    }

`