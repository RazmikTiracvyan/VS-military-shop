import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ChangeDiv,
  ChangeImg,
  ChangeInfo,
  ImgDiv,
  ImgTag,
  InfoDiv,
  InfoInput,
  InfoInputDiv,
  NameDiv,
  NameDivs,
  PageDiv,
  PageTitleDiv,
  PagesDiv,
  ProfileDiv,
  ProfileInfoDiv,
  ProfileInfoTitle,
  ProfileSettingDiv,
  ResIconDiv,
  InfoSelect,
  InfoInputDiv100,
  ChangeButton,
} from './styled';
import { toast } from "react-toastify"
import { Basket } from '../../components/basket';
import adminImg from "../../img/adminpanel/admin.png"
import { FaUser } from "react-icons/fa";
import { FaBasketShopping } from "react-icons/fa6";
import { CiStar } from "react-icons/ci";
import { MdOutlineChangeCircle } from "react-icons/md";
import { AiOutlineMenu } from "react-icons/ai";
import { RamkaSigns } from '../../components/header/styled';
import { HiMiniPencilSquare } from "react-icons/hi2";
import { MyOrders } from './userOrders';
import { MyReview } from './myReview';
import { ChangePassword } from './changePassword';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';

export const UserPage = () => {
  const token = localStorage.getItem('token')
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const [selectedCountry, setSelectedCountry] = useState("Երևան");
  const [changeInfo, setChangeInfo] = useState(false)
  const { register, handleSubmit, setValue } = useForm();
  const [page, setPage] = useState(0)
  const [menuLinks, setMenuLinks] = useState()
  const [lang, setLang] = useState(localStorage.getItem('lang'))
  const location = useLocation()
  const { t } = useTranslation()
  const [link , setLink] = useState()
  const menuColor = (e, i) => {
    let x = menuLinks.slice()
    x.map((element, indexes) => {
      if (indexes === i) element.active = true
      else element.active = false
    })
    setMenuLinks(x);
    setPage(i + 1)
    close();
  }
  const links = location?.state?.key

  useEffect(() => {
    console.log(link);
    if(links === "home"){
      setPage(1)
    }else if(links === "MyOrder"){
      setPage(2)
    }else if(links === "pass"){
      setPage(4)
    }else setPage(1)
    setLink(links)

    
  }, [links])
  useEffect(() => {
    const obj = [
      { name: t("My account"), active: (link == "home" || link == undefined)? true : false, icon: <FaUser /> },
      { name: t("My orders"), active:  link == "MyOrder"? true : false, icon: <FaBasketShopping /> },
      { name: t("My rewievs"), active: false, icon: <CiStar /> },
      { name: t("Change password"), active: link == "pass"? true : false, icon: <MdOutlineChangeCircle /> }
    ];
    setMenuLinks(obj)
  }, [changeInfo, lang , link])


  const [resMenuOpen, setResMenuOpen] = useState(false)

  useEffect(() => {
    const checkToken = () => {
      if (!localStorage.getItem('token')) {
        navigate('/');
        localStorage.removeItem('token')
        return false;
      }
      return true;
    };

    const fetchData = async () => {
      if (!checkToken()) return;

      try {
        if (!token) {
          console.error('Token not found');
          return;
        }

        const req = await fetch(`http://localhost:3002/profile?token=${token}`);

        const res = await req.json();
        setUser(res.user);
        if (!req.ok) {
          navigate('/')
        }
        if (!res?.user?.login) {
          console.log(res?.user?.login);
          return navigate('/')
        }
      } catch (err) {
        console.error(err);
      }
    };

    fetchData();
  }, [changeInfo]);


  const close = () => {
    setResMenuOpen(false)
  }


  const changeProduct = async (data) => {


    try {
      if (data.name == undefined) {
        data.name = user?.name
      }
      if (data.lastName == undefined) {
        data.lastName = user?.lastName
      }
      if (data.phone == undefined) {
        data.phone = user?.phone
      }

      if (data.address == undefined) {
        data.address = user?.address
      }
      if (data.name == "" || data.lastName == "" || data.phone == "" || data.address == "") {
        return toast.warning(t("Заполните все поле"))
      }

      if (data.name.length < 2) {
        return toast.warning(t("wName"))
      }
      if (data.lastName.length < 4) {
        return toast.warning(t("wLastName"))
      }
      if (data.phone.toString().length != 8) {
        return toast.warning(t("phone"))
      }


      const formData = new FormData();
      formData.append('name', data?.name?.trim() !== undefined && data?.name?.trim() !== "" ? data.name : user?.name);
      formData.append('lastName', data?.lastName?.trim() !== undefined ? data.lastName : user?.lastName);
      formData.append('phone', data.phone);
      formData.append('city', selectedCountry.trim() !== '' ? selectedCountry : user?.city);
      formData.append('region', data?.region.trim() !== "" ? data.region : "");
      formData.append('address', data?.address?.trim() !== '' ? data.address : user?.address);
      const req = await fetch(`http://localhost:3002/user/change/${user?._id}`, {
        method: "PUT",
        body: formData,
      });

      if (req.ok) {
        setChangeInfo(false)
        toast.success(t("Данные успешно сохранены"))
      }

    } catch (err) {
      toast.error('error')
      console.log(err);
    }
  };


  const [localStorageData, setLocalStorageData] = useState(localStorage.getItem('myData') || '');

  const handleStorageChange = () => {
    setLocalStorageData(localStorage.getItem('myData') || '');
  };

  useEffect(() => {
    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);



  return (
    <>

      <ProfileDiv>

        <Basket />
        {resMenuOpen && <RamkaSigns onClick={close} />}
        <ResIconDiv onClick={() => setResMenuOpen((e) => !e)}>
          <AiOutlineMenu />
        </ResIconDiv>
        <ProfileSettingDiv $resMenuOpen={resMenuOpen}>
          <NameDiv>
            <ImgDiv>
              <ImgTag src={adminImg} />
            </ImgDiv>
            <NameDivs>
              <p>{user?.name} {user?.lastName}</p>
            </NameDivs>
          </NameDiv>
          <PagesDiv>
            {
              menuLinks?.map((e, i) => {
                return (
                  <PageDiv key={i} onClick={() => menuColor(e, i)} $active={e.active}>
                    <PageTitleDiv>
                      {e.icon} {e.name}
                    </PageTitleDiv>
                  </PageDiv>
                )
              })
            }
          </PagesDiv>
        </ProfileSettingDiv>


        {page == 1 && <ProfileInfoDiv onSubmit={handleSubmit((data) => changeProduct(data))}>
          <ProfileInfoTitle>
            <h3>{t('Personal information')}</h3>
          </ProfileInfoTitle>
          <ChangeDiv>
            <ChangeImg src={adminImg} />
            {!changeInfo ? <ChangeInfo onClick={() => setChangeInfo(true)}>
              <HiMiniPencilSquare /> {t('Change profile information')}
            </ChangeInfo> : null}
          </ChangeDiv>
          <InfoDiv>
            <InfoInputDiv>
              <h5>{t("name")}</h5>

              <InfoInput disabled={!changeInfo} $changeInfo={changeInfo} defaultValue={changeInfo ? "" : user?.name}
                {...register("name")} />

            </InfoInputDiv>
            <InfoInputDiv>
              <h5>{t('sUpSurname')}</h5>
              <InfoInput disabled={!changeInfo} $changeInfo={changeInfo} defaultValue={!changeInfo ? user?.lastName : ""} {...register("lastName")} />

            </InfoInputDiv>
            <InfoInputDiv>
              <h5>{t('sUpMail')} </h5>
              <InfoInput disabled value={user?.email} />

            </InfoInputDiv>
            <InfoInputDiv>
              <h5>{t('aCall')}</h5>
              <InfoInput disabled={!changeInfo} $changeInfo={changeInfo} {...register("phone")} type='number' placeholder='77 777-777' defaultValue={user?.phone} />

            </InfoInputDiv>
            <InfoInputDiv>
              <h5>{t('Region')} </h5>
              {changeInfo ? <InfoSelect id="CCOUNTRY"
                name="CCOUNTRY"
                onChange={(e) => setSelectedCountry(e.target.value)}
                disabled={!changeInfo}
                defaultValue={user?.city || "Երևան"}
              >
                <option value="Երևան">{t('Երևան')}</option>
                <option value="Արարատ">{t('Արարատ')}</option>
                <option value="Մասիս">{t('Մասիս')}</option>
                <option value="Սիսիան">{t('Սիսիան')}</option>
                <option value="Ալավերդի">{t('Ալավերդի')}</option>
                <option value="Եղեգնաձոր">{t('Եղեգնաձոր')}</option>
                <option value="Գավառ">{t('Գավառ')}</option>
                <option value="Գորիս">{t('Գորիս')}</option>
                <option value="Վանաձոր">{t('Վանաձոր')}</option>
                <option value="Կապան">{t('Կապան')}</option>
                <option value="Էջմիածին">{t('Էջմիածին')}</option>
                <option value="Ստեփանավան">{t('Ստեփանավան')}</option>
                <option value="Արմավիր">{t('Արմավիր')}</option>
                <option value="Իջևան">{t('Իջևան')}</option>
                <option value="Արթիկ">{t('Արթիկ')}</option>
                <option value="Մարտունի">{t('Մարտունի')}</option>
                <option value="Աշտարակ">{t('Աշտարակ')}</option>
                <option value="Աբովյան">{t('Աբովյան')}</option>
                <option value="Հրազդան">{t('Հրազդան')}</option>
                <option value="Գյումրի">{t('Գյումրի')}</option>
                <option value="Դիլիջան">{t('Դիլիջան')}</option>
                <option value="Վարդենիս">{t('Վարդենիս')}</option>
                <option value="Ապարան">{t('Ապարան')}</option>
                <option value="Սևան">{t('Սևան')}</option>
                <option value="Արտաշատ">{t('Արտաշատ')}</option>
                <option value="Չարենցավան ">{t('Չարենցավան')} </option>
                <option value="Նոյեմբերյան">{t('Նոյեմբերյան')}</option>
                <option value="Թալին">{t('Թալին')}</option>
              </InfoSelect> :
                <InfoInput $changeInfo={changeInfo} value={user?.city} disabled={!changeInfo} />

              }


            </InfoInputDiv>
            <InfoInputDiv>
              <h5>{t("Address/Region")}</h5>
              {changeInfo ? <InfoSelect name="CREGION"
                disabled={selectedCountry !== "Երևան" || !changeInfo}
                style={{ opacity: selectedCountry !== "Երևան" ? "0.5" : "1" }}
                {...register("region")}
              >
                <option value="" selected=""></option>
                <option data-ddis="55665" value="Աջափնյակ">{t("Աջափնյակ")}</option>
                <option data-ddis="55674" value="Նոր Նորք">{t("Նոր Նորք")}</option>
                <option data-ddis="55675" value="Նուբարաշեն">{t("Նուբարաշեն")}</option>
                <option data-ddis="55676" value="Շենգավիթ">{t("Շենգավիթ")}</option>
                <option data-ddis="55666" value="Արաբկիր">{t("Արաբկիր")}</option>
                <option data-ddis="55667" value="Ավան">{t("Ավան")}</option>
                <option data-ddis="55668" value="Դավթաշեն">{t("Դավթաշեն")}</option>
                <option data-ddis="55669" value="Էրեբունի">{t("Էրեբունի")}</option>
                <option data-ddis="55670" value="Քանաքեռ-Զեյթուն">{t("Քանաքեռ-Զեյթուն")}</option>
                <option data-ddis="55671" value="Կենտրոն">{t("Կենտրոն")}</option>
                <option data-ddis="55672" value="Մալաթիա-Սեբաստիա">{t("Մալաթիա-Սեբաստիա")}</option>
                <option value="Նորք-Մարաշ">{t("Նորք-Մարաշ")}</option>
              </InfoSelect>
                :
                <InfoInput $changeInfo={changeInfo} value={user?.region} disabled={!changeInfo} />

              }


            </InfoInputDiv>

            <InfoInputDiv100>
              <h5>{t('Address/Region')}</h5>
              <InfoInput disabled={!changeInfo} placeholder='Street, House, Appartment' $changeInfo={changeInfo} {...register("address")} defaultValue={user?.address !== "undefined" ? user?.address : null} />



            </InfoInputDiv100>



            <ChangeButton disabled={!changeInfo} $changeInfo={changeInfo} >{t('Change')}</ChangeButton>
          </InfoDiv>
        </ProfileInfoDiv>}

        {page == 2 && <MyOrders />}
        {page == 3 && <MyReview id={user?._id} />}
        {page == 4 && <ChangePassword id={user?._id} />}



      </ProfileDiv>
    </>

  );
}


