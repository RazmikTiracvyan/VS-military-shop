import styled from "styled-components";
import { Link } from "react-router-dom";
export const MyOrdersDiv = styled.div`
    width: 70%;
    height: 100vh;
    background-color: #eee;
    border-radius: 20px 0 0 20px;
    padding: 10px 20px;
    overflow-y: scroll;
    &::-webkit-scrollbar {
    width: 7px;
    height: 90%;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #888;
  }

  &::-webkit-scrollbar-thumb:hover {
    background-color: #333;
  }

  &::-webkit-scrollbar-track {
    background-color: #555;
  }
    @media(max-width:1150px){
        width:100%;
        
    }
    `
export const OrdersTitle = styled.div`
width: 100%;
min-height: 70px;
border-bottom: 3px solid #C9C9C9;
padding: 20px 0 0 20px;
font-weight: bold;
`


export const HistoryCardDiv = styled(Link)`
    min-height:100px;
    width: 100%;
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
    border-radius: 20px;
    box-shadow: 0px 0px 17px -2px rgba(0,0,0,0.75);
    padding: 20px;
    text-decoration: none;
    color: black;

    @media(max-width: 600px){
        display: inline-block;

    }

`
export const HistoryCardImgDiv = styled.div`
    width: 10%;
    margin: auto 0;
    @media(max-width:600px){
        width:100%;
        text-align: center;
         margin-top: 2px;


    }
`
export const HistoryCardImg = styled.img`
    width: 100%;
    @media(max-width:600px){
       width: 50%;

    }
`
export const HistoryCardTitle = styled.div`
    min-height: 20px;
    width: 20%;
    flex-wrap: wrap;
    margin: auto 0;
    word-wrap: break-word;
    @media(max-width: 600px){
        font-size: 15px;
        width: 100%;
        text-align: center;
    }


`
export const PriceDiv = styled.div`
    height: 100px;
    display: flex;
    margin: auto 0;
    @media(max-width: 600px){
        font-size: 25px;
}
`
export const PriceNum = styled.div`
    min-width: 100px;
    text-align: center;
    margin: auto;
    font-size: 22px;
    @media(max-width: 600px){
        font-size: 25px;
    }
    
    
`
export const Price = styled.div`
    font-size: 25px;
    width: 20%;
    margin: auto 0;
    @media(max-width: 600px){
        font-size: 25px;
        width: 100%;
        text-align: center;
    }
`


