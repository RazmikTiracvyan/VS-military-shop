import React, { useEffect, useState } from "react";
import {
    MyOrdersDiv,
    OrdersTitle,
    HistoryCardDiv,
    HistoryCardImgDiv,
    HistoryCardImg,
    HistoryCardTitle,
    Price,
    PriceDiv,
    PriceNum



} from "./styled";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
export const MyOrders = () => {
    const [product, setProduct] = useState('')
    const token = localStorage.getItem('token')
    let [count, setCount] = useState()
    const { t } = useTranslation()
    const lang = localStorage.getItem("lang") || "ru"
    useEffect(() => {
        const fetchData = async () => {
            try {
                const req = await fetch(`http://localhost:3002/buyhistory?token=${token}`)
                const res = await req.json()

                setProduct(res.products)

                let total = 0;
                for (let i = 0; i < res.products?.length; i++) {
                    total += res.products[i].price;
                }
                setCount(total);
            }
            catch (err) {
                console.log(err);
            }
        }

        fetchData()

    }, [])


    return (
        <MyOrdersDiv>
            <OrdersTitle>
                <h4>{t("Ваша покупка за все время на сумму")} ֏{count}</h4>

            </OrdersTitle>

            {product && product.map((e, i) => {
                return (

                    <HistoryCardDiv to={`/shop/product/id/${e._id}`}>
                        <HistoryCardImgDiv>
                            <HistoryCardImg src={`http://localhost:3002/uploads/${e.img}`} />
                        </HistoryCardImgDiv>
                        <HistoryCardTitle>
                            {lang === "ru" && e.titleRU || lang === "am" && e.titleAM || lang === "en" && e.titleEN}
                        </HistoryCardTitle>

                        <PriceDiv>

                            <PriceNum>{t('count')} {e.basketCount}</PriceNum>

                        </PriceDiv>
                        <Price>
                        ֏{e.price} 
                        </Price>

                    </HistoryCardDiv>
                )
            })}
        </MyOrdersDiv>
    )
}