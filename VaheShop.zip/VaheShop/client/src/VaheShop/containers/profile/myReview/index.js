import React, { useRef, useState, useEffect } from 'react'
import Slider from 'react-slick'
import styled from 'styled-components'
import ClientSlider from './card';
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { Slide } from 'react-awesome-reveal';
import { MyReviewDiv } from './styled';
import { toast } from 'react-toastify';
import { useTranslation } from "react-i18next";


export const MyReview = ({ id }) => {
    const [rewievs, setRewievs] = useState([])
    let settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: rewievs.length >= 3 ? 3 : rewievs.length == 2 ? 2 : 1,
        slidesToScroll: 1,
        initialSlide: 0,
        arrows: false,
        responsive: [
            {
                breakpoint: 990,
                settings: {
                    slidesToShow: rewievs.length >= 2 ? 2 : 1,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 700,
                settings: {
                    slidesToShow: rewievs.length >= 2 ? 2 : 1,
                    slidesToScroll: 1,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 530,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    }
    useEffect(() => {


        const fetchData = async () => {
            try {
                const req = await fetch(`http://localhost:3002/user/review/${id}`);
                const res = await req.json();
                setRewievs(res.rev)
            } catch (err) {
                console.log(err);
            }
        };

        fetchData();

    }, []);
    const arrowRef = useRef(null);
    const { t } = useTranslation()
    let clientDisc = rewievs?.map((item, i) => {

        return (
            <ClientSlider item={item} key={i} />
        )
    })

    return (
        <>
            <MyReviewDiv>{rewievs.length !== 0 &&
                <Container id='client'>
                    <Slide direction="right">
                        <h2>{t("Oтзывы")}</h2>
                    </Slide>
                    <Testimonials>
                        <Slider ref={arrowRef} {...settings}>
                            {clientDisc}

                        </Slider>
                        <Buttons>
                            <button
                                onClick={(e) => { e.preventDefault(); arrowRef.current.slickPrev() }}
                            ><IoIosArrowBack /></button>
                            <button
                                onClick={(e) => { e.preventDefault(); arrowRef.current.slickNext() }}
                            ><IoIosArrowForward /></button>
                        </Buttons>

                    </Testimonials>
                </Container>
            } </MyReviewDiv>
        </>

    )
}


const Container = styled.div`
  overflow-wrap: break-word;

    width: 90%;
    max-width: 1280px;
    margin: 0 auto;
    padding: 20px;




    span{
        font-weight: 700;
    }

    h1{
        padding-top: 1rem;
        text-transform: capitalize;
    }

    .slick-list, .slick-slider, .slick-track{
        padding: 0;
    }

    .slick-dots{
        text-align: left;
        margin-left: 1rem;
    }

    .slick-dots li button:before{
        content: "";
    }

    .slick-dots li button{
        width: 9px;
        height: 4px;
        background: linear-gradient(159deg, rgb(45, 45, 58) 0%, rgb(43, 43, 53) 100%);
        padding: 0.1rem;
        margin-top: 1rem;
        transition: all 400ms ease-in-out;
        border-radius: 50px;
    }
    
    .slick-dots li.slick-active button{
        background: #01be96;
        width: 15px;
    }

    .slick-dots li{
        margin: 0;
    }
`


const Testimonials = styled.div`
    margin-top: 2rem;
    position: relative;
`
const Buttons = styled.div`
    position: absolute;
    right: 0.7rem;
    bottom: -2rem;

    button{
        background-color: transparent;
        margin-left: 0.5rem;
        border: none;
        color: #01be96;
        cursor: pointer;
        font-size: 1.1rem;
    }

    @media(max-width:530px){
        display: none;
    }
`