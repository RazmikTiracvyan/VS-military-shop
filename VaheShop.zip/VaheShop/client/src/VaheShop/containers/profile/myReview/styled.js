import styled from "styled-components";

export const MyReviewDiv = styled.form`
    width: 70%;
    min-height: 100vh;
    background-color: #eee;
    border-radius: 20px;

    @media(max-width:1150px){
        width:100%;
        
    }
    `