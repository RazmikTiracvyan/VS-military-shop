import React from 'react'
import styled from 'styled-components'
import { IoIosQuote } from "react-icons/io";
import { FaStar } from "react-icons/fa";
import { MdAccessTime } from "react-icons/md";
import { useTranslation } from 'react-i18next';
import { IoMdDoneAll } from "react-icons/io";

const ClientSlider = (props) => {
    const { name, lastName, position, img_url, stars, disc, confirmed } = props.item;
    const { t } = useTranslation()
    console.log(confirmed);
    return (
        <Container>
            <Header>
                <span className='quote'><IoIosQuote /></span>
                <div>
                    {Array(stars).fill().map((_, i) => (
                        <span className='star' key={i}>
                            <FaStar />
                        </span>
                    ))}
                </div>
            </Header>
            <Body>
                {position}
            </Body>
            <Footer>
                <ImgDiv>
                    <img src={img_url ? img_url : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRir06bApyiBCEsxHMGNWtcxEZGCLYj5vdcxQ&usqp=CAU"} alt={name} />
                </ImgDiv>
                <BodyDiv className="details">
                    <h1>{name} {lastName}</h1>
                    <p style={{ color: "black" }}>{disc}</p>
                </BodyDiv>
            </Footer>
            <ConfirmDiv $confirmed={confirmed}>
                {confirmed ? (
                    <>
                        <IoMdDoneAll /> {t('Одобрен')}
                    </>
                ) : (
                    <>
                        <MdAccessTime /> {t('Ожидает подтверждение')}
                    </>
                )}
            </ConfirmDiv>        </Container>
    )
}

export default ClientSlider

const ImgDiv = styled.div`
    padding-bottom: 150px;
`

const Container = styled.div`
    background: white;
    padding: 1.5rem 1rem;
    margin: 0 1rem;
    border-radius: 20px;
    

`
const ConfirmDiv = styled.div`
    width: 100%;
    height: 50px;
    padding-bottom: 50px;
    color: ${({ $confirmed }) => $confirmed ? "green" : "#ffcd3c"};
`

const BodyDiv = styled.div`
overflow: auto;
white-space: pre-wrap;
width: 100%;
height: 250px;
&::-webkit-scrollbar {
    width: 5px;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #888;
  }

  &::-webkit-scrollbar-thumb:hover {
    background-color: #333;
  }

  &::-webkit-scrollbar-track {
    background-color: #555;
  }
`
const Header = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    .quote{
        font-size: 3rem;
        color: #01be96;
        opacity: 0.7;
    }

    .star{
        color: #ffcd3c;
        font-size: 1.3rem;
    }
`
const Body = styled.p`
    font-size: 0.8rem;
    margin-bottom: 1.5rem;
`
const Footer = styled.div`
    display: flex;
    align-items: center;
    gap: 1rem;
    img{
        width: 4rem;
        height: 4rem;
        border-radius: 50px;
        object-fit: cover;
    }

    h1{
        font-size: 1.2rem;
        font-weight: 700;
        @media(max-width: 580px){
            font-size: 1rem;
        }
        @media(max-width: 538px){
            font-size: 0.9rem;
        }
    }

    p{
        font-size: 0.8rem;
        color: rgba(255,255,255,0.500);
        @media(max-width: 538px){
            font-size: 0.6rem;
        }
    }
`