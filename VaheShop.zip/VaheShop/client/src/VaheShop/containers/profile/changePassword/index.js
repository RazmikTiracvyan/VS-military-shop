import React, { useEffect, useState } from "react";
import {
    ChangeButton,
    ChangePasswordDiv,
    ChangePasswordTitle,
    FormDiv,
    FormInput,
    FormTitle,
    InputDiv,
    ShowPass,
} from "./styled";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import { IoEyeSharp } from "react-icons/io5";
import { FaEyeSlash } from "react-icons/fa";
export const ChangePassword = ({ id }) => {
    const [value, setValue] = useState({
        password: '',
        newPassword: '',
        newPassword2: ''
    })

    const [showPass1, setShowPass1] = useState(false);
    const [showPass2, setShowPass2] = useState(false);
    const [showPass3, setShowPass3] = useState(false);
    const changePass = (e) => {
        const { name, value } = e.target;
        setValue((prev) => {
            return { ...prev, [name]: value };
        });
    };

    const { t } = useTranslation()
    const fetchData = async (e) => {
        e.preventDefault()
        if (value.newPassword.length < 8 || value.newPassword.length > 18) {
            return toast.warning(t("Пароль должен быть от 8 до 16 симовлов"))

        }
        if (value.newPassword !== value.newPassword2) {
            return toast.warning(t("Пароли не совпадают"))
        }

        try {
            const req = await fetch('http://localhost:3002/profile/changepassword', {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ data: value, id: id })

            })
            if (req.status == 400) {
                return toast.error(t('Вы ввели неверный пароль'))

            }
            if (!req.ok) {
                return toast.error(t('Произошла ошибка при попытке изменения пароля'))
            } else toast.success(t('Ваш пароль успешно изменен'))
            setValue({ password: '', newPassword: '', newPassword2: '' })
        }
        catch (err) {
            console.log(err);
            toast.error(t('Произошла ошибка при попытке изменения пароля'))

        }
    }

    return (
        <ChangePasswordDiv>
            <ChangePasswordTitle>
                <h5>{t("Change password")}</h5>
            </ChangePasswordTitle>
            <FormDiv>
                <FormTitle>
                    <h6>{t('Введите ваш старый пароль')}</h6>
                </FormTitle>

                <InputDiv>
                    <FormInput type={showPass1 ? "text" : "password"}
                        name="password"
                        value={value.password}
                        onChange={changePass} />
                    <ShowPass onClick={() => setShowPass1((e) => !e)}>
                        {showPass1 ? < IoEyeSharp /> : <FaEyeSlash />}
                    </ShowPass>

                </InputDiv>

                <FormTitle>
                    <h6>{t('Введите ваш новый пароль')}</h6>
                </FormTitle>
                <InputDiv>
                    <FormInput type={showPass2 ? "text" : "password"}
                        name="newPassword"
                        value={value.newPassword}
                        onChange={changePass} />
                    <ShowPass onClick={() => setShowPass2((e) => !e)}>
                        {showPass2 ? < IoEyeSharp /> : <FaEyeSlash />}
                    </ShowPass>

                </InputDiv>

                <FormTitle>
                    <h6>{t('Повторите пароль')}</h6>
                </FormTitle>

                <InputDiv>
                    <FormInput type={showPass3 ? "text" : "password"}
                        name="newPassword2"
                        value={value.newPassword2}
                        onChange={changePass} />
                    <ShowPass onClick={() => setShowPass3((e) => !e)}>
                        {showPass3 ? < IoEyeSharp /> : <FaEyeSlash />}
                    </ShowPass>

                </InputDiv>
                <ChangeButton onClick={fetchData}>{t("Change password")}</ChangeButton>
            </FormDiv>
        </ChangePasswordDiv>
    )


}