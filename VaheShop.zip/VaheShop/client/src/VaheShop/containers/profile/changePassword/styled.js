import styled from "styled-components";


export const ChangePasswordDiv = styled.form`
    width: 70%;
    min-height: 100vh;
    background-color: #eee;
    border-radius: 20px;
    @media(max-width:1150px){
        width:100%;
        
    }
    `

export const ChangePasswordTitle = styled.div`
width: 100%;
height: 70px;
border-bottom: 3px solid #C9C9C9;
padding: 20px 0 0 10px;
`

export const FormDiv = styled.div`
    width: 400px;
    padding: 40px 10px;
    margin: 0 auto;
    @media(max-width:450px){
        width: 100%;
    }
    
`

export const FormTitle = styled.div`
    width: 100%;
    margin-top: 20px;
    @media(max-width:450px){
        font-size: 10px;
    }
    
    
`

export const InputDiv = styled.div`
    width: 100%;
    height: 40px;
    position: relative;
`


export const FormInput = styled.input`
    width: 100%;
    height: 40px;
    padding: 10px;
    border: none;
    outline: none;
    border-radius: 20px;
`
export const ShowPass = styled.div`
    width: 40px;
    height: 40px;
    position: absolute;
    right: 0;
    top: 0;
    font-size: 22px;
`


export const ChangeButton = styled.button`
	width: 100%;
	height: 40px;
	border-radius:50px;
	border: none;
	font-size: 19px;
	transition: 0.5s;
	background-color: #5cb85c;
    color: white;
    margin-top: 30px;

	&:hover{
        box-shadow:rgb(38, 57, 77) 0px 10px 15px -5px; 
        transform: scale(1.05); 

	}
   

	@media(max-width:196px){
		font-size:15px;
	}
    `