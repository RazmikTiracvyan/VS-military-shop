import styled from 'styled-components';
import { Link } from 'react-router-dom';
export const Page404Wrapper = styled.section`
  padding: 40px 0;
  background: #fff;
  font-family: 'Arvo', serif;
`;

export const FourZeroFourBg = styled.div`
  background-image: url(https://cdn.dribbble.com/users/285475/screenshots/2083086/dribbble_1.gif);
  height: 400px;
  background-position: center;
`;

export const FourZeroFourHeading = styled.h1`
  font-size: 50px;
`;

export const FourZeroFourSubHeading = styled.h3`
  font-size: 80px;
`;

export const Link404 = styled(Link)`
  color: #fff !important;
  padding: 10px 20px;
  background: #39ac31;
  margin: 20px 0;
  display: inline-block;
  text-decoration: none;
  border-radius: 10px;
  
`;

export const ContantBox404 = styled.div`
  margin-top: -50px;
`;