import React from 'react';

import {Page404Wrapper , FourZeroFourHeading , FourZeroFourSubHeading , Link404 , ContantBox404 , FourZeroFourBg} from "./styled"


const NotFoundPage = () => (
  <Page404Wrapper>
    <div className="container">
      <div className="row">
        <div className="col-sm-12">
          <div className="col-sm-10 col-sm-offset-1 text-center">
            <FourZeroFourBg>
              <FourZeroFourHeading>Page not found</FourZeroFourHeading>
            </FourZeroFourBg>

            <ContantBox404>
              <FourZeroFourSubHeading>Looks like you're lost</FourZeroFourSubHeading>

              <p>The page you are looking for is not available!</p>

              <Link404 to="/">Go to Home</Link404>
            </ContantBox404>
          </div>
        </div>
      </div>
    </div>
  </Page404Wrapper>
);

export default NotFoundPage;
