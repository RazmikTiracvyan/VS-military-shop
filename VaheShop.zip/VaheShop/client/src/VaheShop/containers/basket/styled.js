import { Link } from "react-router-dom";
import styled from "styled-components";

export const MainDiv = styled.div`
    width: 100%;
    min-height: 100vh;
    display: flex;
    padding: 30px;
    @media(max-width:1085px){
        display: inline;
    }

`

export const BasketInfo = styled.div`
    width: 70%;
    min-height: 100vh;
    padding: 20px;
    @media(max-width:1085px){
        margin: 0 auto;
        width: 100%;
    min-height: 0vh;


    }

`
export const LinkToBack = styled(Link)`
    text-decoration: none;
    color: black;
    font-size: 20px;

`
export const BasketInfoTitle = styled.div`
    height: 50px;
    border-bottom: 2px solid #e5e5e5;

`
export const BasketInfoText = styled.div`
    width: 100%;
    padding: 10px;
`
export const BasketCardDiv = styled.div`
    min-height:100px;
    padding: 0 15px;
    width: 100%;
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
    border-radius: 20px;
    box-shadow: 0px 0px 17px -2px rgba(0,0,0,0.75);

`
export const BasketCardImgDiv = styled.div`
    width: 10%;
    margin: auto 0;
    @media(max-width:500px){
        display: none;

    }
`
export const BasketCardImg = styled.img`
    width: 100%;
`
export const BasketCardTitle = styled.div`
    min-height: 20px;
    flex-wrap: wrap;
    margin: auto 0;

`

export const PriceDiv = styled.div`
    height: 100px;
    display: flex;
    margin: auto 0;
`

export const PricePlusMinus = styled.div`
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background-color: white;
    box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.75);
    margin: auto 0;
    text-align: center;
    font-size: 19px;
    cursor: pointer;
    transition: 0.3s;
    &:hover{
        transform: scale(1.2);
    }
    @media(max-width:600px){
        width: 20px;
        height: 20px;
        font-size: 12px;

    }
`
export const PriceNum = styled.div`
    width: 40px;
    text-align: center;
    margin: auto;
    font-size: 28px;
    
    
`
export const Price = styled.div`
    font-size: 25px;
    margin: auto 0;
    margin-left: 20px;
    @media(max-width: 600px){
        font-size: 15px;
    }
`
export const DeleteDiv = styled.div`
    cursor: pointer;
    margin: auto 0;


    
`
export const DeleteIcon = styled.div`
    font-size: 35px;
    @media(max-width: 600px){
        font-size: 25px;
    }


`


export const BasketBuy = styled.div`
    width: 30%;
    height: 550px;
    background: linear-gradient(270deg, rgba(0,255,119,0.891281512605042) 0%, rgba(64,94,62,1) 100%);
    border-radius: 20px;
    padding: 0 20px;
    @media(max-width:1085px){
        margin: 0 auto;
        width: 50%;
    }
    @media(max-width:700px){
        width: 70%;
    }
    @media(max-width:500px){
        width: 90%;
    }

`

export const BasketBuyTitleDiv = styled.div`
    width: 100%;
    font-weight: bold;
    padding: 20px 0;
    color: white;
    font-size: 25px;
`

export const BasketBuyCardType = styled.div`
    width: 100%;
    font-weight: bold;
    font-size: 20px;
    color: white;
`
export const BasketBuyCards = styled.div`
width: 150px;
    display: flex;
    justify-content: space-between;
`
export const CardSpan = styled.span`
   font-size: 40px;

`
export const ImgCard = styled.img`
    border-radius: 5px;
    height: 32px;
    margin-top: 20px;
`

export const BuyForm = styled.form`
    width: 100%;
    min-height: 500px;
`

export const CardInput = styled.input`
    width: 100%;
    height: 40px;
    border-radius: 10px;
    background-color: white;
    border: none;
    outline: none;
    padding: 10px;
    margin-top: 20px;
`

export const CardInfoDiv = styled.div`
    width: 100%;
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
    height: 70px;
    border-bottom: 1px solid black;


`


export const CardData = styled.input`
    width: 45%;
    height: 40px;
    border-radius: 10px;
    background-color: white;
    border: none;
    outline: none;
    padding: 10px;
`

export const TotalPrice = styled.div`
    display: flex;
    justify-content: space-around;
    margin-top: 10px;
`

export const TotalPriceKey = styled.span`
    font-weight: bold;
    font-size: 20px;
    color: white;
`

export const TotalPriceValue = styled.span`
     font-weight: bold;
    font-size: 20px;
    color: white;

`
export const BuyButtonDiv = styled.div`
    width: 100%;
    text-align: center;
    padding: 10px;

`

export const BuyButton = styled.button`
  opacity: 1;
  padding: 10px 30px;
  color: black;
  text-decoration: none;
  background: linear-gradient(270deg, rgba(0,255,119,0.891281512605042) 0%, rgba(221,255,113,1) 100%);
  border-radius: 30px;
  text-transform: uppercase;
  letter-spacing: 1px;
  transition: 0.5s;
  border: none;
    width: 70%
    ;

  &:hover {
    opacity: 0.9;
    transform: scale(1.1);
  }
`