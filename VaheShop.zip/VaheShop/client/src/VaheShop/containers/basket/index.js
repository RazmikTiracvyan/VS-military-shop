import React, { useState, useEffect } from "react";
import {
  BasketInfo,
  MainDiv,
  BasketBuy,
  BasketInfoTitle,
  LinkToBack,
  BasketInfoText,
  BasketCardDiv,
  BasketCardImgDiv,
  BasketCardTitle,
  BasketCardImg,
  PriceDiv,
  PricePlusMinus,
  PriceNum,
  Price,
  DeleteDiv,
  DeleteIcon,
  BasketBuyTitleDiv,
  BasketBuyCardType,
  BasketBuyCards,
  CardSpan,
  ImgCard,
  BuyForm,
  CardInput,
  CardInfoDiv,
  CardData,
  TotalPrice,
  TotalPriceKey,
  TotalPriceValue,
  BuyButton,
  BuyButtonDiv,
} from "./styled";
import { FaLongArrowAltLeft } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import { Basket } from "../../components/basket";
import { FaCcVisa } from "react-icons/fa";
import { FaCcMastercard } from "react-icons/fa";
import cardImg from "../../img/socSeti/cardArca.jpg";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export const BasketPage = () => {
  const [products, setProducts] = useState();
  const [price, setPrice] = useState();
  const [pricePlus, setPricrPlus] = useState(false);
  const [user, setUser] = useState();
  const [cardNumber, setCardNumber] = useState("");
  const [date, setDate] = useState("");
  const [cvv, setCvv] = useState("");
  const loc = useNavigate();
  const token = localStorage.getItem("token");
  if (!token) {
    loc("/");
  }
  useEffect(() => {
    const fetchData = async () => {
      try {
        const req = await fetch(`http://localhost:3002/basket?token=${token}`);
        const res = await req.json();
        setProducts(res.user.basket);
        setUser(res.user._id);
        const totalPrice = res?.user?.basket.reduce(
          (acc, product) => acc + product?.price * product?.basketCount,
          0
        );
        setPrice(totalPrice);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, [pricePlus]);

  const minusePrice = async (i) => {
    try {
      if (products[i]?.basketCount == 1) {
        return;
      }
      const id = products[i]._id;
      console.log(user);

      const req = await fetch(`http://localhost:3002/basket/price/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ type: "minus", user: user }),
      });
      if (req.ok) {
        setPricrPlus((e) => !e);
      }
    } catch (err) {
      console.log(err);
    }
  };
  const plusPrice = async (i) => {
    try {
      if (products[i]?.basketCount == 10) {
        return;
      }
      const id = products[i]._id;
      const req = await fetch(`http://localhost:3002/basket/price/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ type: "plus", user: user }),
      });
      if (req.ok) {
        setPricrPlus((e) => !e);
      }
    } catch (err) {
      console.log(err);
    }
  };
  const deleteProduct = async (i) => {
    try {
      const id = products[i]._id;
      console.log(id);
      const req = await fetch(`http://localhost:3002/basket/delete/${id}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ num: user }),
      });
      if (req.ok) {
        setPricrPlus((e) => !e);
      }
    } catch (err) {
      console.log(err);
    }
  };

  const handleCardNumberChange = (e) => {
    const inputCardNumber = e.target.value.replace(/\D/g, "");

    const formattedCardNumber = inputCardNumber
      .replace(/(\d{4})/g, "$1 ")
      .trim();

    const limitedCardNumber = formattedCardNumber.slice(0, 19);

    setCardNumber(limitedCardNumber);
  };
  const handleDateChange = (e) => {
    const inputDate = e.target.value;

    const cleanedDate = inputDate.replace(/\D/g, "");

    const formattedDate = cleanedDate.replace(/^(\d{2})/, "$1/");

    const limitedDate = formattedDate.slice(0, 7);

    setDate(limitedDate);
  };
  const handleCvvChange = (e) => {
    const inputCvv = e.target.value;

    const cleanedCvv = inputCvv.replace(/\D/g, "");

    const limitedCvv = cleanedCvv.slice(0, 4);

    setCvv(limitedCvv);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (!token) {
          console.error("Token not found");
          return;
        }
        const req = await fetch(`http://localhost:3002/profile?token=${token}`);
        const res = await req.json();
        setUser(res.user._id);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, []);
  const prodId = [];

  products?.map((e, i) => {
    prodId.push(e._id);
  });

  const buyHistory = async (e) => {
    e.preventDefault();
    try {
      if (!token) {
        console.error("Token not found");
        return;
      }
      const req = await fetch(
        `http://localhost:3002/users/buy/history/${user}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(prodId),
        }
      );

      const res = await req.json();
      if (req.status == 400) {
        return toast.error("Ошибка покупкы продукта");
      }
      if (req.ok) {
        toast.success("Вы успешно купили данные товыра");
      } else return toast.error("Ошибка");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <>
      <MainDiv>
        <BasketInfo>
          <LinkToBack to="/shop">
            <BasketInfoTitle>
              <FaLongArrowAltLeft /> Continue shopping
            </BasketInfoTitle>
          </LinkToBack>
          <BasketInfoText>
            <h2>
              You have {products?.length} items in your cart , Total price`{" "}
              {price}Դ
            </h2>
          </BasketInfoText>
          {products?.map((e, i) => {
            return (
              <BasketCardDiv>
                <BasketCardImgDiv>
                  <BasketCardImg
                    src={`http://localhost:3002/uploads/${e.img}`}
                  />
                </BasketCardImgDiv>
                <BasketCardTitle>{e.titleAM}</BasketCardTitle>

                <PriceDiv>
                  <PricePlusMinus onClick={() => minusePrice(i)}>
                    -
                  </PricePlusMinus>
                  <PriceNum>{e.basketCount}</PriceNum>
                  <PricePlusMinus onClick={() => plusPrice(i)}>
                    +
                  </PricePlusMinus>
                </PriceDiv>
                <Price>{e.price * e.basketCount}Դ</Price>
                <DeleteDiv>
                  <DeleteIcon onClick={() => deleteProduct(i)}>
                    <MdDelete />
                  </DeleteIcon>
                </DeleteDiv>
              </BasketCardDiv>
            );
          })}
        </BasketInfo>
        <BasketBuy>
          <BasketBuyTitleDiv>Card details</BasketBuyTitleDiv>
          <BasketBuyCardType>
            Card type
            <BasketBuyCards>
              <CardSpan>
                <FaCcVisa />
              </CardSpan>
              <CardSpan>
                <FaCcMastercard />
              </CardSpan>
              <ImgCard src={cardImg} />
            </BasketBuyCards>
          </BasketBuyCardType>
          <BuyForm onSubmit={buyHistory}>
            <CardInput placeholder="NAME USERNAME" />
            <CardInput
              placeholder="1234 1234 1234 1234"
              value={cardNumber}
              onChange={handleCardNumberChange}
            />
            <CardInfoDiv>
              <CardData
                onChange={handleDateChange}
                value={date}
                placeholder="MM/YYYY"
              />
              <CardData
                type="password"
                placeholder="Cvv"
                value={cvv}
                onChange={handleCvvChange}
              />
            </CardInfoDiv>
            <TotalPrice>
              <TotalPriceKey>total price`</TotalPriceKey>
              <TotalPriceValue>{price}Դ</TotalPriceValue>
            </TotalPrice>
            <BuyButtonDiv>
              <BuyButton>{price}Դ BUY</BuyButton>
            </BuyButtonDiv>
          </BuyForm>
        </BasketBuy>
        <Basket pricePlus={pricePlus} />
      </MainDiv>
    </>
  );
};
