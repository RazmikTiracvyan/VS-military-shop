import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ProductStr } from '../productStr/index';
import { useTranslation } from 'react-i18next';
import {
    ProductDivs,
    CardContainer,
    ImgBox,
    BuyButton,
    Price,
    Img,
    Title,
    ContentBox,
    TitleProd
} from "./styled";
import { Basket } from '../../components/basket';
import { Footer, Header } from '../../components';
import { ProductGin } from '../../components/HistoryProducts/styled';
import Nkar from "../../img/chapterImg/broni.png"



export function Product() {
    const [products, setProducts] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [lange, setLange] = useState(false);
    const [user, setUser] = useState()
    const lang = localStorage.getItem('lang') || 'ru';
    const prevLangRef = useRef(lang);
    const { t } = useTranslation()
    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch("https://localhost:7123/api/product");
                if (!response.ok) {
                    throw new Error(`Failed to fetch products. Status: ${response.status}`);
                }

                const data = await response.json();
                setProducts(data);
                setLoading(false);
            
                  fetchData();
            } catch (err) {
                console.error('Error fetching products:', err.message);
                setError('Failed to fetch products. Please try again later.');
                setLoading(false);
            }
        };

        fetchData();
    

        
    }, []);
    const token = localStorage.getItem('token')
    useEffect(() => {
        const fetchData = async () => {
            try {
                if (!token) {
                    return;
                }
                const req = await fetch(`http://localhost:3002/profile?token=${token}`)
                const res = await req.json()
                setUser(res.user._id)
            }

            catch (err) {
                console.log(err);
            }
        }
        fetchData()
    }, [])
    const addHistory = async (index) => {

        try {
            if (!token) {
                return;
            }
            const id = products[index]._id
            const req = await fetch(`http://localhost:3002/users/history/${user}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ number: id })
            });



        } catch (err) {
            console.error(err);
        }
    };

    return (
        <>
            <Basket />
            {loading ? (
                <p>{t("Loading products")}</p>
            ) : error ? (
                <p>{error}</p>
            ) : (
                <>
                    <TitleProd>{t("Новые товары")}</TitleProd>

                    <ProductDivs>
                        {products.map((product, index) => {
                            console.log(product.imageFileName);
                            return(
                            
                            <CardContainer key={product + index} onClick={() => addHistory(index)}>
                                <ImgBox to={`/shop/product/fileName/${product.imageFileName}`}>
                                    <img src={Nkar}/>
                                </ImgBox>
                                <ContentBox>
                                    <Title>{((lang == 'am') && product?.titleAM) || ((lang == 'ru') && product?.titleRU) || ((lang == 'en') && product?.titleEN)}</Title>
                                    <Price>{product.price + " ₽"}</Price>
                                    <BuyButton to={`/shop/product/fileName/${product.imageFileName}`} element={<ProductStr />}>Buy Now</BuyButton>
                                </ContentBox>
                            </CardContainer>
                        )})}
                    </ProductDivs>
                </>
            )}


        </>
    );
}
