import styled from "styled-components"
import { Link } from "react-router-dom"

export const TitleProd = styled.h2`
  text-align: center;
  padding-top: 50px;
  border-bottom: 3px solid #e5e5e5;
  padding: 50px 0 30px 0;
  width: 95%;
  margin: 0 auto;

`

export const ProductDivs = styled.div`
	display:flex;
	height:auto;
	justify-content: space-around;
	align-items: center;
	flex-wrap: wrap;
	padding: 20px;
	@media(max-width:1184px){
		margin-top:30px;
		height: auto;
		margin-bottom:30px;
		
	};
	@media(max-width:935px){
		margin-top:30px;
		height: auto;
		margin-bottom:30px;		
	}

`
export const ProductForms = styled.div`
	width:22%;
	height:500px;
	border-radius:10px;
	text-align:center;
	padding-top:20px;
	margin-top:20px;
	position:relative;
	border-color:none;
	background-color:white;
	@media(max-width:1184px){
		width: 30%;

	};
	@media(max-width:700px){
		width: 42%;

	};
	@media(max-width: 500px){
		width: 80%;
	}
`
export const ProductTitle = styled.div`
	width: 100%;
	font-weight: bold;
	text-align:center;
	font-size:22px;
`

export const ProductInfo = styled.p`
	margin-top:30px;
	color: black;
`
export const ProductGin = styled.h3`
	color:#5fa36a;
`

export const ProductImgForm = styled.div`
	width:100%;
	height: 220px;
	overflow: hidden;
	position:relative;

`

export const ProductImg = styled.img`
	transition:0.3s;
	cursor:pointer;
	position:absolute;
	    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
	width: 50%;
    margin: auto;

`
export const ButtonAdd = styled.div`
	width:45px;
	height:45px;
	text-align:center;
	line-height:45px;
	border-radius:50%;
	margin-right:20px;
	cursor:pointer;
	position:absolute;
	right:20px;
	bottom:10px;
	color:white;
	transition:0.5s;
	font-weight:800;
	background-color:green;



`


export const CardContainer = styled.div`
  position: relative;
  width: 320px;
  height: 500px;
  background: white;
  border-radius: 30px;
  overflow: hidden;
  margin-top: 20px;

  background: #2b2b36 ;

  &:before {
    content: "";
    position: absolute;
    top: -50%;
    width: 100%;
    height: 100%;
    transform: skewY(345deg);
    background: linear-gradient(270deg, rgba(0,255,119,0.891281512605042) 0%, rgba(64,94,62,1) 100%);
    transition: 0.5s;
  }

  &:hover:before {
    top: -70%;
    transform: skewY(390deg);

  }

  &:after {
    content: "VaheShoop";
    position: absolute;
    bottom: 0;
    left: 0;
    font-weight: 600;
    font-size: 3.5em;
    padding: 0 0 0px 15px;
    color: rgba(0, 0, 0, 0.1);
  }
`;

export const ImgBox = styled(Link)`
  position: relative;
  width: 100%;
  height: 300px;

  display: flex;
  justify-content: center;
  align-items: center;
  padding-top: 20px;
`;

export const Img = styled.img`
  height: 150px;
  width: auto;
  max-width: 100%;
  transition: 0.5s;

  ${CardContainer}:hover & {
    transform: scale(1.1);
  }
`;

export const ContentBox = styled.div`
  position: relative;
  padding: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
`;

export const Title = styled.h3`
  font-size: 18px;
  color: white;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 1px;
`;

export const Price = styled.h2`
  font-size: 24px;
  color: white;
  font-weight: 700;
  letter-spacing: 1px;
`;

export const BuyButton = styled(Link)`
  position: relative;
  top: 100px;
  opacity: 0;
  padding: 10px 30px;
  margin-top: 15px;
  color: white;
  text-decoration: none;
  background: linear-gradient(270deg, rgba(0,255,119,0.891281512605042) 0%, rgba(221,255,113,1) 100%);
  border-radius: 30px;
  text-transform: uppercase;
  letter-spacing: 1px;
  transition: 0.5s;

  ${CardContainer}:hover & {
    top: -10px;
    opacity: 1;
  }
`