import styled from "styled-components"
import { Link } from "react-router-dom";
import Slider from "rc-slider";
import 'rc-slider/assets/index.css';



export const MainDiv = styled.div`
	width:100%;
	min-height: 100vh;
	display: flex;
	padding: 50px;
  @media(max-width: 1130px){
    display: inline;
  }
	
	
`
export const FilterDiv = styled.div`
	width: 400px;
	height: 700px;
	background-color:white;
	margin-top: 40px;
	border-radius: 10px;
	box-shadow: 0px 0px 7px 0px rgba(0,0,0,1);
  @media(max-width: 1130px){
    width: 97%;
    height: 250px;
    display: flex;
    margin: 0 auto;
    position: relative;
  }
  @media(max-width: 839px){
    width: 100%;
    min-height: 200px;
    display: inline;
  }

`

export const PriceDiv = styled.div`
	width: 400px;
	border: none;
	border-bottom:1px solid #e5e5e5 ;
	padding: 30px;
  @media(max-width: 1130px){
    border: none;
	width: 500px;

  }
  @media(max-width: 839px){
    text-align: center;
    justify-content: center;
    width: 100%;
  }
  
`
export const RangeDiv = styled.div`
	padding: 10px;

`
export const SliderStyle = styled(Slider)`
  width: 100%;
`

export const FilterPriceInput = styled.input`
	outline: none;
  border: 1px solid #e5e5e5;
	width: 100px;
	height: 30px;
	border-radius: 10px;
	margin-left: 7px;
  padding: 5px;
`
export const FilterInfoDiv = styled.div`
	height: 100%;
	height: 100px;
	border: none;
	padding: 30px;
	border-bottom:1px solid #e5e5e5 ;
	text-align: left;
  @media(max-width: 1130px){
    border: none;
  }
	
`
export const FilterInfoChackBox = styled.input`

`

export const FilterSerachDiv = styled.div`
  width: 100%;
  height: 100px;
  position: relative;
  padding-left: 20px;
`
export const FilterSearchInput = styled.input`
  width: 90%;
  height: 50px;
  border: none;
  outline: none;
  padding: 10px;
  border-radius: 20px;
  font-size: 25px;
  margin-top: 12px;
	background-color: #e5e3e3;
  @media (max-width: 839px){
    width: 95%;
  }

`

export const FilterSearchIcon = styled.div`
  position: absolute;
  font-size: 30px;
  right: 50px;
  top: 14px;
  cursor: pointer;
  @media(max-width: 1130px){
    right: 13%;
  }
  @media(max-width: 839px){
    right: 10%;
  }
`

export const ProductDivs = styled.div`
	display:flex;
	width: 100%;
	height: 80%;
	height:auto;
	justify-content: space-around;
	align-items: center;
	flex-wrap: wrap;
	padding: 20px;
	@media(max-width:1184px){
		margin-top:30px;
		height: auto;
		margin-bottom:30px;
		
	};
	@media(max-width:935px){
		margin-top:30px;
		height: auto;
		margin-bottom:30px;		
	}

`
export const ScrolDiv = styled.div`


`
export const DefDiv = styled.div`
  display: flex;
  overflow-x: scroll;
  padding-bottom: 10px;
  
  &::-webkit-scrollbar {
        width: 5px;
        height: 5px;
      }
    
      &::-webkit-scrollbar-thumb {
        background-color: #888;
        border-radius: 20px;

      }
    
      &::-webkit-scrollbar-thumb:hover {
        background-color: #333;
      }
    
      &::-webkit-scrollbar-track {
        background-color: white;
      }
`
export const StrDivs = styled.div`
  width: 50%;
  display: flex;
  padding: 10px 30px 10px 30px;
  background-color: #f6f7fb;
  margin-bottom: 30px;
  margin-top: 30px;
  margin-left: auto;
  margin-right: auto;
  border-radius: 20px ;
  justify-content: center;
  @media (max-width: 1000px) {
    width: 90%;
  }
`
;
export const StrDivScrolLeft = styled.div`
 min-width: 30px;
  width: 30px;
  height: 30px;
  background-color: #dbdfec;
  text-align: center;
  border-radius: 50%;
  margin-right: 10px;

  cursor: pointer;
`;

export const StrDivScrolRight = styled.div`
 min-width: 30px;
  width: 30px;
  height: 30px;
  background-color: #dbdfec;
  text-align: center;
  border-radius: 50%;
  cursor: pointer;
  margin-left: 10px;
`;

export const StrDiv = styled.div`
 min-width: 30px;
  width: 30px;
  margin-left: 10px;
  padding-top: 2px;
  height: 30px;
  background-color: ${(props) => props.isActive ? '#5D5D5D' : '#dbdfec'};
  color: ${(props) => props.isActive ? 'white' : 'black'};
  text-align: center;
  border-radius: 50%;
  cursor: pointer;
`;

export const FixedButtons = styled.div`
  position: fixed;
  top: 50%;
  left: 10px;
  transform: translateY(-50%);
`;
export const MyLink = styled(Link)`
	text-decoration: none;
`

export const CardContainer = styled.div`
  position: relative;
  width: 330px;
  height: 500px;
  background: white;
  border-radius: 30px;
  overflow: hidden;
  margin-top: 20px;

  background: #2b2b36 ;

  &:before {
    content: "";
    position: absolute;
    top: -50%;
    width: 100%;
    height: 100%;
    transform: skewY(345deg);
    background: linear-gradient(270deg, rgba(0,255,119,0.891281512605042) 0%, rgba(64,94,62,1) 100%);
    transition: 0.5s;
  }

  &:hover:before {
    top: -70%;
    transform: skewY(390deg);

  }

  &:after {
    content: "VaheShoop";
    position: absolute;
    bottom: 0;
    left: 0;
    font-weight: 600;
    font-size: 3.5em;
    padding: 0 0 0px 15px;
    color: rgba(0, 0, 0, 0.1);
  }
`;

export const ImgBox = styled(Link)`
  position: relative;
  width: 100%;
  height: 300px;

  display: flex;
  justify-content: center;
  align-items: center;
  padding-top: 20px;
`;

export const Img = styled.img`
  height: 150px;
  width: auto;
  max-width: 100%;
  transition: 0.5s;

  ${CardContainer}:hover & {
    transform: scale(1.1);
  }
`;

export const ContentBox = styled.div`
  position: relative;
  padding: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
`;

export const Title = styled.h3`
  font-size: 18px;
  color: white;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 1px;
`;

export const Price = styled.h2`
  font-size: 24px;
  color: white;
  font-weight: 700;
  letter-spacing: 1px;
`;

export const BuyButton = styled(Link)`
  position: relative;
  top: 100px;
  opacity: 0;
  padding: 10px 30px;
  margin-top: 15px;
  color: white;
  text-decoration: none;
  background: linear-gradient(270deg, rgba(0,255,119,0.891281512605042) 0%, rgba(221,255,113,1) 100%);
  border-radius: 30px;
  text-transform: uppercase;
  letter-spacing: 1px;
  transition: 0.5s;
  z-index: 1;

  ${CardContainer}:hover & {
    top: -10px;
    opacity: 1;
  }
`

export const TypesDiv = styled.div`
  border-radius: 20px;
  background-color: white;
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  gap: 10px;
  @media(max-width: 1130px){
    position: absolute;
    bottom: 20px;
    padding: 0 20px;
  }
  @media(max-width: 839px){
    position: static;
  }
`
export const Types = styled.div`
  width: 100px;
  height: 100px;
  border-radius: 20px;
  background-color: ${({ $activ }) => $activ === true ? "#eee" : "white"}; 
  box-shadow: 0px 0px 9px 2px rgba(0,0,0,0.42);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  &:hover{
    background-color: #eee;
  }
  @media (hover: hover) {
    &:hover{
    background-color: #eee;
  }
  }
`

