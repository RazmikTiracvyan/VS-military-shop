import React, { useEffect, useState, useRef } from "react";
import Nkar from "../../img/chapterImg/broni.png"

import {
    CardContainer,
    ImgBox,
    Img,
    ContentBox,
    Title,
    BuyButton,
    Price,
    MainDiv,
    StrDiv,
    StrDivs,
    ProductDivs,
    FilterDiv,
    PriceDiv,
    FilterPriceInput,
    RangeDiv,
    FilterInfoDiv,
    FilterInfoChackBox,
    FilterSerachDiv,
    FilterSearchInput,
    FilterSearchIcon,
    SliderStyle,
    ScrolDiv,
    StrDivScrolLeft,
    StrDivScrolRight,
    DefDiv,
    TypesDiv,
    Types
} from "./styled";
import { FaSearch } from "react-icons/fa";
import { SlArrowLeft } from "react-icons/sl";
import { SlArrowRight } from "react-icons/sl";
import { Basket } from "../../components/basket";
import { useLocation } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { Footer, Header } from "../../components";



export const ProductStr = React.memo(() => {
    const [products, setProducts] = useState([]);
    const [pages, setPages] = useState([]);
    const [paginatedProduct, setPaginatedProduct] = useState([])
    const [range, setRange] = useState([0, 10000000]);
    const [filter, setFilter] = useState(false)
    const [filterInStock, setFilterInStock] = useState(false)
    const [search, setSearch] = useState(false)
    const [activeIndex, setActiveIndex] = useState(null);
    const [lange, setLange] = useState(false);
    const [link, setLink] = useState(false)
    const [user, setUser] = useState()
    const [filterType, setFilterType] = useState({
        clothing: false,
        weapons: false,
        helmets: false,
        watches: false,
        backpacks: false,
        binoculars: false,
    });
    useEffect(() => {
        let link = location?.state?.key
        setLink(link)
        link = link?.toLowerCase()
        setFilterType((e) => ({
            ...e,
            [link]: true
        }));
    }, [])

    const lang = localStorage.getItem('lang') || 'ru';
    const prevLangRef = useRef(lang);
    const newUuid = uuidv4();

    const handleRangeChange = (newRange) => {


        setRange(newRange);
        setFilter(true)
    };

    useEffect(() => {
        const myFetch = async () => {
            try {
                const res = await fetch("https://localhost:7123/api/product");
                const data = await res.json();
                setProducts(data);
                setPaginatedProduct(data.filter((e, i) => {
                    return i >= 0 && i < 10
                }))
                const newPages = [];
                for (let i = 1; i <= (data?.length / 10) + 1; i++) {
                    newPages.push(i);
                }
                setPages(newPages);
            } catch (err) {
                console.log(err);
            }
        };

        myFetch();

    }, []);
    const location = useLocation();



    const myF = async (e, index) => {

        try {
            const req = await fetch("http://localhost:3002/products2", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ number: e })
            });
            const res = await req.json();
            setPaginatedProduct(res);
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            setActiveIndex(index);

        }
        catch (err) {
            console.log(err);
        }
    }
    const inStockChange = () => {
        setFilterInStock((e) => !e);
    }
    const handleInputChange = (e, type) => {
        const newValue = parseInt(e.target.value.replace(/\D/g, ''), 10);

        if (!isNaN(newValue)) {
            if (type === 'min') {
                const newMinValue = Math.min(newValue, range[1]);
                setRange([newMinValue, range[1]]);
                setFilter(true)
            } else {
                const newMaxValue = Math.min(newValue, 10000000);
                setRange([range[0], newMaxValue]);
                setFilter(true)

            }
        } else {
            setRange([0, range[1]]);
        }
    };
    const scrollContainerRef = useRef(null);

    const handleScrollClickToRight = () => {
        if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollLeft += 50;

        }
    }
    const handleScrollClickToLeft = () => {
        if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollLeft -= 50;
        }
    }
    const handleButtonClick = (type, index) => {
        setFilterType((e) => ({
            ...e,
            [type]: !e[type]
        }));
    };
    const typeObj = [
        { text: 'WEAPONS', onclick: () => handleButtonClick('weapons'), activ: filterType.weapons },
        { text: 'CLOTHING', onclick: () => handleButtonClick('clothing'), activ: filterType.clothing },
        { text: 'HELMETS', onclick: () => handleButtonClick('helmets'), activ: filterType.helmets },
        { text: 'WATCHES', onclick: () => handleButtonClick('watches'), activ: filterType.watches },
        { text: 'BACKPACKS', onclick: () => handleButtonClick('backpacks'), activ: filterType.backpacks },
        { text: 'BINOCULARS', onclick: () => handleButtonClick('binoculars'), activ: filterType.binoculars },
    ]
    const token = localStorage.getItem('token')
    useEffect(() => {
        const fetchData = async () => {
            try {
                if (!token) {
                    return;
                }
                const req = await fetch(`http://localhost:3002/profile?token=${token}`)
                const res = await req.json()
                setUser(res.user._id)
            }

            catch (err) {
                console.log(err);
            }
        }
        fetchData()
    }, [])
    const addHistory = async (index) => {

        try {
            if (!token) {
                return;
            }
            const id = products[index]._id
            const req = await fetch(`http://localhost:3002/users/history/${user}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ number: id })
            });



        } catch (err) {
            console.error(err);
        }
    };
    return (
        <>
            <Basket />
            <MainDiv>

                <FilterDiv>
                    <PriceDiv>
                        <FilterPriceInput
                            placeholder="0"
                            value={range[0]}
                            onChange={(e) => handleInputChange(e, 'min')}
                        />
                        -
                        <FilterPriceInput
                            placeholder="10.000.000"
                            value={range[1]}
                            onChange={(e) => handleInputChange(e, 'max')}
                        />
                        <RangeDiv>
                            <label>Цена:</label>
                            <SliderStyle
                                range
                                min={0}
                                max={10000000}
                                step={1}
                                value={range}
                                onChange={handleRangeChange}
                            />

                        </RangeDiv>
                    </PriceDiv>
                    <FilterInfoDiv>
                        <label ><FilterInfoChackBox type="checkbox" onChange={inStockChange} /> Есть в наличии</label>
                    </FilterInfoDiv>
                    <FilterSerachDiv>

                        <FilterSearchInput onChange={(e) => setSearch(e.target.value)} />
                        <FilterSearchIcon>
                            <FaSearch />
                        </FilterSearchIcon>


                    </FilterSerachDiv>
                    <TypesDiv>
                        {typeObj.map((e, i) => {
                            return (<Types $activ={e.activ} onClick={e.onclick}>
                                {e.text}
                            </Types>)
                        })}
                    </TypesDiv>
                </FilterDiv>
                <ProductDivs>

                    {!filter &&
                        !filterInStock &&
                        !search &&
                        !filterType.watches &&
                        !filterType.weapons &&
                        !filterType.binoculars &&
                        !filterType.helmets &&
                        !filterType.backpacks &&
                        !filterType.clothing ? paginatedProduct?.map((e, i) => (
                            <CardContainer key={uuidv4()} onClick={() => addHistory(i)}>
                                <ImgBox to={`/shop/product/fileName/${e.imageFileName}`}>
                                    <Img src={Nkar} alt="mouse corsair" />
                                </ImgBox>
                                <ContentBox>
                                    <Title>{((lang == 'am') && e?.titleAM) || ((lang == 'ru') && e?.titleRU) || ((lang == 'en') && e?.titleEN)}</Title>
                                    <Price>{e.price + " ₽"}</Price>
                                    <BuyButton to={`/shop/product/id/${e._id}`} element={<ProductStr />}>Buy Now</BuyButton>
                                </ContentBox>
                            </CardContainer>
                        ))
                        :
                        products?.filter((e, i) => {
                            return (
                                (e.price > range[0] && e.price < range[1] && (filterInStock ? e.inStock : true)) &&
                                (!search || (e.titleAM && e.titleAM.toLowerCase().includes(search.toLowerCase()))) &&
                                ((!filterType.weapons &&
                                    !filterType.watches &&
                                    !filterType.binoculars &&
                                    !filterType.helmets &&
                                    !filterType.backpacks &&
                                    !filterType.clothing) ||
                                    (filterType.weapons && e.type === "WEAPONS") ||
                                    (filterType.watches && e.type === "WATCHES") ||
                                    (filterType.clothing && e.type === "CLOTHING") ||
                                    (filterType.helmets && e.type === "HELMETS") ||
                                    (filterType.backpacks && e.type === "BACKPACKS") ||
                                    (filterType.binoculars && e.type === "BINOCULARS"))
                            );
                        })
                            .map((e, i) => (

                                <CardContainer key={uuidv4()}>
                                    <ImgBox to={`/shop/product/fileName/${e.imageFileName}`}>
                                        <Img src={Nkar} alt="mouse corsair" />
                                    </ImgBox>
                                    <ContentBox>
                                        <Title>{((lang == 'am') && e?.titleAM) || ((lang == 'ru') && e?.titleRU) || ((lang == 'en') && e?.titleEN)}</Title>
                                        <Price>{e.price + " ₽"}</Price>
                                        <BuyButton to={`/shop/product/fileName/${e.imageFileName}`} element={<ProductStr />}>Buy Now</BuyButton>
                                    </ContentBox>
                                </CardContainer>
                            ))}
                </ProductDivs>


            </MainDiv>
            {!filter &&
                !filterInStock &&
                !search &&
                !filterType.watches &&
                !filterType.weapons &&
                !filterType.binoculars &&
                !filterType.helmets &&
                !filterType.backpacks &&
                !filterType.clothing ?
                <ScrolDiv>



                    <StrDivs>
                        <StrDivScrolLeft onClick={handleScrollClickToLeft}><SlArrowLeft /></StrDivScrolLeft>
                        <DefDiv ref={scrollContainerRef}>
                            {pages?.map((e, i) => (
                                <>
                                    <StrDiv key={uuidv4()} isActive={activeIndex === i} onClick={() => { myF(e, i) }}>{i + 1}</StrDiv>

                                    </>
                                    )
                            )}

                                </DefDiv >
                            <StrDivScrolRight onClick={handleScrollClickToRight}><SlArrowRight /></StrDivScrolRight>

                    </StrDivs>
                </ScrolDiv>

                : null}

        </>
    );
});

