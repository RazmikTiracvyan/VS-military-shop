import React, { useState, useEffect } from "react"
import { EmailInput, EmailInputDiv, ForgetButton, ForgetpasswordDiv, ForgetpasswordForm, IconDiv, InfoDiv, TimerSpan } from "./styled"
import { toast } from "react-toastify";
import { HiMiniPencilSquare } from "react-icons/hi2";
import { useLocation , useNavigate } from 'react-router-dom';
import { Footer, Header } from "../../components";

export const ForgetNewPassword = () => {
    const [value, setValue] = useState("")
    const [password, setPassword] = useState(null)
    const [password2, setPassword2] = useState(null)
    const [isButtonDisabled, setIsButtonDisabled] = useState(false);
    const [timer, setTimer] = useState(
      parseInt(localStorage.getItem('timer')) || 5
    );
    const location = useLocation();
    const navigate = useNavigate()

    const email = location.state?.email || null;
    const code = location.state?.code || null;
    useEffect(() => {
        if(!email || !code){
            navigate('/')
        }
    })
    const sendCode = async () => {
        if(password != password2){
            return toast.warning('Пароль не совпадают')
        }
        if(password.length > 16 || password.length < 8){
            return toast.warning("Пароль должен быть не меньше 8 символов и не больше 16 символов")
        }

        try {
            const req = await fetch('http://localhost:3002/reset-password', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ email: email , code: code , password: password? password : null })
            })

            if (req.status == 400) {
                return toast.warning('Неправильный код восстановления или код истек')
            }
            if (req.ok) {
                toast.success('Пароль успешно восстановлен')
                navigate('/')
            }
        }
        catch (err) {
            toast.error('Пользователь не найден')
            console.log(err);
        }

    }
    let interval;
    const startTimer = () => {
        setIsButtonDisabled(true);
    
        interval = setInterval(() => {
          setTimer(prevTimer => {
            if (prevTimer === 1) {
              clearInterval(interval);
              setIsButtonDisabled(false);
              return 0;
            }
            return prevTimer - 1;
          });
        }, 1000);
      };
      useEffect(() => {
        localStorage.setItem('timer', timer.toString());
    
        return () => clearInterval(interval);
      }, [timer]);
    return (
        <>
            <ForgetpasswordDiv>
                <ForgetpasswordForm>
                    <InfoDiv>
                        <span>Enter you email</span>
                    </InfoDiv>
                    <EmailInputDiv>
                        <EmailInput disabled placeholder="email" value={email} style={{opacity:"0.7"}}/>
                        <EmailInput disabled placeholder="email" value={code} style={{opacity:"0.7"}}/>
                      
                    </EmailInputDiv>
                    <EmailInput onChange={(e) => setPassword(e.target.value)} placeholder="new password"/>
                    <EmailInput onChange={(e) => setPassword2(e.target.value)} placeholder="repeat password"/>
                    <ForgetButton onClick={sendCode}>Send code</ForgetButton>
                    <br /><TimerSpan>Подождите {timer} секунд перед следующей попыткой</TimerSpan>
                </ForgetpasswordForm>
            </ForgetpasswordDiv>
        </>
    )
}