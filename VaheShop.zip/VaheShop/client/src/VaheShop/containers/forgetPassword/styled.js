import styled from "styled-components";


export const ForgetpasswordDiv = styled.div`
    width: 100%;
    min-height: 100vh;
    background-color: white;
    padding: 100px 20px;
`
export const ForgetpasswordForm = styled.div`
    width: 400px;
    min-height: 300px;
    background-color:#eee;
    margin: auto;
    border-radius: 15px;
    padding: 20px;
    text-align: center;
    @media(max-width: 500px){
        width: 100%;
    }
`

export const InfoDiv = styled.div`
    width: 100%;
    padding: 20px;
    color: #999;
    font-size: 22px;
    text-align: center;

`

export const EmailInputDiv = styled.div`
    position: relative;
`
export const IconDiv = styled.div`
    position: absolute;
    top: 26px;
    right: 20px;
    font-size: 25px;
    @media(max-width: 500px){
        font-size: 20px;
        top: 32px;
    }
    
`

export const EmailInput = styled.input`
    width: 100%;
    height: 40px;
    padding: 10px;
    border-radius: 10px;
    background-color: white;
    border: none;
    outline: none;
    margin-top: 30px;
    opacity: ${({$confirm}) => $confirm ? "0.6" : "1"};
`

export const ForgetButton = styled.button`
	width: 200px;
	height: 40px;
	border-radius:30px;
	border: none;
	font-size: 19px;
	transition: 0.5s;
	background-color: #5cb85c;
    color: white;
    margin-top: 30px;

	&:hover{
        box-shadow: rgb(38, 57, 77) 0px 10px 15px -5px;
        transform: scale(1.05); 

	}
 

	@media(max-width:300px){
		width:100%
	}
    `

    export const TimerSpan = styled.div`
        padding: 30px 0 0 0;
    `
