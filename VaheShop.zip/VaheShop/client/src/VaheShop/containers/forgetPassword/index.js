import React, { useState, useEffect } from "react"
import { EmailInput, EmailInputDiv, ForgetButton, ForgetpasswordDiv, ForgetpasswordForm, IconDiv, InfoDiv, TimerSpan } from "./styled"
import { toast } from "react-toastify";
import { HiMiniPencilSquare } from "react-icons/hi2";
import { useNavigate } from "react-router-dom";
import { Footer, Header } from "../../components";
export const Forgetpassword = () => {
    const [value, setValue] = useState("")
  
    const location = useNavigate()
    useEffect(() => {
        localStorage.getItem("token") && location('/')
    } , [])
    const sendCode = async () => {
        if (value.length == 0) {
            return toast.warning('Запаолните поле')
        }
        try {
            const req = await fetch('http://localhost:3002/forgot-password', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ email: value })
            })

            if (req.status == 404) {
                return toast.warning('Почта не зарегистрирована')
            }
            if (req.ok) {
                toast.success('Код восстановления отправлен на вашу почту')
                location('/forgetpassword/code' , {state : value})
            }
        }
        catch (err) {
            toast.error('Пользователь не найден')
            console.log(err);
        }

    }
    
    return (
        <>
            <ForgetpasswordDiv>
                <ForgetpasswordForm>
                    <InfoDiv>
                        <span>Enter you email</span>
                    </InfoDiv>
                    <EmailInputDiv>
                        <EmailInput placeholder="email" onChange={(e) => setValue(e.target.value)} />

                    </EmailInputDiv>
                    <ForgetButton onClick={sendCode}>Send code</ForgetButton>
                </ForgetpasswordForm>
            </ForgetpasswordDiv>
        </>
    )
}