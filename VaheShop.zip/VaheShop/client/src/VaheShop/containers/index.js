import { Product } from "./productPage/index.js"
import { Contact } from "./contact"
import { UserPage } from "./profile/index.js"
import { MyRewievPage } from "./rewiev/index.js"
import { Forgetpassword } from "./forgetPassword/index.js"
import { ForgetpasswordCode } from "./forgetPasswordCode"
import { ForgetNewPassword } from "./NewPassword"

export { Product, Contact, UserPage, MyRewievPage, Forgetpassword, ForgetpasswordCode , ForgetNewPassword }