import styled from "styled-components";

export const MainDiv = styled.div`
    width: 100%;
    display: flex;  
    background-color: #f0f0f0;
    @media(max-width:1078px){
        display: inline;
    }
`
export const TitleDiv = styled.div`
    width: 100%;
    height: 60px;
    padding: 10px 0px 0px 50px;
    background-color: #f0f0f0;


`
export const DivInfo = styled.div`
    width: 70%;
    min-height: 500px;
    background-color: white;
    display: flex;
    border-radius: 20px;
    padding: 5px;

    @media(max-width:1078px){
        width: 100%;
    }
    @media(max-width:786px){
        display: inline;
        width: 90%;
    }

`
export const DivInfoImg = styled.div`
    width: 60%;
    margin-left: 50px;
    min-height: 500px;
    background-color:white;
    display: flex;
    justify-content: center;
    border-right: 1px solid #e5e5e5;
    @media(max-width:1078px){
        min-height: 200px;
    }
    @media(max-width:786px){
        border:none;
        width: 100%;
    padding-bottom: 50px;

    }
    @media(max-width:474px){
        width: 80%;
    }
   
  
`

export const InfoText = styled.div`
    width: 90%;
    min-height: 500px;
    background-color: white;
    justify-content: center;
    padding: 20px;
   
    @media(max-width:1078px){
        min-height: 200px;
        width: 100%;
    }
    @media(max-width:786px){
        min-height: 150px;

    }

`



export const Img = styled.img`
    height: 250px;
    @media(max-width: 1118px){
        height: 200px;
    }
    @media(max-width:1078px){
        height: 320px;
    }
    @media(max-width:1078px){
        height: 250px;
    }
    @media(max-width:442px){
        height: 150px;
    }
    @media(max-width:394px){
        height: 120px;
    }
    
    
`



export const InfoTextDivs1 = styled.div`
    width:100%;
    min-height: 40px;
    background-color: white;
    border: 1px solid #e5e5e5;
    display: flex;
    


    
`
export const InfoTextDivs2 = styled.div`
    width:100%;
    min-height: 40px;
    background-color: #f2f2f2;
    border: 1px solid #e5e5e5;
    display: flex;

    
`

export const InfoTextSpanKey = styled.div`
    width: 150px;
    height: auto;
    margin-top: auto;
    margin-bottom: auto;
    word-wrap: break-word;
    padding-left: 10px;

    

`
export const InfoTextSpanValue = styled.div`
    width: 60%;
    height: auto;
    margin-top: auto;
    margin-bottom: auto;
    word-wrap: break-word;

`


export const KeySpan = styled.span`
    font-family: 'Helvetica Neue', Arial, sans-serif;
    font-size: 13px;
    color: #4D4D4D;

`

export const ValueSpan = styled.span`
`

export const BuyDiv = styled.div`
    width: 25%;
    min-height: 500px;
    margin-left: 70px;
    border-radius: 20px;
    @media(max-width:1078px){
        min-height: 350px;
        margin-left: auto;
        margin-right: auto;
    }
    @media(max-width:786px){
        width:300px;
        margin-left: auto;
        margin-right: auto;
    }
`

export const BuyDivInfo = styled.div`
    text-align: center;
    width: 100%;
    background-color: white;
    padding: 25px;
    border-radius: 20px;


`

export const BuyDivInStock = styled.div`
    border-left: none;
    border-right: none;
    width: 100%;
    height: 60px;
    padding: 12px;
    background-color: white;
`

export const InStockText = styled.span`
    color: #0a0;
`
export const InStockTextNo = styled.span`
    color: red;
`

export const BuyDivButton = styled.button`
	width: 80%;
	height: 40px;
	margin-top:30px;
	border-radius:50px;
	border:none;
	font-size: 19px;
	transition: 0.5s;
	background-color: #5cb85c;
	&:hover{
	box-shadow: rgb(38, 57, 77) 0px 10px 15px -5px;
	transform: scale(1.05);	};
	@media(max-width:270px){
		font-size:11px;
	}
`