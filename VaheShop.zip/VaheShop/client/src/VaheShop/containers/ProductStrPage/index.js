import React, { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import { BuyDiv, BuyDivInfo, DivInfo, DivInfoImg, Img, InfoText, InfoTextDivs1, InfoTextDivs2, InfoTextSpanKey, InfoTextSpanValue, KeySpan, MainDiv, TitleDiv, ValueSpan, BuyDivInStock, InStockText, BuyDivButton, InStockTextNo } from "./styled";
import { MdOutlineDoneAll } from "react-icons/md";
import { RxCross1 } from "react-icons/rx";
import { toast } from "react-toastify";
import { Basket } from "../../components/basket";
import Nkar from "../../img/chapterImg/broni.png"
import { Header, Footer } from "../../components";

export const ProductStrPage = () => {
    const [product, setProduct] = useState();
    const [lange, setLange] = useState(false);
    const { fileName } = useParams();
    const lang = localStorage.getItem('lang') || 'ru';
    const token = localStorage.getItem('token')
    const [user, setUser] = useState()
    const [prod, setProd] = useState()

    useEffect(() => {
        const fetchData = async () => {
            try {
                const req = await fetch(`https://localhost:7123/api/product/${fileName}`);
                const res = await req.json();
                setProduct(res);
                console.log(res);
            } catch (err) {
                console.log(err);
            }
        };

        fetchData();

    }, [fileName]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                if (!token) {
                    console.error('Token not found');
                    return;
                }
                const req = await fetch(`http://localhost:3002/profile?token=${token}`)
                const res = await req.json()
                setUser(res.user._id)
            }

            catch (err) {
                console.log(err);
            }
        }
        fetchData()
    }, [])

    const addBasket = async (id) => {

        try {
            if (!token) {
                console.error('Token not found');
                return;
            }
            const req = await fetch(`http://localhost:3002/users/basket/${user}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ number: id })
            });

            const res = await req.json();
            setProd(res.id)
            if (req.status == 400) {
                return toast.error('Продукт уже добавлен в корзину')
            }
            if (req.ok) {
                setLange((e) => !e)
                toast.success('Товар успешно добавлен в карзину')
            } else return toast.error('Ошибка')

        } catch (err) {
            console.error(err);
        }
    };
    return (
        <>
            <Basket lange={lange} />
            <TitleDiv>
                <h1>{product?.title}</h1>
            </TitleDiv>
            {product ? <MainDiv>

                <DivInfo>
                    <DivInfoImg>
                        <Img src={Nkar} />
                    </DivInfoImg>
                    <InfoText>
                        <InfoTextDivs1>
                            <InfoTextSpanKey>
                                <KeySpan>Модель</KeySpan>
                            </InfoTextSpanKey>
                            <InfoTextSpanValue>
                                <ValueSpan>{lang === 'am' && product?.titleAM || lang == 'ru' && product?.titleRU || lang == 'en' && product?.titleEN}</ValueSpan>
                            </InfoTextSpanValue>
                        </InfoTextDivs1>
                        <InfoTextDivs2>
                            <InfoTextSpanKey>
                                <KeySpan>Цена</KeySpan>
                            </InfoTextSpanKey>
                            <InfoTextSpanValue>
                                <ValueSpan>{product?.price}֏</ValueSpan>
                            </InfoTextSpanValue>
                        </InfoTextDivs2>
                        <InfoTextDivs1>
                            <InfoTextSpanKey>
                                <KeySpan>О прадукте</KeySpan>
                            </InfoTextSpanKey>
                            <InfoTextSpanValue>
                                <ValueSpan>{((lang == 'am') && product?.descriptionAM) || ((lang == 'ru') && product?.descriptionRU) || ((lang == 'en') && product?.descriptionEN)}</ValueSpan>
                            </InfoTextSpanValue>
                        </InfoTextDivs1>
                        <InfoTextDivs2>
                            <InfoTextSpanKey>
                                <KeySpan>Статус</KeySpan>
                            </InfoTextSpanKey>
                            <InfoTextSpanValue>
                                {product.inStock ? <InStockText> Есть в наличии  <MdOutlineDoneAll /> </InStockText> : <InStockTextNo>Товар закончился <RxCross1 /></InStockTextNo>}
                            </InfoTextSpanValue>
                        </InfoTextDivs2>
                    </InfoText>
                </DivInfo>

                <BuyDiv>
                    <BuyDivInfo>
                        <h2>{product?.title}</h2>
                        <KeySpan>цена</KeySpan>
                        <h2>{product?.price} ֏</h2>
                        <KeySpan>скидка</KeySpan>
                        <h4>{product?.price * 80 / 100} ֏</h4>
                        <KeySpan>За месяц</KeySpan>
                        <h4>{Math.ceil(product?.price / 12)} ֏</h4>

                        <BuyDivInStock>
                            {product.inStock ? <InStockText> Есть в наличии  <MdOutlineDoneAll /> </InStockText> : <InStockTextNo>Товар закончился <RxCross1 /></InStockTextNo>}

                        </BuyDivInStock>
                        <BuyDivButton onClick={() => addBasket(product._id)}>Добавить в карзину</BuyDivButton>
                    </BuyDivInfo>

                </BuyDiv>
            </MainDiv> : <p>loading user data</p>}
        </>
    )
}