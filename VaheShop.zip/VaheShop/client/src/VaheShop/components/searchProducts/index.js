import React, { useEffect, useState } from "react";
import { FilterSearchIcon, FilterSearchInput, FilterSerachDiv, Img, LinkTo, ProductInfoDiv, RamkaSigns, SearchProductDiv } from "./styled";
import { FaSearch } from "react-icons/fa";
import { Link } from "react-router-dom";

export const SearchProducts = () => {
  const [openSearchDiv, setOpenSearchDiv] = useState(false);
  const [value, setValue] = useState('');
  const [products, setProducts] = useState([]);

  useEffect(() => {
    if (value === "") {
      setOpenSearchDiv(false);
    } else {
      setOpenSearchDiv(true);
    }
  }, [value]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const req = await fetch("http://localhost:3002/productsfilter");
        const res = await req.json();
        setProducts(res);
      } catch (err) {
        console.log(err);
      }
    };

    fetchData();
  }, []);

  const closeSearch = () => {
    setValue('')
  }

  return (
    <>
      {openSearchDiv && <RamkaSigns onClick={closeSearch}/>}

      <FilterSerachDiv>

        <FilterSearchInput onChange={(e) => setValue(e.target.value)} value={value}/>
        <FilterSearchIcon>
          <FaSearch />
        </FilterSearchIcon>
        {openSearchDiv && (
          <ProductInfoDiv>
            {products
              .filter((e) => e.titleAM && e.titleAM.toLowerCase().includes(value.toLowerCase()))
              .map((e, i) => (
                <LinkTo key={i} to={`/shop/product/id/${e._id}`} onClick={closeSearch}>
                <SearchProductDiv>
                  <p>{e.title}</p>
                  <Img src={`http://localhost:3002/uploads/${e.img}`} alt={e.title} />
                  <p>Цена - {e.price}</p>

                </SearchProductDiv>
                </LinkTo>
              ))}
           <p>Продукт больше нет</p>

          </ProductInfoDiv>
        )}
      </FilterSerachDiv>
    </>
  );
};
