import styled from "styled-components"


export const QuestionForm = styled.form`
	width:100%;
	height:300px;
	margin-left:20px;
		
`

export const FormInputs = styled.input`
	width: 80%;
	height: 40px;
	margin-top:10px;
	padding-left: 5px;
	border:none;
	border-radius:0;
	background-color: #e5e3e3;
	outline:none;
	@media(max-width:400px){
		font-size:12px;
	}
`

export const FormQuestion = styled.textarea`
	width: 80%;
	height:100px;
	background-color: #e5e3e3;
	border:none;
	padding-top:5px;
	resize: none;
	padding-left:5px;
	margin-top:15px;
	outline:none;
	@media(max-width:400px){
		font-size:12px;
	}
`


export const FormButton = styled.button`
	width: 30%;
	height: 40px;
	margin-top:35px;
	border-radius:50px;
	transition: 0.5s;
	background-color:#5cb85c;
	border:none;
	color:white;
	&:hover{
	box-shadow: rgb(38, 57, 77) 0px 10px 20px -10px;
	transform:scale(1.1);
	}
	@media(max-width:722px){
		width:80%;
	};
	@media(max-width:300px){
		font-size:12px;
	}
`


export const ErrorMessage = styled.div`
	width: 100%;
	height:20px;
	color: red;
	font-size: 13px;
	padding-top:10px;

`

export const EmailForm = styled.form`
	width:40%;
    @media(max-width:943px){
        width:100%;
    }
    @media(max-width:315px){
        height:120px;
    }
    @media(max-width:726px){
        margin-top:100px;
    }
`
export const FooterTitle = styled.span`
    font-weight: bold;   
    margin-left:20px;
`




export const EmailInput = styled.input`
    height:40px;
    width:250px;
    border:none;
    outline:none;
    background-color: #e5e3e3;
	border-radius: 50px;
    margin-top:10px;
    margin-left:20px;
    padding-left:10px;
    border-top-right-radius:0;
    border-bottom-right-radius:0;
     @media(max-width:943px){
        width:60%;
    }
    @media(max-width:726px){
        width:65%;
        border-radius:0;
        margin-left:20px;

    }
        @media(max-width:372px){
    font-size:11px;

    }

`
export const ErrorMessageMail = styled.div`
	width: 100%;
	color: red;
	font-size: 13px;
	margin-left:20px;

`

export const EmailButton = styled.button`
    width: 100px;
    height: 40px;
    border-radius:50px;
	transition: 0.5s;
    background-color:#5cb85c;
    border:none;
    color:white;
    border-top-left-radius:0;
    border-bottom-left-radius:0;
    &:hover{
    opacity:0.8;
    };
    @media(max-width:726px){
        width:27%;
        border-radius:0;
    }
    @media(max-width:372px){
    font-size:9px;

    }

`

export const ButText = styled.span`
	font-size: 12px;
	padding: auto;
`