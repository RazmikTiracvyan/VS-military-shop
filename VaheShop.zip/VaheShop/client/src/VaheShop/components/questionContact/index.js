// Ваш файл с компонентами

import React from 'react';
import { useForm } from 'react-hook-form';
import EmailValidator from 'email-validator';
import { useValidation, yupResolver } from '../../validations/questionValidation';
import { QuestionForm, FormInputs, FormQuestion, FormButton, ErrorMessage, EmailForm, FooterTitle, EmailInput, EmailButton, ErrorMessageMail, ButText } from './styled';
import { useTranslation } from 'react-i18next';

export const QuestionCntact = () => {
  const { t } = useTranslation();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(useValidation()),
  });

  return (
    <>
      <QuestionForm onSubmit={handleSubmit((data) => console.log(data))}>
        <ErrorMessage>{errors.name ? errors.name : null}</ErrorMessage>
        <FormInputs
          placeholder={t("name")}
          type="text"
          {...register('name', {
            required: true,
          })}
        />
        <ErrorMessage>{errors.email ? errors.email : null}</ErrorMessage>
        <FormInputs
          placeholder={t("mail")}
          {...register("email", {
            required: true,
            validate: {
              email: (value) => EmailValidator.validate(value)
            }
          })}
        />
        <ErrorMessage>{errors.textarea ? errors.textarea : null}</ErrorMessage>
        <FormQuestion
          placeholder={t("message")}
          {...register('textarea', {
            required: true
          })}
        />
        <FormButton>{t("send")}</FormButton>
      </QuestionForm>
    </>
  );
};

export const InputEmail = () => {
  const { t } = useTranslation();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(useValidation()),
  });

  return (
    <>
      <EmailForm onSubmit={handleSubmit((data) => console.log(data))}>
        <FooterTitle>{t("subEmail")}</FooterTitle><br />
        <ErrorMessageMail>{errors.email ? errors.email : null}</ErrorMessageMail>
        <EmailInput
          placeholder={t("subEmailP")}
          {...register("email", {
            required: true,
            validate: {
              email: (value) => EmailValidator.validate(value)
            }
          })}
        />
        <EmailButton><ButText>{t("subSend")}</ButText></EmailButton>
      </EmailForm>
    </>
  );
};
