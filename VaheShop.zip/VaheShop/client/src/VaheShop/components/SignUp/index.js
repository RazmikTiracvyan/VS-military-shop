import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import EmailValidator from 'email-validator';
import { useValidation, yupResolver } from '../../validations/signUpValidation';
import { useTranslation } from 'react-i18next'
import { useNavigate } from "react-router-dom"
import { IoEyeSharp } from "react-icons/io5";
import { FaEyeSlash } from "react-icons/fa";
import { toast } from "react-toastify";


import {
	SignUpDiv,
	SignUpForms,
	FormH1,
	For2Inputs,
	InputsInForm,
	ButtonInForm,
	CheckBoxDivs,
	CheckBoxes,
	LabelForCheckBoxes,
	CheckBoxSpan,
	ErrorMessage,
	ShowPassword
} from './styled';

export const FormSignUp = ({ value, setValue }) => {
	const { t } = useTranslation()


	const location = useNavigate();

	const {
		register,
		handleSubmit,
		formState: { errors },
	} = useForm({
		resolver: yupResolver(useValidation()),
	});

	const onSubmit = async (data) => {
		try {
			setValue(true)
			console.log(data);
			const req = await fetch("http://localhost:3002/register", {
				method: "POST",
				headers: {
					"Content-Type": "application/json"
				},
				body: JSON.stringify(data)
			})
			console.log(req.status);
			if(req.status == 200){
				setValue(false)
			}
			if(req.status == 401){
				return toast.error('Такая почта уже существует!')
			}
			const res = await req.json();
			console.log(res);
			//location(`/profile/token/${localStorage.getItem('token')}`, { state: { user: res.user, token: res.token } })
			toast.success('Вы успешно зраегистрировались!')
			setTimeout(() => {
				toast.success('Для входа в ваш аккаунт требуется подверждение эл.почты!')
			} , 4000)
			
		}
		catch (err) {
			console.log(err);
		}
	};

	const [showPass , setShowPass] = useState(false)
	const ShowPas = () => {
		setShowPass((e) => !e)
	}
	return (
		<>
			<SignUpDiv>
				<SignUpForms onSubmit={handleSubmit(onSubmit)}>
					<FormH1>{t("sUpTitle")}</FormH1>
					<For2Inputs>
						<ErrorMessage>{errors.name ? errors.name : null}</ErrorMessage>
						<InputsInForm
							type="text"
							placeholder={t("sUpName")}
							{...register('name', {
								required: true,
							})}
						/>
					</For2Inputs>
					<For2Inputs>
						<ErrorMessage>{errors.lastName ? errors.lastName : null}</ErrorMessage>
						<InputsInForm placeholder={t("sUpSurname")}
							{...register("lastName", {
								required: true
							})}
						/>
					</For2Inputs>
					<For2Inputs>
						<ErrorMessage>{errors.email ? errors.email : null}</ErrorMessage>
						<InputsInForm placeholder={t("sUpMail")}
							{...register("email", {
								required: true,
								validate: {
									email: (value) => EmailValidator.validate(value)
								}
							})}
						/>
					</For2Inputs>
					<For2Inputs>
						<ErrorMessage>{errors.password ? errors.password : null}</ErrorMessage>
						<InputsInForm placeholder={t("sUpPass")} type={showPass? "text" : "password"}
							{...register("password")}
						/>
						<ShowPassword onClick={ShowPas}>{showPass ? <IoEyeSharp /> : <FaEyeSlash />}</ShowPassword>
					</For2Inputs>
					<For2Inputs>
						<CheckBoxDivs>
							<LabelForCheckBoxes>
								<CheckBoxes
									type="checkbox"
									{...register('ageCheck', {
										required: 'Обязательно для выбора',
									})}
								/>
								<CheckBoxSpan err={errors.ageCheck}>{t("sUpC1")}</CheckBoxSpan>
							</LabelForCheckBoxes>
						</CheckBoxDivs>
						<CheckBoxDivs>
							<LabelForCheckBoxes>
								<CheckBoxes
									type="checkbox"
									{...register('privacyCheck', {
										required: true,
									})}
								/>
								<CheckBoxSpan err={errors.privacyCheck}>{t("sUpC2")}</CheckBoxSpan>
							</LabelForCheckBoxes>
						</CheckBoxDivs>
					</For2Inputs>
					<For2Inputs>
						<ButtonInForm>{t("sUpReg")}</ButtonInForm>
					</For2Inputs>


				</SignUpForms>
			</SignUpDiv>
		</>
	);
};
