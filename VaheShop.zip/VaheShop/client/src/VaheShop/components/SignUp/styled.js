import styled from "styled-components"

export const SignUpDiv = styled.div`
	width:100%;
	height:500px;	
`
export const SignUpForms = styled.form`
	width:100%;
	height:500px;
	position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    margin: auto;
    `
export const FormH1 = styled.h5`
	padding-top:10px;
	text-align: center;
	@media(max-width:336px){
		font-size:15px;
	};
	@media(max-width:248px){
		font-size:10px;
	}
`

export const For2Inputs = styled.div`
	width:100%;
	height:60px;
	display: flex;
	flex-wrap: wrap;
	justify-content: center;
`

export const InputsInForm = styled.input`
	width: 80%;
	height: 40px;
	border-radius:50px;
	padding-left: 10px;
	background-color: #e5e3e3;
	border: none;
	outline: none;
	@media(max-width:302px){
		font-size:10px;
	};
	@media(max-width:182px){
		font-size:8px;
	}
`
export const ButtonInForm = styled.button`
	width: 80%;
	height: 40px;
	margin-top:50px;
	border-radius:50px;
	border:none;
	font-size: 19px;
	transition: 0.5s;
	background-color: #5cb85c;
	&:hover{
	box-shadow: rgb(38, 57, 77) 0px 10px 15px -5px;
	transform: scale(1.05);	};
	@media(max-width:270px){
		font-size:11px;
	}
`

export const CheckBoxDivs = styled.div`
	width: 100%;
	height: 40px;
	font-size: 19px;
	padding-left: 10%;
	display: flex;
	align-items: center;
	padding-top:15px;

`

export const CheckBoxes = styled.input`
	width:18px;
	height:18px;
`

export const CheckBoxSpan = styled.span`
	position: relative;
	color:${({err})=>err?"red":"black"};
	top: -5px;
	font-size:15px;
	margin-left:5px;
	@media(max-width:402px){
		font-size:11px;
	}
`

export const LabelForCheckBoxes = styled.label`
margin-top: 20px;
`

export const ErrorMessage = styled.div`
	width: 100%;
	height:30px;
	color: red;
	padding-top: 8px;
	font-size: 13px;
	padding-left:10%;
	@media(max-width:298px){
		font-size:10px;
	};
	@media(max-width:226px){
		font-size:8px;
	}
	
`
export const SignIn = styled.div`
	margin-top:20px;
	font-size:20px;	
`
export const SignInLink = styled.a`
	cursor:pointer;
`

export const ShowPassword = styled.span`
position: absolute;
right: 80px;
top: 260px;
cursor: pointer;
@media(max-width: 347px){
	top:255px
};
@media(max-width: 246px){
	top:250px
}
`