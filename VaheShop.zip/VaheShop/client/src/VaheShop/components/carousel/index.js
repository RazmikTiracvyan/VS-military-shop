
import img1 from '../../img/1.png'
import img2 from '../../img/2.png'
import img3 from '../../img/3.png'
import Carousel from 'react-bootstrap/Carousel';
import 'bootstrap/dist/css/bootstrap.min.css';
import {ImgCarousel} from './styled'

function UncontrolledExample() {
  return (
    <>
  <section>
 <Carousel data-bs-theme="dark" style={{zIndex:"0"}}>
      <Carousel.Item>
        <ImgCarousel
          className="d-block w-100"
          src={img1}
          alt="First slide"
        />
        <Carousel.Caption>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <ImgCarousel
          className="d-block w-100"
          src={img2}
          alt="Second slide"
        />
        <Carousel.Caption>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <ImgCarousel
          className="d-block w-100"
          src={img3}
          alt="Third slide"
        />
        <Carousel.Caption>
         
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  </section>	
  	</>
  	)
}

export default UncontrolledExample;