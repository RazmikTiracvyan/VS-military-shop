import styled from "styled-components"


export const ImgCarousel = styled.img`
	width:auto;
	height:auto;
`