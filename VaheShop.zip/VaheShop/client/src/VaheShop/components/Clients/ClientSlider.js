import React from 'react'
import styled from 'styled-components'
import {IoIosQuote} from "react-icons/io";
import { FaStar } from "react-icons/fa";

const ClientSlider = (props) => {
    const {name, lastName , position, img_url, stars, disc} = props.item;
  return (
    <Container>
        <Header>
            <span className='quote'><IoIosQuote/></span>
            <div>
                {Array(stars).fill()?.map((_, i) => (
                    <span className='star' key={i}>
                        <FaStar/>
                    </span>
                ))}
            </div>
        </Header>
        <Body>
            {position}
        </Body>
        <Footer>
            <ImgDiv>
            <img src={img_url ? img_url:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRir06bApyiBCEsxHMGNWtcxEZGCLYj5vdcxQ&usqp=CAU"} alt={name} />
            </ImgDiv>
            <BodyDiv className="details">
                <h1>{name } {lastName}</h1>
                <p>{disc}</p>
            </BodyDiv>
        </Footer>
    </Container>
  )
}

export default ClientSlider

const ImgDiv = styled.div`
    padding-bottom: 150px;
`

const Container = styled.div`
    background: linear-gradient(159deg, rgb(45, 45, 58) 0%, rgb(43, 43, 53) 100%);
    padding: 1.5rem 1rem;
    margin: 0 1rem;
    border-radius: 20px;
`
const BodyDiv = styled.div`
overflow: auto;
white-space: pre-wrap;
width: 68%;
height: 250px;
&::-webkit-scrollbar {
    width: 5px;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #888;
  }

  &::-webkit-scrollbar-thumb:hover {
    background-color: #333;
  }

  &::-webkit-scrollbar-track {
    background-color: #555;
  }
`
const Header = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    .quote{
        font-size: 3rem;
        color: #01be96;
        opacity: 0.7;
    }

    .star{
        color: #ffcd3c;
        font-size: 1.3rem;
    }
`
const Body = styled.p`
    font-size: 0.8rem;
    margin-bottom: 1.5rem;
`
const Footer = styled.div`
    display: flex;
    align-items: center;
    gap: 1rem;
    img{
        width: 4rem;
        height: 4rem;
        border-radius: 50px;
        object-fit: cover;
    }

    h1{
        font-size: 1.2rem;
        font-weight: 700;
        @media(max-width: 580px){
            font-size: 1rem;
        }
        @media(max-width: 538px){
            font-size: 0.9rem;
        }
    }

    p{
        font-size: 0.8rem;
        color: rgba(255,255,255,0.500);
        @media(max-width: 538px){
            font-size: 0.6rem;
        }
    }
`