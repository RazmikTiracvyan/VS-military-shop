import React, { useEffect, useState } from "react";
import {
  MenuBar,
  MenuDivs,
  MenuLinks,
  ProfileIcon,
  ProfileDiv,
  MenuSignUp,
  SignUpDivForm,
  CloseSignUp,
  SignInDiv,
  SignInLink,
  MenuDropDownIcon,
  ResponsiveMenu,
  ResponsiveMenuButton,
  RamkaSigns,
  CloseResMenu,
  LanguageDiv,
  HeaderLanguage,
  LanguageRamka,
  LangImg,
  LangText,
  LogoImg,
  ProfileLink,
  MenuResLinks,
  ProfuleName,
  RamkaSignsWhite,
  ProfileInfo,
  ProfileLinks,
  MenuDiv,
  LanguageRamkaRes,
  HeaderLanguageRes,
  LanguageDivRes,
  LangTextRes,
  LangImgRes,
} from "./styled";
import { FormSignUp, SignInForm } from "../index";
import { RxDropdownMenu } from "react-icons/rx";
import { IoMdSettings } from "react-icons/io";
import { CgProfile } from "react-icons/cg";
import { HiMiniShoppingCart } from "react-icons/hi2";
import { FaShoppingBasket } from "react-icons/fa";
import { TbLogout } from "react-icons/tb";
import { Link, useNavigate } from "react-router-dom";
import i18n, { use } from "i18next";
import { useTranslation } from "react-i18next";
import { SearchProducts } from "../searchProducts";
import imgLogo from "../../img/logo.png";
import am from "../../img/lang/am.png";
import ru from "../../img/lang/ru.png";
import en from "../../img/lang/en.png";
export const Header = () => {
  const location = useNavigate();
    const [selectedLanguage, setSelectedLanguage] = useState(
      localStorage.getItem("lang") || "ru"
    );
  const [selectLangImg, setSelectLangImg] = useState(
    localStorage.getItem("src") || ru
  );
  let [profileOpen, setProfileOpen] = useState(false);
  let [signUpOpen, setSignUpOpen] = useState(false);
  let [signInOpen, setSignInOpen] = useState(false);
  let [menuIsOpen, setMenuIsOpen] = useState(false);
  let [openLang, setOpenLang] = useState(false);
  const [user, setUser] = useState({});

  const [menuLinks, setMenuLinks] = useState([
    { pathname: "/", name: "home", active: true },
    { pathname: "/shop", name: "Shop", active: false },
    { pathname: "/contact", name: "Contact", active: false },
  ]);

  const { t } = useTranslation();

  const languages = [
    { code: "am", name: "AM", src: `${am}` },
    { code: "ru", name: "RU", src: `${ru}` },
    { code: "en", name: "EN", src: `${en}` },
  ];

  const MyProfileOpen = () => {
    setProfileOpen((profileOpen = !profileOpen));
  };

  const signUpDiv = () => {
    setSignUpOpen(true);
    setMenuIsOpen(false);
  };

  const myChangeToUp = () => {
    setSignUpOpen(true);
    setSignInOpen(false);
  };

  const myChangeToIn = () => {
    setSignUpOpen(false);
    setSignInOpen(true);
  };

  const openResMenu = () => {
    setMenuIsOpen((e) => !e);
  };
  const closeForm = () => {
    setSignUpOpen(false);
    setSignInOpen(false);
    setProfileOpen(false);
    setMenuIsOpen(false);
  };

  const handleSelectLang = (code, src) => {
    setSelectedLanguage(code);
    localStorage.setItem("lang", code);
    localStorage.setItem("src", src);
    i18n.changeLanguage(code);
    setOpenLang(!openLang);
    setSelectLangImg(src);
    setOpenLang(!openLang);
    window.location.reload();
  };
  const token = localStorage.getItem("token");

  const menuColor = (e, i) => {
    let x = menuLinks.slice();
    x.map((element, indexes) => {
      if (indexes === i) element.active = true;
      else element.active = false;
    });
    setMenuLinks(x);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const req = await fetch(`http://localhost:3002/profile?token=${token}`);
        const res = await req.json();
        setUser(res.user);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, [localStorage.getItem("token")]);

  const logOut = async () => {
    try {
      const req = await fetch(`http://localhost:3002/logout?token=${token}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const res = await req.json();

      if (req.status === 200) {
        localStorage.removeItem("token");
        closeForm();
        location("/");
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <>
      <MenuBar>
        <ProfileLink to="/">
          <LogoImg src={imgLogo} />
        </ProfileLink>
        <MenuDiv>
          {menuLinks.map((e, i) => {
            return (
              <MenuLinks
                to={e.pathname}
                key={i}
                onClick={() => menuColor(e, i)}
              >
                <MenuDivs $active={e.active}>{t(e.name)}</MenuDivs>
              </MenuLinks>
            );
          })}
          {user?.login ? null : (
            <MenuSignUp className="menuItems" onClick={signUpDiv}>
              {t("Sing up / Sign in")}
            </MenuSignUp>
          )}
          <SearchProducts />
        </MenuDiv>

        <>
          {signInOpen ? (
            <SignUpDivForm>
              <CloseSignUp onClick={closeForm}>X</CloseSignUp>
              <SignInForm closeForm={closeForm} />
              <SignInDiv>
                {t("sInQuest")}
                <SignInLink onClick={myChangeToUp}>
                  {t("sInQuestLink")}
                </SignInLink>
              </SignInDiv>
            </SignUpDivForm>
          ) : null}
          {signInOpen && (
            <RamkaSigns onClick={closeForm} className="ramkaSigns" />
          )}
        </>

        <LanguageRamka>
          <HeaderLanguage onClick={() => setOpenLang(!openLang)}>
            <LangImg src={`${selectLangImg}` || `${ru}`} />
            <LangText>{selectedLanguage}</LangText>
          </HeaderLanguage>
          {openLang && (
            <LanguageDiv>
              {languages.map((element) => {
                return (
                  <HeaderLanguage
                    key={element.code}
                    onClick={() => handleSelectLang(element.code, element.src)}
                  >
                    <LangImg src={element.src} value={element.src} />
                    <LangText>{element.code}</LangText>
                  </HeaderLanguage>
                );
              })}
            </LanguageDiv>
          )}
        </LanguageRamka>

        {user?.login ? (
          <ProfileIcon $isSelected={profileOpen}>
            <CgProfile onClick={MyProfileOpen} />
            {profileOpen && (
              <ProfileDiv>
                <h3>
                  {user.name} {user.lastName}
                </h3>

                <ProfuleName></ProfuleName>

                <ProfileLinks to={`/profile`} state={{ key: "home" }}>
                  <ProfileInfo>
                    <CgProfile /> {t("Профиль")}
                  </ProfileInfo>
                </ProfileLinks>
                <ProfileInfo>
                  <ProfileLinks to={`/profile`} state={{ key: "MyOrder" }}>
                    {" "}
                    <HiMiniShoppingCart />
                    {t("My orders")}{" "}
                  </ProfileLinks>
                </ProfileInfo>
                <ProfileInfo>
                  <ProfileLinks to="/basket">
                    <FaShoppingBasket /> {t("Карзинка")}{" "}
                  </ProfileLinks>
                </ProfileInfo>
                <ProfileInfo>
                  <ProfileLinks to={"/profile"} state={{ key: "pass" }}>
                    <IoMdSettings />
                    {t("Change password")}{" "}
                  </ProfileLinks>
                </ProfileInfo>
                <ProfileInfo onClick={logOut}>
                  <ProfileLinks to="/">
                    <TbLogout /> {t("Выйти из аккаунта")}{" "}
                  </ProfileLinks>
                </ProfileInfo>
              </ProfileDiv>
            )}
          </ProfileIcon>
        ) : null}

        {profileOpen && <RamkaSignsWhite onClick={closeForm} />}

        <MenuDropDownIcon onClick={openResMenu}>
          <RxDropdownMenu />
        </MenuDropDownIcon>
      </MenuBar>
      <>
        {signUpOpen && (
          <SignUpDivForm>
            <CloseSignUp onClick={closeForm}>X</CloseSignUp>
            <SignInDiv>
              {t("sUpQuest")}
              <SignInLink onClick={myChangeToIn}>
                {t("sUpQuestLink")}
              </SignInLink>{" "}
            </SignInDiv>
            <FormSignUp value={signUpOpen} setValue={setSignUpOpen} />
          </SignUpDivForm>
        )}

        {signUpOpen && <RamkaSigns onClick={closeForm} />}
      </>
      <ResponsiveMenu $menuIsOpen={menuIsOpen}>
        <CloseResMenu onClick={closeForm}>X</CloseResMenu>
        <MenuResLinks to="/">
          <ResponsiveMenuButton onClick={closeForm}>
            {t("home")}
          </ResponsiveMenuButton>
        </MenuResLinks>

        <MenuResLinks to="/shop">
          <ResponsiveMenuButton onClick={closeForm}>
            {t("Shop")}
          </ResponsiveMenuButton>
        </MenuResLinks>

        <MenuResLinks to="/contact">
          <ResponsiveMenuButton onClick={closeForm}>
            {t("Contact")}{" "}
          </ResponsiveMenuButton>
        </MenuResLinks>

        <ResponsiveMenuButton onClick={signUpDiv}>
          {t("Sing up / Sign in")}
        </ResponsiveMenuButton>
        <LanguageRamkaRes onClick={() => setOpenLang(!openLang)}>
          <HeaderLanguageRes>
            <LangImgRes src={`${selectLangImg}` || `${ru}`} />
            <LangTextRes>{selectedLanguage}</LangTextRes>
          </HeaderLanguageRes>
          {openLang && (
            <LanguageDivRes>
              {languages.map((element) => {
                return (
                  <HeaderLanguageRes
                    key={element.code}
                    onClick={() => handleSelectLang(element.code, element.src)}
                  >
                    <LangImgRes src={element.src} value={element.src} />
                    <LangTextRes>{element.code}</LangTextRes>
                  </HeaderLanguageRes>
                );
              })}
            </LanguageDivRes>
          )}
        </LanguageRamkaRes>
      </ResponsiveMenu>
      {menuIsOpen && <RamkaSigns onClick={openResMenu} />}
    </>
  );
};
