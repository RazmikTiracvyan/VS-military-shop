import styled from "styled-components"
import { Link } from 'react-router-dom'

export const MenuBar = styled.div`
    width:100%;
    height:60px;
    display:flex;
    position:fixed;
    top:0;
    z-index: 2;
    background-color: white;
    @media(max-width:935px){
        justify-content: flex-end;
    };
    box-shadow: 0px 0px 21px 3px rgba(0,0,0,0.75);

`
export const LogoImg = styled.img`
cursor: pointer;
width: 60px;
height: 60px;
margin-left: 5px;
position: absolute;
left: 0;
@media(max-width:550px){
    width: 40px;
    height: 40px;
    margin-top: 10px;
}
`

export const MenuDiv = styled.div`
    margin-left: 70px;
    display: flex;
    width: 900px;
    @media(max-width:550px){
        margin-left: 50px;
    }

`

export const MenuDivs = styled.div`
    height:60px;
    text-align:center;
    padding-top:15px;
    transition:0.5s;
    background-color: ${({ $active }) => $active === true ? "#e5e3e3" : "none"};
    &:hover{
        background-color:#e5e3e3;
    };
    @media(max-width:940px){
        display: none;
    }
`

export const MenuLinks = styled(Link)`
    width: 100px;
    text-decoration:none;
    color:black;
    @media(max-width:940px){
        display: none;
    }
`
export const MenuResLinks = styled(Link)`
    width: 100px;
    text-decoration:none;
    color:black;
    background-color:#e5e3e3;
    
`

export const ProfileLink = styled(Link)`
`

export const MenuSignUp = styled.div`
    cursor:pointer;
    width:120px;
    text-align:center;
    padding-top:15px;
    margin-left: 10px;
    &:hover{
    background-color:#e5e3e3;
    }
    @media(max-width:940px){
        display: none;
    }
    `



export const RamkaSigns = styled.div`
    position: fixed;
    width: 100%;
    height: 1000px;
    top: -70px;
    background-color: black;
    opacity: 0.7;
    z-index: 3;


`

export const RamkaSignsWhite = styled.div`
    position: fixed;
    width: 100%;
    height: 1000px;
    top: -70px;
    z-index: 1;

`


export const SignUpDivForm = styled.div`
    background-color: white   ;
    width:500px;
    height:300px;
    position:relative;
    z-index:4;
    border-radius:8%;
    display: table;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    margin: auto;
    position:fixed;

    @media(max-width:600px){
        width:100%;
        border-radius:0%;
    }
`

export const CloseSignUp = styled.div`
    position:absolute;
    width:20px;
    height:20px;
    z-index:200;
    right:40px;
    top:40px;
    cursor:pointer;
    font-size:20px;
    transition:0.5s;
    &:hover{
        font-size:30px;
    }

 @media(max-width:533px){
        right:10px;
        top:50px;
    };
     @media(max-width:286px){
        right:10px;
        top:30px;
    }
`


export const SignInDiv = styled.div`
    width:100%;
    height:60px;
    position:absolute;
    bottom:17px;
    text-align:center;
    z-index:4;
    padding-top: 20px;
`
export const SignInLink = styled.a`
    z-index:4;
    cursor:pointer;
`

export const ProfileIcon = styled.div`
    margin-left: auto;
    margin-right:2%;
    font-size:30px;
    cursor: pointer;
    margin-top:6px;
    color:${({ $isSelected }) => $isSelected ? "green" : "black"};
    @media(max-width:935px){
        margin: none;
    }

`

export const ProfileDiv = styled.div`
    position:absolute;
    top:65px;
    right: 1%;
    width:350px;
    min-height:100px;
    z-index:1000;
    background-color:white;
    padding: 15px 15px 15px 15px;
    border-radius: 20px;
    box-shadow: 0px 0px 12px 3px rgba(0,0,0,0.75);

    @media (max-width:371px) {
        width: 100%;
    }

`
export const ProfuleName = styled.h3`
color : black;
`
export const ProfileLinks = styled(Link)`
    text-decoration: none;
    cursor: pointer;
    color: black;
    &:hover{
        opacity: 0.7;
    }
`

export const ProfileInfo = styled.div`
    width: 100%;
    height: 40px;
    margin-top: 10px ;
    cursor: pointer;
    border: none;
    background-color: #f4f2ff;
    border-radius: 10px;
    font-size: 18px;
    padding: 5px;
    `
export const MenuDropDownIcon = styled.div` 
    width: 40px;
    height: 40px;
    display: none;
    font-size:35px;
    cursor:pointer;
    margin-right: 20px;
    @media(max-width:940px){
        display: block;
    }
`

export const ResponsiveMenu = styled.div`
    position: fixed;
    padding: 20px 10px;
    width: 300px;
    top:0;
    z-index:100;
    min-height: 120vh;
    background-color: #e5e3e3;
    transition:right 0.7s;
    right:${({ $menuIsOpen }) => $menuIsOpen ? "0" : "-800px"};
    box-shadow:${({ $menuIsOpen }) => $menuIsOpen ? "rgba(0,0,0,.5) 0 0 0 5000px" : "none"};
    @media(min-width:941px){
        display: none;
    };
    @media(max-width:450px){
        width: 100%;
    }  
`

export const CloseResMenu = styled.div`
    position:absolute;
    width:20px;
    height:20px;
    z-index:200;
    right:10px;
    top:10px;
    z-index:101;
    cursor:pointer;
    font-size:20px;
    transition:0.5s;
    &:hover{
        font-size:30px;
    };
    @media(max-width:580px){
        right:10px;
        top:10px;
    }

`

export const ResponsiveMenuButton = styled.div`
    margin: 0 auto;
    text-align: center;

    padding: 10px;
    width: 100%;
    background-color:#e5e3e3;
    height: 50px;
    margin-top:5px;
    border-radius:50px;
    font-weight: bold;
    font-size: 19px;
    transition: 0.5s;
    cursor: pointer;
    margin-top: 20px;
    &:hover{
        box-shadow: 0px 0px 13px 4px rgba(0,0,0,0.75);
    }
`


export const LanguageRamka = styled.div`
    width: 70px;
    margin-top: 15px;
    height: 37x;
    position: absolute;
    right: 80px;
    background-color: #edebeb;
    border-radius: 10px;
    @media(max-width: 940px){
        display: none;
    }


`


export const LanguageDiv = styled.div`
    width: 70px;
    height: 105px;
    background-color: #edebeb;
    cursor: pointer;
    border-radius:7px;


`

export const HeaderLanguage = styled.div`
    width: 70px;
    height: 30px;
    border-radius:7px;
    cursor: pointer;
    margin-top: 5px;
    padding-left: 5px;
`
export const LangImg = styled.img`
    width: 20px;
    height: 20px;
    border-radius: 50%;

`
export const LangText = styled.span`
    margin-left:15px;
`



export const LanguageRamkaRes = styled.div`
    width: 150px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 15px;
    height: 40px;
    background-color: #ABABAB;
    border-radius: 10px;
    
  

`


export const LanguageDivRes = styled.div`
    width: 150px;
  

    height: 105px;
    background-color: #ABABAB;
    cursor: pointer;
    border-radius:7px;
    margin-top: 20px;

     
`

export const HeaderLanguageRes = styled.div`
    width: 100%;
    height: 30px;
    padding-left: 50px;
    cursor: pointer;
    margin-top: 5px;
    padding-top:5px;
`
export const LangImgRes = styled.img`
    width: 20px;
    height: 20px;
    border-radius: 50%;

`
export const LangTextRes = styled.span`
    margin-left:15px;

`

