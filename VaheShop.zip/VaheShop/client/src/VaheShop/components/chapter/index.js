import React from 'react'
import { CarouselPage } from './src/App'
import styled from 'styled-components'
const MainDiv = styled.div`
  max-width: 1280px;
  margin: 0 auto;
  padding: 2rem;
  text-align: center;
`
export const Chapter = () => {
    return (
        <>
            <MainDiv>
                <CarouselPage />

            </MainDiv>
        </>
    )
}
