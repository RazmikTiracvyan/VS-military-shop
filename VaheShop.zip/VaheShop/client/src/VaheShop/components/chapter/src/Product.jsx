import React from "react";
import styled from "styled-components"
import { Link } from "react-router-dom"
import { useTranslation } from 'react-i18next'

export default function Product(props) {
  const { t } = useTranslation()
  const ImgDiv = styled.div`
  width: 100%;
  padding: 10px;

`
  return (
    <div className="card">
      <Link to={`/shop`} state={{ key: props.state }}>
        <ImgDiv>
          <img className="product--image" src={props.url} alt="product image" width="100" />

        </ImgDiv>
      </Link>

      <h5>{props.name}</h5>
      <p className="price">{props.price}</p>
      <p>{props.description}</p>
      <p>
        <Link to={`/shop`} state={{ key: props.state }}>
          <button>{t("Go to page")}</button>

        </Link>
      </p>
    </div>
  );
}
