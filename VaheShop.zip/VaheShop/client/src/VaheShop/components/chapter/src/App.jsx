import "./App.css";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import Product from "./Product";
import { responsive } from "./data";
import form from "../../../img/chapterImg/form.png"
import gun from "../../../img/chapterImg/gun.png"
import kaska from "../../../img/chapterImg/kaska.png"
import time from "../../../img/chapterImg/time.png"
import broni from "../../../img/chapterImg/broni.png"
import binokl from "../../../img/chapterImg/binokl.png"
import { useTranslation } from "react-i18next";
export const CarouselPage = () => {
  const { t } = useTranslation()
  const productData = [

    {
      id: 1,
      imageurl: form,
      name: t("CLOTHING"),
      state: "CLOTHING",
      price: t("from") +"֏19.99",
    },
    {
      id: 2,
      imageurl: gun,
      name: t("WEAPONS"),
      state: "WEAPONS",
      price: t("from") +"֏19.99",
    },
    {
      id: 3,
      imageurl: kaska,
      name: t("HELMETS"),
      state: "HELMETS",
      price: t("from") +"֏19.99",
    },
    {
      id: 4,
      imageurl: time,
      name: t("WATCHES"),
      state: "WATCHES",
      price: t("from") +"֏19.99",
    },
    {
      id: 5,
      imageurl: broni,
      name: t("BACKPACKS"),
      state: "BACKPACKS",
      price: t("from") +"֏19.99",
    },
    {
      id: 6,
      imageurl: binokl,
      name: t("BINOCULARS"),
      state: "BINOCULARS",
      price: t("from") +"֏19.99",
    },


  ];
  const product = productData.map((item) => (

    <Product
      name={item.name}
      state={item.state}
      url={item.imageurl}
      price={item.price}
      description={item.description}
      style={{ textDecoration: "none" }}
    />

  ));

  return (
    <div className="App">
      <Carousel showDots={true} responsive={responsive}>
        {product}
      </Carousel>
    </div>
  );
}
