import {Footer} from "./footer"
import {Header} from "./header"
import {FormSignUp} from './SignUp'
import {SignInForm} from './signIn'
import { HistorProducts } from "./HistoryProducts"
import { Chapter } from "./chapter"

export  {Footer , Header , FormSignUp ,SignInForm , HistorProducts, Chapter}