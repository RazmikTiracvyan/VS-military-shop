import React, { useEffect, useRef } from "react";
import { useNavigate } from 'react-router-dom';
import { toast } from "react-toastify";

export const AlertPage = () => {
  const toastShown = useRef(false);
  const location = useNavigate();

  useEffect(() => {
    if (!toastShown.current) {
      toast.success('Почта успешно потвержденаю Теперь вы можете зайти в ващ аккаунт');
      toastShown.current = true;
    }

      location('/');
  }, [location]);

  return <></>;
};
