import styled from "styled-components";

export const BasketDiv = styled.div`
    width: 70px;
    height: 70px;
    position: fixed;
    bottom: 40px;
    right: 40px;
    z-index: 100;
    font-size: 40px;
    background-color: green;
    color: white;
    border-radius: 50%;
    text-align: center;
    box-shadow: 0px 0px 13px 4px rgba(0,0,0,0.75);
    cursor: pointer;
    transition: 0.5s;

    &:hover{
        transform: scale(1.2);

    }

`

export const BasketNum = styled.div`
    border-radius: 50px;
    background-color: black;
    width: 20px;
    height: 20px;
    position: absolute;
    right: 20px;
    top: 5px;
    color: white;
    font-size: 15px;
`