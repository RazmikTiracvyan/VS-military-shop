import React, { useState, useEffect } from "react";

import { SlBasket } from "react-icons/sl";
import { BasketDiv, BasketNum } from "./styled";
import { Link } from "react-router-dom";

export const Basket = ({ lange, pricePlus }) => {
  const [products, setProducts] = useState();
  const token = localStorage.getItem("token");
  useEffect(() => {
    const fetchData = async () => {
      try {
        const req = await fetch(`http://localhost:3002/basket?token=${token}`);
        const res = await req.json();
        setProducts(res);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, [lange, pricePlus]);
  return (
    <>
      {token && (
        <Link to="/basket">
          <BasketDiv>
            {products?.user?.basket?.length > 0 ? (
              <BasketNum>{products?.user?.basket?.length}</BasketNum>
            ) : null}

            <SlBasket />
          </BasketDiv>
        </Link>
      )}
    </>
  );
};
