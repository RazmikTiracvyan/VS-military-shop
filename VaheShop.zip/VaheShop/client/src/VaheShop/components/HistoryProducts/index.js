import React , {useEffect , useState} from "react";
import { HistoryCardsDiv, 
    HistoryTitle, 
    MainDiv,
    CardContainer,
    ImgBox,
    Img,
    ContentBox,
    Title,
    BuyButton,
    Price
 } from "./styled";

export const HistorProducts = () => {
    const [products , setProducts] = useState()
    const token = localStorage.getItem('token')
    const lang = localStorage.getItem('lang') || 'ru';

    useEffect(() => {
        const fetchData = async () => {
            try {
                const req = await fetch(`http://localhost:3002/history?token=${token}`)
                const res = await req.json()
                setProducts(res?.products?.reverse())
                
            }
            catch (err) {
                console.log(err);
            }
        }
        fetchData()
    }, [])
    return(
        <>{ (token && products?.length > 0)  &&  <MainDiv>
            <HistoryTitle>
                Недавно смотрели
            </HistoryTitle>
            <HistoryCardsDiv>
            {products && products.map((e , i) => {
                    return(<CardContainer key={e + i}>
                    <ImgBox to={`/shop/product/id/${e._id}`}>
                        <Img src={`http://localhost:3002/uploads/${e.img}`} alt="mouse corsair" />
                    </ImgBox>
                    <ContentBox>
                        <Title>{((lang == 'am') && e?.titleAM) || ((lang == 'ru') && e?.titleRU) || ((lang == 'en') && e?.titleEN)}</Title>
                        <Price>{e.price + " ₽"}</Price>
                        <BuyButton to={`/shop/product/id/${e._id}`}>Buy Now</BuyButton>
                    </ContentBox>
                </CardContainer>)
                })}
                
            </HistoryCardsDiv>
        </MainDiv>}</>
     
    )
}
