import styled from "styled-components"
import { Link } from "react-router-dom"
export const SignUpDiv = styled.div`
	width:100%;
	height:500px;
`
export const SignInForms = styled.form`
	width:100%;
	height:500px;
	position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    margin: auto;
    `
export const SignInInputsDiv = styled.div`
	width:100%;
	height:250px;

`

export const SignInInputsDivs = styled.div`
	height:40px;
	width: 100%;
	text-align:center;
`
export const SignInInputsInForm = styled.input`
	width: 80%;
	height: 40px;
	border-radius:50px;
	padding-left: 10px;
	background-color: #e5e3e3;
	border:none;
	outline: none;
`
export const SignInButtonInForm = styled.button`
	width: 80%;
	height: 40px;
	margin-top:20px;
	border-radius:50px;
	border: none;
	font-size: 19px;
	transition: 0.5s;
	background-color: #5cb85c;

	&:hover{
	box-shadow: rgb(38, 57, 77) 0px 10px 15px -5px;
	transform: scale(1.05);
	}
	@media(max-width:196px){
		font-size:15px;
	}
`
export const FormTitle = styled.p`
	text-align: center;
	font-size:25px;
	margin-top:10px;
	@media(max-width:454px){
		font-size:15px;
	}
	`
export const FormIconText = styled.p`
	text-align: center;
	font-size:25px;
	padding-top:40px;
	text-decoration: none;
	@media (max-width: 300px){
		font-size: 20px;
	}
`
export const ErrorMessage = styled.div`
	width: 100%;
	height:30px;
	color: red;
	font-size: 10px;
	padding-left:10%;
	padding-top:10px;
	@media(max-width:226px){
		padding-top:0;
	}
`
export const SignInHr = styled.hr`
`
export const SignInIconDiv = styled.div`
	height:60px;
	width:100%;
	color:white;
	display:flex;
	position:absolute;
	bottom:90px;
	justify-content: space-around;


`




export const IconButton = styled.button`
	text-align:center;
	width:120px;
	cursor:pointer;
	transition:0.5s;
	border-color:white;	
	background-color: #e5e3e3;

	&:hover{
	box-shadow: rgb(38, 57, 77) 0px 20px 30px -10px;
		transform:scale(1.1);
};


`
export const IconButtonImg = styled.img`
	width:50px;
	height:50px;

`

export const IconButtonText = styled.span`
	padding-left:10px;
	font-size:8px;
	@media(max-width:600px){
		display:none;
	}

`


export const ShowPassword = styled.span`
position: absolute;
right: 80px;
top: 170px;
cursor: pointer;
@media(max-width: 450px){
	top:  155px;
}

`