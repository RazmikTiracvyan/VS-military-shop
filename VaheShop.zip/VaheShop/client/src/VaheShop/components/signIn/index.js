import React , {useState} from 'react'
import { useForm } from 'react-hook-form';
import { useValidation, yupResolver } from '../../validations/signInValidation';
import { useTranslation } from 'react-i18next'
import { useNavigate } from 'react-router-dom';
import { ShowPassword } from './styled';
import { IoEyeSharp } from "react-icons/io5";
import { FaEyeSlash } from "react-icons/fa";
import { Link } from 'react-router-dom';
import {
	SignUpDiv,
	SignInForms,
	FormTitle,
	SignInInputsDivs,
	SignInInputsDiv,
	SignInInputsInForm,
	SignInButtonInForm,
	ErrorMessage,
	SignInIconDiv,
	IconButton,
	IconButtonImg,
	IconButtonText,
	FormIconText

} from './styled'
import { toast } from 'react-toastify';
import TgIcon from "../../img/tgIcon.png"
import googleIcon from "../../img/googleIcon.png"
import vkIcon from "../../img/vkIcon.png"
import instIcon from "../../img/instIcon.png"


export const SignInForm = ({closeForm}) => {
	const { t } = useTranslation()
	const location = useNavigate()

	const {
		register,
		handleSubmit,
		formState: { errors },
	} = useForm({
		resolver: yupResolver(useValidation()),
	});
	const onSubmit = async(data) => {
		try {
			const req = await fetch('http://localhost:3002/login', {
				method: "POST",
				headers: {
					"Content-Type": "application/json"
				},
				body: JSON.stringify(data)
			})

			if(req.status == 401){
				return toast.error('Не верная почта или пароль !')
			}
			if(req.status == 402){
				return toast.error('Ваша почта не потверждена!')
			}
			const res = await req.json();
			if(req.ok){
				localStorage.setItem("token", res.token);
				closeForm()
				location(`/profile` ,{ state: { user: res.user, token: res.token } })
			}
			

		}
		catch (err) {
			console.log(err);
		}
	};
	const [showPass , setShowPass] = useState(false)
	const ShowPas = () => {
		setShowPass((e) => !e)
	}
	return (
		<>
			<SignUpDiv>
				<SignInForms onSubmit={handleSubmit(onSubmit)}>
					<FormTitle>{t("sInTitle")}</FormTitle>
					<SignInInputsDiv>
						<ErrorMessage>{errors.name ? errors.name : null}</ErrorMessage>

						<SignInInputsDivs><SignInInputsInForm placeholder={t("email")} {...register('email')} /></SignInInputsDivs>
						<ErrorMessage>{errors.password ? errors.password : null}</ErrorMessage>

						<SignInInputsDivs><SignInInputsInForm placeholder={t("sInPass")} {...register("password")} type={showPass? "text" : "password"}/></SignInInputsDivs>
						<ShowPassword onClick={ShowPas}>{showPass ? <IoEyeSharp /> : <FaEyeSlash />}</ShowPassword>
						
						<SignInInputsDivs><SignInButtonInForm>{t("sInBut")}</SignInButtonInForm></SignInInputsDivs>

						{/* <FormIconText>{t("sInInt")}</FormIconText> */}
						<FormIconText><Link to={'/forgetpassword'} onClick={closeForm}>{t("Забыль пароль?")}</Link></FormIconText>

					</SignInInputsDiv>

				</SignInForms>

				{/* <SignInIconDiv>
					<IconButton><IconButtonImg src={TgIcon} /><IconButtonText>{t("sInInt1")}</IconButtonText></IconButton>
					<IconButton><IconButtonImg src={googleIcon} /><IconButtonText>{t("sInInt2")}</IconButtonText></IconButton>
					<IconButton><IconButtonImg src={vkIcon} /><IconButtonText>{t("sInInt3")}</IconButtonText></IconButton>
					<IconButton><IconButtonImg src={instIcon} /><IconButtonText>{t("sInInt4")}</IconButtonText></IconButton>

				</SignInIconDiv> */}
			</SignUpDiv>
		</>
	)
}