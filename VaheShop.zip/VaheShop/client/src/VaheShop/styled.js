import styled from "styled-components"

export const BodyShoop = styled.div`
    position: relative;
    top: 60px;

`