import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { HomePage } from "./containers/homePage/index";
import {
  FormSignUp,
  MyRewievPage,
  Forgetpassword,
  ForgetpasswordCode,
  ForgetNewPassword,
} from "./containers/index";
import { Header, Footer } from "./components";
import { BodyShoop } from "./styled";
import { Contact, UserPage } from "./containers/index";
import { ProductStr } from "./containers/productStr";
import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import translationEN from "./locales/en/translation.json";
import translationRU from "./locales/ru/translation.json";
import translationAM from "./locales/am/translation.json";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ProductStrPage } from "./containers/ProductStrPage/index";
import { jwtDecode } from "jwt-decode";
import { AdminPanel } from "../adminPanel/index";
import { BasketPage } from "./containers/basket";
import { AlertPage } from "./components/alertConfirmed";

i18n.use(initReactI18next).init({
  resources: {
    en: {
      translation: translationEN,
    },
    ru: {
      translation: translationRU,
    },
    am: {
      translation: translationAM,
    },
  },
  lng: localStorage.getItem("lang") || "ru",
  fallbackLng: "ru",
  interpolation: {
    escapeValue: false,
  },
});

export function MyHomePage() {
  const isValidToken = (token) => {
    try {
      const decodedToken = jwtDecode(token);

      const currentTimestamp = Date.now() / 1000;
      if (decodedToken.exp && decodedToken.exp < currentTimestamp) {
        return false;
      }

      return true;
    } catch (error) {
      return false;
    }
  };

  const isAuthenticated = () => {
    const token = localStorage.getItem("token");

    if (token && isValidToken(token)) {
      return true;
    }

    return false;
  };

  useEffect(() => {
    if (localStorage.getItem("token") && !isAuthenticated()) {
      localStorage.removeItem("token");
    }
    return () => {};
  }, []);

  return (
    <BodyShoop>
      <ToastContainer
        position="top-right"
        autoClose={2000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      <Router>
        <Header />

        <Routes>
          <Route path="/contact" element={<Contact />} />
          <Route path="/shop/product/fileName/:fileName" element={<ProductStrPage />} />
          <Route path={`/profile`} element={<UserPage />} />
          <Route path={`/register/confirm/succes`} element={<AlertPage />} />
          <Route path="/rewiev" element={<MyRewievPage />} />
          <Route path="/shop" element={<ProductStr />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/basket" element={<BasketPage />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/forgetpassword" element={<Forgetpassword />} />
          <Route path="/forgetpassword/code" element={<ForgetpasswordCode />} />
          <Route
            path="/forgetpassword/newpassword"
            element={<ForgetNewPassword />}
          />

          <Route path="*" element={<HomePage />} />
        </Routes>
        <Footer />
      </Router>
    </BodyShoop>
  );
}
