import React from "react";
import { useForm } from "react-hook-form";
import { AddUserFormDiv, AddUserInputDiv, AddUsersInput, ButtonInForm, CheckInput } from "./styled";
import { toast } from "react-toastify";

export const AddUser = () => {
    const { register, handleSubmit } = useForm();
    const changeUsers = async (data, i) => {
        try {
            const formData = new FormData();
            formData.append('name', data.name);
            formData.append('lastName', data.lastName);
            formData.append('email', data.email);
            formData.append('password', data.password);
            formData.append('confirmed', data.confirmed);

            const req = await fetch("http://localhost:3002/admin/adduser", {
                method: "POST",
                body:formData,
            });

            if (req.ok) {
                toast.success('success')
            } else {
                toast.error('error')
            }
        } catch (err) {
            console.log(err);
        }
    };
    return (
        <>
            <AddUserFormDiv onSubmit={handleSubmit((data) => changeUsers(data))}>
                <h3>Add user</h3>
                <AddUserInputDiv>
                    <AddUsersInput placeholder="name" {...register('name')} />
                    <AddUsersInput placeholder="lastName" {...register('lastName')} />
                    <AddUsersInput placeholder="email" {...register('email')} />
                    <AddUsersInput placeholder="password" {...register('password')} />
                    <label><CheckInput type="checkbox" {...register('confirmed')}/> confirmed</label>
                    <ButtonInForm>add user</ButtonInForm>
                </AddUserInputDiv>
            </AddUserFormDiv>
        </>
    )
}