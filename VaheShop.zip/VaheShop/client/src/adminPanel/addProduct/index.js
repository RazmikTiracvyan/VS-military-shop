import React from "react";
import { useForm } from "react-hook-form";

import {
  RamkaDiv,
  TitleDiv,
  AddProductFormDiv,
  AddProductsInput,
  AddProductsInputCheck,
  AddImgInput,
  AddProductTextArea,
  AddProductsButton,
  AddProductsSelect,
} from "./styled"
import { toast } from "react-toastify";

export const AddProducts = () => {
  const { register: productsRegister, handleSubmit: handleProductsSubmit, formState: { errors } } = useForm();
  const onProductsSubmit = async (data) => {

    if (
      data.titleRU === "" ||
      data.titleEN === "" ||
      data.titleAM === "" ||
      data.descriptionRU === "" ||
      data.descriptionEN === "" ||
      data.descriptionAM === "" ||
      data.price === ""
    ) {
      return toast.warning('Заполните все поля!');
    }
    if (!data.img[0]) {
      return toast.warning("Картинка не выбран!")

    }
    if (data.img[0]?.size > (10 * 1024 * 1024)) {
      return toast.warning("Картинка не может перевышать 10 мб")
    }

    try {
      console.log(data);

      const formData = new FormData();
      formData.append('titleRU', data.titleRU);
      formData.append('titleEN', data.titleEN);
      formData.append('titleAM', data.titleAM);
      formData.append('ImageFileName', data.img[0]?.name);
      formData.append('Image', data.img[0]);
      formData.append('price', data.price);
      formData.append('descriptionRU', data.descriptionRU);
      formData.append('descriptionEN', data.descriptionEN);
      formData.append('descriptionAM', data.descriptionAM);
      formData.append('inStock', data.inStock);
      formData.append('type', data.type);
      console.log(formData);
      const req = await fetch('https://localhost:7123/api/product', {
        method: 'POST',
        body: formData,
      });
      console.log("kjhgfds");
      console.log(req , "req");
      if (req.ok) {
        toast.success('Товар кспешно добавлен!')
      } else toast.error('Что-то пошел не так')


      const res = req.json()
      console.log(res);
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <RamkaDiv>
      {console.log(1)}

      <TitleDiv>
        <h3>Добавить продукт</h3>
      </TitleDiv>
      <AddProductFormDiv onSubmit={handleProductsSubmit(onProductsSubmit)}>

        <AddProductsInput placeholder='Заголовок продукта RU' {...productsRegister('titleRU')} />
        <AddProductsInput placeholder='Заголовок продукта EN' {...productsRegister('titleEN')} />
        <AddProductsInput placeholder='Заголовок продукта AM' {...productsRegister('titleAM')} />

        <AddImgInput type='file' accept='image/*'  {...productsRegister('img')} />

        <AddProductsInput type='number' placeholder='Цена продукта'  {...productsRegister('price')} />

        <AddProductTextArea placeholder='Информация о продукте RU'  {...productsRegister('descriptionRU')} />
        <AddProductTextArea placeholder='Информация о продукте EN'  {...productsRegister('descriptionEN')} />
        <AddProductTextArea placeholder='Информация о продукте AM'  {...productsRegister('descriptionAM')} />
        <AddProductsSelect placeholder='Заголовок продукта AM' {...productsRegister('type')}>
          <option>
            WEAPONS
          </option>
          <option>
            HELMETS
          </option>
          <option>
            WATCHES
          </option>
          <option>
            BACKPACKS
          </option>
          <option>
            BINOCULARS
          </option>
          <option>
            CLOTHING
          </option>
        </AddProductsSelect>

        <AddProductsInputCheck type='checkbox'  {...productsRegister('inStock')} /><br />В наличии
        <AddProductsButton>Добавить товар</AddProductsButton>
      </AddProductFormDiv>
    </RamkaDiv>
  )

}