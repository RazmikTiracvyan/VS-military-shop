import React, { useEffect, useState } from "react";
import { DoneDiv, RevDiv, RevOInfoDiv } from "./styled";
import { IoMdDoneAll } from "react-icons/io";
import { RxCross1 } from "react-icons/rx";


export const MyReview = React.memo(() => {
    const [reviews, setReviews] = useState([])

    useEffect(() => {
        console.log(reviews);

        const fetchData = async () => {
            try {
                const req = await fetch("http://localhost:3002/rewievsAll", {
                    method: "GET",
                });
                const res = await req.json();
                setReviews(() => {
                    return [...res]
                })

            } catch (err) {
                console.log(err);
            }
        };

        fetchData();

    }, []);

    const doneReview = async (i) => {
        try {
            const updatedReviews = [...reviews];
            const reviewToUpdate = updatedReviews[i];
    
            if (!reviewToUpdate.confirmed) {
                const req = await fetch(`http://localhost:3002/updateReview/${reviewToUpdate._id}`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({ confirmed: true }), // Обновляем поле confirmed на true
                });
    
                if (req.ok) {
                    // Обновляем копию массива
                    updatedReviews[i] = { ...reviewToUpdate, confirmed: true };
                    setReviews(updatedReviews);
                } else {
                    console.error("Не удалось обновить обзор");
                }
            }
    
        } catch (err) {
            console.log(err);
        }
    }


    const deleteReview = async (i) => {
        try {
            const reviewToDelete = reviews[i];
            const req = await fetch(`http://localhost:3002/deleteReview/${reviewToDelete._id}`, {
                method: "DELETE",
            });
    
            if (req.ok) {
                // Успешно удалено из базы данных
                const updatedReviews = reviews.filter((_, index) => index !== i);
                setReviews(updatedReviews);
            } else {
                console.error("Не удалось удалить обзор");
            }
        } catch (err) {
            console.log(err);
        }
    };
    return (
        <>
            <RevDiv>
                {reviews?.map((e, i) => {
                    return (
                        <RevOInfoDiv key={e + i}>
                            <DoneDiv>
                                {!e.confirmed ? <button onClick={() => {doneReview(i)}}>{<IoMdDoneAll />} </button> : null}
                                <span>  </span>
                                <button onClick={() => deleteReview(i)}> {<RxCross1 />}</button>
                            </DoneDiv>
                            <p>name : {e.name}</p>
                            <p>position : {e.position}</p>
                            <p>stars : {e.stars}</p>
                            <p>disc : {e.disc}</p>
                            <p>confirmed : {e.confirmed ? "Одобрен" : "Ожидает одобрение"}</p>
                        </RevOInfoDiv>
                    )
                })}
            </RevDiv>
        </>
    )
})