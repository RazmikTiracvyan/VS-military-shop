import styled from "styled-components";


export const RevDiv = styled.div`
    background-color: white;
    position: fixed;
    top: 70px;
    right: 0;
    bottom: 0;
    left: 0;
    margin: auto;
    width: 80%;
    height: 600px;
    overflow-y: scroll;
    overflow-x: hidden;
    border-radius: 20px;
    word-wrap: break-word;

    &::-webkit-scrollbar {
    width: 5px;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #888;
  }

  &::-webkit-scrollbar-thumb:hover {
    background-color: #333;
  }

  &::-webkit-scrollbar-track {
    background-color: #555;
  }
    
`

export const RevOInfoDiv = styled.div`
    width: 100%;
    min-height: 100px;
    background-color: white;
    margin-top: 20px;
    padding: 10px;
    overflow: auto;
    word-wrap: break-word;
  position: relative;
    &::-webkit-scrollbar {
    width: 5px;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #888;
  }

  &::-webkit-scrollbar-thumb:hover {
    background-color: #333;
  }

  &::-webkit-scrollbar-track {
    background-color: #555;
  }



`

export const DoneDiv = styled.div`
position: absolute;
right: 10px;
top: 10px;

`