import React, { useState, useEffect, useRef } from 'react'
import { useForm } from 'react-hook-form';
import { ProductsDiv, ProductsInfoDiv, DoneDiv, EditUsersDiv, EditUsersInput, EditUsersButton, EditUsersInputCheck, SortDiv, SearchUsers, SearchDivIconDiv } from "./styled";
import { FaEdit } from "react-icons/fa";
import { RxCross1 } from "react-icons/rx";
import { FaSearch } from "react-icons/fa";
import { Link } from 'react-router-dom';


export const AllUsers = () => {
    const itemsPerPage = 20;
    const [users, setUsers] = useState([])
    const [editUserIndex, setEditUserIndex] = useState(null);
    const [editBuyIndex, setEditBuyIndex] = useState(null);
    const [searchUser, setSerachUser] = useState('')
    const [visibleItems, setVisibleItems] = useState(itemsPerPage);
    const containerRef = useRef(null);
    const { register, handleSubmit } = useForm();
    useEffect(() => {
        const fetchData = async () => {
            const req = await fetch('http://localhost:3002/users');
            const res = await req.json()
            if (req.ok) {
                setUsers(res)
            } else console.log('не удалось получить список пользователей');
        }
        fetchData()
    }, [editUserIndex])

    const deleteUser = async (i) => {
        try {
            const UserDelete = users[i];
            const req = await fetch(`http://localhost:3002/users/${UserDelete._id}`, {
                method: "DELETE",
            });

            if (req.ok) {
                const updateUsers = users.filter((_, index) => index !== i);
                setUsers(updateUsers);
            } else {
                console.error("Не удалось удалить обзор");
            }
        } catch (err) {
            console.log(err);
        }
    };
    const toggleEditUsers = (index) => {
        setEditUserIndex((e) => (e === index ? null : index));
        setEditBuyIndex(false)
    };
    const toggleBuyUsers = (index) => {
        setEditBuyIndex((e) => (e === index ? null : index));
        setEditUserIndex(false)
    };
    const changeUsers = async (data, i) => {
        try {
            const formData = new FormData();
            formData.append('name', data?.name?.trim() !== '' ? data.name : users[i].name);
            formData.append('lastName', data?.lastName?.trim() !== '' ? data.lastName : users[i].lastName);
            formData.append('email', data?.email?.trim() !== '' ? data.email : users[i].email);
            formData.append('confirmed', data.confirmed);

            const req = await fetch(`http://localhost:3002/users/${users[i]._id}`, {
                method: "PUT",
                body: formData,
            });

            if (req.ok) {
                setUsers(prevUsers => {
                    const updateUsers = [...prevUsers];
                    updateUsers[i] = { ...updateUsers[i], ...data };
                    return updateUsers;
                });
                setEditUserIndex(null);
            } else {
                console.error("Не удалось обновить продукт");
            }
        } catch (err) {
            console.log(err);
        }
    };
    const handleScroll = () => {
        const container = containerRef.current;
        if (container) {
            const isAtBottom =
                container.scrollTop + container.clientHeight >= container.scrollHeight - 20;


            if (isAtBottom) {
                setVisibleItems((prevVisibleItems) => prevVisibleItems + itemsPerPage);
            }
        }
    };

    useEffect(() => {
        const container = containerRef.current;

        if (container) {
            container.addEventListener('scroll', handleScroll);
        }

        return () => {
            if (container) {
                container.removeEventListener('scroll', handleScroll);
            }
        };
    }, []);
    return (
        <>

            <ProductsDiv ref={containerRef}>
                <SortDiv>
                    <SearchUsers placeholder='search' onChange={(e) => setSerachUser(e.target.value)} />
                    <SearchDivIconDiv>
                        <FaSearch />
                    </SearchDivIconDiv>
                </SortDiv>
                {users?.filter(
                    (e) =>
                        e.email.toLowerCase().includes(searchUser.toLowerCase()) ||
                        e.name.toLowerCase().includes(searchUser.toLowerCase()) ||
                        e.lastName.toLowerCase().includes(searchUser.toLowerCase())
                )?.slice(0, visibleItems).map((e, i) => {
                    return (
                        <ProductsInfoDiv key={i}>
                            <DoneDiv>
                                <button onClick={() => toggleEditUsers(i)}>{<FaEdit />} </button>
                                <span> </span>
                                <button onClick={() => deleteUser(i)}> {<RxCross1 />}</button>
                            </DoneDiv>
                            <p>name: {e.name}</p>
                            <p>lastname: {e.lastName}</p>
                            <p>email: {e.email}</p>
                            <p>confirned: {e.confirmed ? "yes" : "no"}</p>
                            <p>online: {e.login ? "yes" : "no"}</p>
                            <p>data signup: {e.createdAt?.slice(0, 10)}</p>
                            <p>id: {e._id}</p>
                            <p><button onClick={() => toggleBuyUsers(i)}>Посмотреть историю покупки</button></p>
                            <hr />
                            {editBuyIndex === i && <p>{e.buyHistory?.map((prod, index) => {
                                return (
                                    <>
                                        <p>id: {prod._id}</p>
                                        <p>titleRU: {prod.titleRU}</p>
                                        <p>titleEN: {prod.titleEN}</p>
                                        <p>titleAM: {prod.titleAM}</p>
                                        <p>img: {prod.img}</p>
                                        <p>price: {prod.price}</p>
                                        <p>discriptionRU: {prod.descriptionRU}</p>
                                        <p>discriptionEN: {prod.descriptionEN}</p>
                                        <p>discriptionAM: {prod.descriptionAM}</p>
                                        <p>type: {prod.type}</p>
                                        <p><Link to={`/shop/product/id/${prod._id}`}>Перейти в страницу</Link></p>
                                        <hr />
                                    </>
                                )
                            })}</p>}
                            
                            {editUserIndex === i && (
                                <EditUsersDiv>
                                    <form onSubmit={handleSubmit((data) => changeUsers(data, i))}>
                                        <EditUsersInput placeholder="name" {...register("name")} />
                                        <br />
                                        <EditUsersInput placeholder="lastName" {...register("lastName")} />
                                        <br />
                                        <EditUsersInput placeholder="email" {...register("email")} />
                                        <br />
                                        <label>
                                            <EditUsersInputCheck type="checkbox" {...register("confirmed")} /> confirmed
                                        </label>
                                        <br />
                                        <EditUsersButton type="submit">update</EditUsersButton>
                                    </form>
                                </EditUsersDiv>
                            )}
                        </ProductsInfoDiv>
                    );
                })}
            </ProductsDiv>
        </>
    );
}