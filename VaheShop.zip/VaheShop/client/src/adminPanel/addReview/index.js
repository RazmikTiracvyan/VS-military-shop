import React, { useState, useEffect, useMemo } from "react";
import {  CloseDiv, RamkaDiv, ReviewButton, ReviewInput, ReviewTextarea,  Star, StarSpan, TitleReviews } from "./styled";
import { FaStar } from "react-icons/fa";
import { v4 as uuidv4 } from 'uuid';
import { toast } from "react-toastify";
import { RxCross1 } from "react-icons/rx";

export const AdminAddReview = React.memo(({closeAddProductMenu}) => {
    const [stars, setStars] = useState(0);
    const [user , setUser] = useState()
    const [text, setText] = useState({
        disc: '',
        name: '',
        lastName: '',
        position: '',
        stars: ''
    });
    
    const arr = [1, 2, 3, 4, 5];

    const myOnChange = (e) => {
        const { name, value } = e.target;
        setText((prev) => {
            return { ...prev, [name]: value };
        });
    };



    const addRewiev = async () => {
        try {
           

            text.stars = stars;

            if (stars === 0) {
                return toast.error("поставьте вашу оценку");
            }
            if (!text.disc) {
                return toast.error("Поле 'отзыв' не может быть пустым");
            }
            if (!text.position) {
                return toast.error("Поле 'профессия' не может быть пустым!");
            }

            const req = await fetch('http://localhost:3002/rewievs', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(text)
            });
            toast.success('Ваш отзыв отправлен на модерацию!');
        } catch (err) {
            console.log(err);
        }
    };

   
    useEffect(() => {
    const checkToken = () => {
      if (!localStorage.getItem('token')) {
        return false;
      }
      return true;
    };

    const fetchData = async () => {
      if (!checkToken()) return;

      try {
        if (!token) {
          console.error('Token not found');
          return;
        }

        const req = await fetch(`http://localhost:3002/profile?token=${token}`);

        const res = await req.json();
        setUser(res.user);
        } catch (err) {
        console.error(err);
      }
    };

    fetchData();
  }, []);

    const token = localStorage.getItem('token')
  useEffect(() => {
    const checkToken = () => {
      if (!localStorage.getItem('token')) {
        return false;
      }
      return true;
    };

    const fetchData = async () => {
      if (!checkToken()) return;

      try {
        if (!token) {
          console.error('Token not found');
          return;
        }

        const req = await fetch(`http://localhost:3002/profile?token=${token}`);

        const res = await req.json();
        setUser(res.user);
      } catch (err) {
        console.error(err);
      }
    };

    fetchData();
  }, []);

    return (
        <>
           <RamkaDiv>
            <CloseDiv onClick={closeAddProductMenu}>
                <RxCross1 />
            </CloseDiv>
                <TitleReviews>Добавить свой отзыв на сайте</TitleReviews>
                <ReviewInput placeholder="Ваша имя" name="name" value={text.name} onChange={myOnChange} />
                <ReviewInput placeholder="Ваша фамилия" name="lastName" value={text.lastName} onChange={myOnChange} />
                <ReviewInput placeholder="Ваша профессия" name="position" value={text.position} onChange={myOnChange} />
                <ReviewTextarea placeholder="Ваш отзыв" maxLength={300} name="disc" value={text.disc} onChange={myOnChange} />
                <Star>
                    {arr.map((e, i) => {
                        let count = i + 1;
                        return (
                            <StarSpan key={uuidv4()}><FaStar
                                onClick={() => setStars(count)}
                                color={count <= stars ? "yellow" : "gray"}
                            /></StarSpan>
                        );
                    })}
                </Star>
                <ReviewButton onClick={addRewiev}>Добавить отзыв</ReviewButton>
            </RamkaDiv>
           
        </>
    );
});

