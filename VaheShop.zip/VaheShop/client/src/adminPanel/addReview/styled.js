import styled from "styled-components";


export const RewievPageDiv = styled.div`
    width: 100%;
    min-height: 100vh;
    background-color: #191923;

`
export const StarSpan = styled.div`
    font-size: 30px;
    width: 30px;
    cursor: pointer;

`

export const StarDiv = styled.div`
background-color: red;
`

export const Star = styled.div`
display: flex;
margin-left: 40px;
`

export const BGCdiv = styled.div`
z-index: 49;
position: fixed;
width: 100%;
height: 120%;
top:-60px;
background-color: black;
opacity: 0.7;
`

export const RamkaDiv = styled.div`
position: fixed;
left: 0;
top: 0;
right: 0;
bottom: 0;
background-color: #191923;
width: 400px;
height: 550px;
z-index: 100;
margin: auto;
border-radius:50px;
text-align: center;
	@media(max-width: 455px){
		width: 100%;


	}
`
export const ReviewInput = styled.input`
	width: 80%;
	height: 40px;
	border-radius:10px;
	padding-left: 10px;
	background-color: #e5e3e3;
	border: none;
	outline: none;
	margin-top: 20px;

`
export const ReviewTextarea = styled.textarea`
	width: 80%;
    height: 100px;
	border-radius:10px;
	padding-left: 10px;
	background-color: #e5e3e3;
	border: none;
	outline: none;
	margin-top: 5px;
	resize: none;

`
export const ReviewButton = styled.button`
	width: 80%;
	height: 40px;
	margin-top:50px;
	border-radius:50px;
	border:none;
	font-size: 19px;
	transition: 0.5s;
	background-color: #5cb85c;
	&:hover{
	box-shadow: rgb(38, 57, 77) 0px 10px 15px -5px;
	transform: scale(1.05);	};

`
export const AddReview = styled.div`
width: 100%;
min-height: 100px;
color: white;
padding: 20px 0 20px 10%;
`

export const AddReviewButton = styled.button`
	width: 300px;
	height: 40px;
	margin-top:50px;
	border-radius:50px;
	border:none;
	font-size: 19px;
	transition: 0.5s;
	background-color: #5cb85c;
	&:hover{
	box-shadow: rgb(38, 57, 77) 0px 10px 15px -5px;
	transform: scale(1.05);	
}
@media(max-width: 344px){
		width: 200px;


	}
	`

export const TitleReviews = styled.h4`
color: #9ba49b;;
margin-top: 10px;
`

export const CloseDiv = styled.div`
	position: absolute;
	color: white;
	font-size: 25px;
	right: 10px;
	top: 30px;
`