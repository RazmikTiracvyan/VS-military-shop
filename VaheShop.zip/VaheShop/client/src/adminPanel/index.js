import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';

import {
  AdminLoginDiv,
  AdminLoginForm,
  AdminPanelButton,
  AdminPanelInput,
  AdminDiv,
  AdminHeader,
  AdminHeaderProfileImg,
  AdminBody,
  AdminBodyDivsAll,
  AdminBodyDivs,
  AdminBodyDiv,
  AdminBodyDivImgDiv,
  AdminBodyImg,
  RamkaBgcDiv,
  AdminBodyTextDiv,
  AdminBodyText,

} from './styled';
import adminImg from "../VaheShop/img/adminpanel/admin.png"
import user from "../VaheShop/img/adminpanel/user.png"
import users from "../VaheShop/img/adminpanel/users.png"
import products from "../VaheShop/img/adminpanel/products.png"
import order from "../VaheShop/img/adminpanel/order.png"
import category from "../VaheShop/img/adminpanel/category.png"
import review from "../VaheShop/img/adminpanel/review.png"
import { MyReview } from './Review';
import { MyProductsList } from './ProductList';
import { AdminAddReview } from './addReview';
import { AllUsers } from './users';
import { AddUser } from './addUser';
import { toast } from "react-toastify";
import { AddProducts } from './addProduct';

const AdminPanel = () => {
  const [openReviews, setOpenReviews] = useState(false);
  const [adminName, setAdminName] = useState();

  const [openAddMenu, setOpenAddMenu] = useState({
    addProduct: false,
    review: false,
    products: false,
    users: false,
    addUser:false,
  })
  const navigate = useNavigate();
  const { register: loginRegister, handleSubmit: handleLoginSubmit } = useForm();



  const onLoginSubmit = async (data) => {
    try {
      const req = await fetch('http://localhost:3002/admin/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const res = await req.json();
      console.log(res);
      setAdminName({name : res.name , login: res.login})
      localStorage.setItem('admin', "admin");
      navigate('/admin');
    } catch (err) {
      console.log(err);
    }
  };

 
  const openAddProduct = () => {
    setOpenAddMenu({ ...openAddMenu, addProduct: true });
  }
  const closeAddProductMenu = () => {
    setOpenAddMenu({ ...openAddMenu, addProduct: false, review: false, products: false , users: false , addUser:false });
    setOpenReviews(false)
  }

  const openRevMenu = () => {
    setOpenAddMenu({ ...openAddMenu, review: true });
  }
  const openProductsMenu = () => {
    setOpenAddMenu({ ...openAddMenu, products: true });
  }
  const openUsersMenu = () => {
    setOpenAddMenu({ ...openAddMenu, users: true });
  }
  const openAddUsersMenu = () => {
    setOpenAddMenu({ ...openAddMenu, addUser: true });
  }
  console.log(adminName);
  return (
    <>


      {localStorage.getItem('admin') && adminName?.login ? (

        <AdminDiv>
          {openReviews ? <AdminAddReview closeAddProductMenu={closeAddProductMenu}/> : null}
          {openReviews ? <RamkaBgcDiv onClick={closeAddProductMenu} /> : null}
          {openAddMenu.users? <AllUsers /> : null}
          {openAddMenu.users? <RamkaBgcDiv onClick={closeAddProductMenu} /> : null}
          {openAddMenu.addUser? <RamkaBgcDiv onClick={closeAddProductMenu} /> : null}

          {openAddMenu.addUser? <AddUser /> : null}
          {openAddMenu.addProduct ? <RamkaBgcDiv onClick={closeAddProductMenu} /> : null}
          {openAddMenu.addProduct && <AddProducts /> }
          {openAddMenu.review ? <RamkaBgcDiv onClick={closeAddProductMenu} /> : null}

          {openAddMenu.review ? <MyReview /> : null}


          {openAddMenu.products ? <RamkaBgcDiv onClick={closeAddProductMenu} /> : null}
          {openAddMenu.products ? <MyProductsList /> : null}

          <AdminHeader>
            <AdminHeaderProfileImg src={adminImg} />
          </AdminHeader>
          <AdminBody>
            <AdminBodyDivsAll>
              <AdminBodyDivs>
                <AdminBodyDiv onClick={openAddUsersMenu}>
                  <AdminBodyDivImgDiv>
                    <AdminBodyImg src={user} />
                  </AdminBodyDivImgDiv>
                  <AdminBodyTextDiv>
                    <AdminBodyText>
                      add user
                    </AdminBodyText>
                  </AdminBodyTextDiv>
                </AdminBodyDiv>
                <AdminBodyDiv onClick={openUsersMenu}>
                  <AdminBodyDivImgDiv>
                    <AdminBodyImg src={users} />
                  </AdminBodyDivImgDiv>
                  <AdminBodyTextDiv>
                    <AdminBodyText>
                      users
                    </AdminBodyText>
                  </AdminBodyTextDiv>
                </AdminBodyDiv>
              </AdminBodyDivs>
              <AdminBodyDivs>
                <AdminBodyDiv onClick={openAddProduct}>
                  <AdminBodyDivImgDiv>
                    <AdminBodyImg src={products} />
                  </AdminBodyDivImgDiv>
                  <AdminBodyTextDiv>
                    <AdminBodyText>
                      Добавить продукт
                    </AdminBodyText>
                  </AdminBodyTextDiv>
                </AdminBodyDiv>
                <AdminBodyDiv onClick={openProductsMenu}>
                  <AdminBodyDivImgDiv>
                    <AdminBodyImg src={order} />
                  </AdminBodyDivImgDiv>
                  <AdminBodyTextDiv>
                    <AdminBodyText>
                      Продукты
                    </AdminBodyText>
                  </AdminBodyTextDiv>
                </AdminBodyDiv>
              </AdminBodyDivs>
              <AdminBodyDivs>
                <AdminBodyDiv>
                  <AdminBodyDivImgDiv>
                    <AdminBodyImg src={category} />
                  </AdminBodyDivImgDiv>
                  <AdminBodyTextDiv>
                    <AdminBodyText>
                      ...
                    </AdminBodyText>
                  </AdminBodyTextDiv>
                </AdminBodyDiv>
                <AdminBodyDiv>
                  <AdminBodyDivImgDiv>
                    <AdminBodyImg src={category} />
                  </AdminBodyDivImgDiv>
                  <AdminBodyTextDiv>
                    <AdminBodyText>
                      ...
                    </AdminBodyText>
                  </AdminBodyTextDiv>
                </AdminBodyDiv>

              </AdminBodyDivs>
              <AdminBodyDivs>
                <AdminBodyDiv onClick={openRevMenu}>
                  <AdminBodyDivImgDiv>
                    <AdminBodyImg src={review} />
                  </AdminBodyDivImgDiv>
                  <AdminBodyTextDiv>
                    <AdminBodyText>
                      Reviews
                    </AdminBodyText>
                  </AdminBodyTextDiv>
                </AdminBodyDiv>
                <AdminBodyDiv onClick={() => setOpenReviews(true)}>
                  <AdminBodyDivImgDiv>
                    <AdminBodyImg src={review} />
                  </AdminBodyDivImgDiv>
                  <AdminBodyTextDiv>
                    <AdminBodyText>
                      Добавить отзыв
                    </AdminBodyText>
                  </AdminBodyTextDiv>
                </AdminBodyDiv>
              </AdminBodyDivs>
            </AdminBodyDivsAll>

          </AdminBody>

        </AdminDiv>


      ) : (
        <AdminLoginDiv>
          <AdminLoginForm>
            <h4>Панель администратора</h4>
            <form onSubmit={handleLoginSubmit(onLoginSubmit)}>
              <AdminPanelInput placeholder="Логин" {...loginRegister('name')} />
              <AdminPanelInput type="password" placeholder="Пароль" {...loginRegister('password')} /> <br />
              <AdminPanelButton type="submit">Войти</AdminPanelButton>
            </form>
          </AdminLoginForm>
        </AdminLoginDiv>
      )}
    </>
  );
};

export { AdminPanel };
