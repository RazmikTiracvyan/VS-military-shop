import React, { useEffect, useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { MdOutlineDoneAll } from "react-icons/md";
import { RxCross2 } from "react-icons/rx";
import {
  InStockP,
  DoneDiv,
  EditProductButton,
  EditImgInput,
  EditProductDiv,
  EditProductInput,
  ProductsDiv,
  ProductsInfoDiv,
  SortSpan,
  SortDiv,
  SearchProducts,
  SearchDivIconDiv,
} from "./styled";
import { FaEdit } from "react-icons/fa";
import { RxCross1 } from "react-icons/rx";
import { FaSearch } from "react-icons/fa";

export const MyProductsList = React.memo(() => {
  const { register, handleSubmit } = useForm();
  const itemsPerPage = 20;
  const [products, setProducts] = useState([]);
  const [editProductIndex, setEditProductIndex] = useState(null);
  const [sortProducts, setSortProducts] = useState("minMax");
  const [sortProductsBoolean, setSortProductsBoolean] = useState(true);
  const [visibleItems, setVisibleItems] = useState(itemsPerPage);
  const [searchProducts, setSerachProducts] = useState("");

  const containerRef = useRef(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const req = await fetch("https://localhost:7123/api/product", {
          method: "GET",
        });
        const res = await req.json();
        console.log(res);
        setProducts(res);
      } catch (err) {
        console.log(err);
      }
    };

    fetchData();
  }, [editProductIndex]);

  const deleteProduct = async (i) => {
    try {
      const ProductsToDelete = products[i];
      console.log(ProductsToDelete);
      const req = await fetch(
        `https://localhost:7123/api/product/${ProductsToDelete.imageFileName}`,
        {
          method: "DELETE",
        }
      );

      if (req.ok) {
        const updatedproducts = products.filter((_, index) => index !== i);
        setProducts(updatedproducts);
        setEditProductIndex(null);
      } else {
        console.error("Не удалось удалить обзор");
      }
    } catch (err) {
      console.log(err);
    }
  };

  const changeProduct = async (data, imageFileName) => {
    try {
      const response = await fetch(
        `https://localhost:7123/api/product/${imageFileName}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );

      if (response.ok) {
        console.log("Product updated successfully");
      } else {
        console.error("Failed to update product");
      }
    } catch (error) {
      console.error("An error occurred while updating product:", error.message);
    }
  };

  const toggleEditProduct = (index) => {
    setEditProductIndex((e) => (e === index ? null : index));
  };

  const handleSort = () => {
    const sortedProducts = [...products];

    if (sortProducts === "minMax") {
      sortedProducts.sort((a, b) => a.price - b.price);
      setSortProducts("maxMin");
    } else {
      sortedProducts.sort((a, b) => b.price - a.price);
      setSortProducts("minMax");
    }

    setProducts(sortedProducts);
  };
  const handleSortBoolean = () => {
    const sortedProducts = [...products];

    sortedProducts.sort((a, b) => {
      setSortProductsBoolean((e) => !e);
      const aValue = a.inStock ? 0 : 1;
      const bValue = b.inStock ? 0 : 1;
      return aValue - bValue;
    });

    setSortProductsBoolean(!sortProductsBoolean);
    if (!sortProductsBoolean) {
      sortedProducts.reverse();
    }

    setProducts(sortedProducts);
  };

  const handleScroll = () => {
    const container = containerRef.current;
    if (container) {
      const isAtBottom =
        container.scrollTop + container.clientHeight >=
        container.scrollHeight - 20;

      if (isAtBottom) {
        setVisibleItems((prevVisibleItems) => prevVisibleItems + itemsPerPage);
      }
    }
  };

  useEffect(() => {
    const container = containerRef.current;

    if (container) {
      container.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, []);

  return (
    <>
      <ProductsDiv ref={containerRef}>
        <SortDiv>
          Сортировать по цене`{" "}
          {sortProducts === "minMax" ? (
            <SortSpan onClick={handleSort}>возрастанию</SortSpan>
          ) : (
            <SortSpan onClick={handleSort}>убыванию</SortSpan>
          )}
          , по статусу`{" "}
          {sortProductsBoolean ? (
            <SortSpan onClick={handleSortBoolean}>Есть в наличии</SortSpan>
          ) : (
            <SortSpan onClick={handleSortBoolean}>Законченные товары</SortSpan>
          )}
          <br />{" "}
          <SearchProducts
            placeholder="search"
            onChange={(e) => setSerachProducts(e.target.value)}
          />
          <SearchDivIconDiv>
            <FaSearch />
          </SearchDivIconDiv>
        </SortDiv>

        {products
          .filter(
            (e) =>
              e.titleAM?.toLowerCase().includes(searchProducts.toLowerCase()) ||
              e.titleRU?.toLowerCase().includes(searchProducts.toLowerCase()) ||
              e.titleEN?.toLowerCase().includes(searchProducts.toLowerCase())
          )
          .slice(0, visibleItems)
          ?.map((e, i) => (
            <ProductsInfoDiv key={e._id}>
              <DoneDiv>
                <button onClick={() => toggleEditProduct(i)}>
                  {<FaEdit />}{" "}
                </button>
                <span> </span>
                <button onClick={() => deleteProduct(i)}>
                  {" "}
                  {<RxCross1 />}
                </button>
              </DoneDiv>
              <p>titleRU: {e.titleRU}</p>
              <p>titleEN: {e.titleEN}</p>
              <p>titleAM: {e.titleAM}</p>
              <p>img: {e.img}</p>
              <p>price: {e.price}</p>
              <p>discriptionRU: {e.descriptionRU}</p>
              <p>discriptionEN: {e.descriptionEN}</p>
              <p>discriptionAM: {e.descriptionAM}</p>
              <p>type: {e.type}</p>
              {e.inStock ? (
                <InStockP inStock={e.inStock}>
                  Статус: есть на продаже <MdOutlineDoneAll />
                </InStockP>
              ) : (
                <InStockP inStock={e.inStock}>
                  Статус: товар закончен <RxCross2 />
                </InStockP>
              )}

              {editProductIndex === i && (
                <EditProductDiv
                  onSubmit={handleSubmit((data) => changeProduct(data, i))}
                >
                  <EditProductInput
                    placeholder="titleRU"
                    {...register("titleRU")}
                  />
                  <br />
                  <EditProductInput
                    placeholder="titleEN"
                    {...register("titleEN")}
                  />
                  <br />
                  <EditProductInput
                    placeholder="titleAM"
                    {...register("titleAM")}
                  />
                  <br />
                  <EditProductInput
                    type="number"
                    placeholder="price"
                    {...register("price")}
                  />
                  <br />
                  <EditProductInput
                    placeholder="descriptionRU"
                    {...register("descriptionRU")}
                  />
                  <br />
                  <EditProductInput
                    placeholder="descriptionEN"
                    {...register("descriptionEN")}
                  />
                  <br />
                  <EditProductInput
                    placeholder="descriptionAM"
                    {...register("descriptionAM")}
                  />
                  <br />
                  <p>
                    <select style={{ marginTop: "10px" }} {...register("type")}>
                      <option>WEAPONS</option>
                      <option>HELMETS</option>
                      <option>WATCHES</option>
                      <option>BACKPACKS</option>
                      <option>BINOCULARS</option>
                      <option>CLOTHING</option>
                    </select>
                  </p>
                  <label>
                    <input type="checkbox" {...register("inStock")} /> Есть в
                    наличии{" "}
                  </label>
                  <br />
                  <EditProductButton>edit</EditProductButton>
                </EditProductDiv>
              )}
              <hr />
            </ProductsInfoDiv>
          ))}
      </ProductsDiv>
    </>
  );
});
