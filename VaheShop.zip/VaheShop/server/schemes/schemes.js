const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const BlogSchema = new Schema({
  name: { type: String, trim: true, required: true },
  lastName: { type: String, trim: true, required: true },
  email: { type: String, trim: true, required: true, unique: true },
  password: { type: String, trim: true, minlength: 8, required: true },
  phone: { type: Number, trim: true },
  city: { type: String, trim: true },
  region: { type: String, trim: true },
  address: { type: String, trim: true },
  creaatedAt: { type: Date, default: Date.now },
  confirmed: { type: Boolean, default: false },
  login: { type: Boolean, default: false },
  resetCode: { type: String },
  resetCodeExpiration: { type: Date },
  basket: [],
  history: [],
  buyHistory: [],
});

const AdminSchema = new Schema({
  name: { type: String, trim: true, required: true, unique: true },
  password: { type: String, trim: true, minlength: 8, required: true },
  login: { type: Boolean, trim: true, required: true, default: false },
  createdAt: { type: Date, default: Date.now },
});

const ReviewsSchema = new Schema({
  name: { type: String, required: true, trim: true ,unique: false },
  lastName: { type: String, required: true, trim: true ,unique: false },
  position: { type: String, required: true, trim: true ,unique: false },
  stars: { type: Number, required: true, trim: true ,unique: false },
  confirmed: { type: Boolean, default: false ,unique: false },
  disc: { type: String, required: true, trim: true ,unique: false },
  id: {},
  createdAt: { type: Date, default: Date.now },
});


const AllProducts = new Schema({
  titleRU: { type: String, required: true, trim: true },
  titleAM: { type: String, required: true, trim: true },
  titleEN: { type: String, required: true, trim: true },
  img: { type: String, required: true, trim: true },
  price: { type: Number, required: true, trim: true },
  descriptionRU: { type: String, required: true, trim: true },
  descriptionEN: { type: String, required: true, trim: true },
  descriptionAM: { type: String, required: true, trim: true },
  type: { type: String, required: true, trim: true },
  inStock: { type: Boolean, required: true, default: false },
  basketCount: { type: Number, default: 1 },
  createdAt: { type: Date, default: Date.now },
});

const AdminModel = model("adminpanel", AdminSchema)
const UsersModel = model("users", BlogSchema);
const ReviewsModel = model('rewievs', ReviewsSchema)
const AllProductsModel = model('products', AllProducts)
module.exports.BlogModel = UsersModel;
module.exports.AdminModel = AdminModel;
module.exports.ReviewsModel = ReviewsModel;
module.exports.AllProductsModel = AllProductsModel



