require("dotenv").config();
const path = require("path");
const fs = require("fs");
const mongoose = require("mongoose");
const url = process.env.MONGOOSE_URL;
const jwt = require("jsonwebtoken");
const {
  BlogModel,
  AdminModel,
  ReviewsModel,
  AllProductsModel,
} = require("./schemes/schemes");
const bcrypt = require("bcrypt");
const { verifyToken } = require("./middleware/auth");
const cors = require("cors");
const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const stripe = require("stripe")(
  "sk_test_51OpVS6Hm0nYzXqH8J0ZKNXKj5KOqHMn5QVn5ME1w6lUZivKr4nZqblQ8VXEX5onyBH33EK9fG9Nyw7B0S2IrLeXd00cwwQXsb2"
);
const nodemeiler = require("nodemailer");
app.use(bodyParser.json());
const fileUpload = require("express-fileupload");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.use("/uploads", express.static("uploads"));
app.use(cors());
app.use(fileUpload());
const crypto = require("crypto");
mongoose.connect(url);

const db = mongoose.connection;

db.on("error", () => {
  console.log("MongoDB connection error");
});
db.once("open", () => {
  console.log("connected to MongoDB");
});

app.post("/create-payment-intent", async (req, res) => {
  const { email, price } = req.body;

  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: price,
      currency: "usd",
      description: "Payment for items",
      receipt_email: email,
    });

    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    console.error("Error creating payment intent:", error);
    res.status(500).json({ error: "Failed to create payment intent" });
  }
});

const transporter = nodemeiler.createTransport({
  host: "smtp.gmail.email",
  secure: false,
  service: "gmail",
  auth: {
    user: "vaheshop363@gmail.com",
    pass: "bamf uaaj askt mwiy",
  },
});

const generateConfirmationToken = (userID) => {
  return jwt.sign({ userId: userID }, "your-secret-key", { expiresIn: "1h" });
};

app.post("/register", async (req, res) => {
  try {
    const { name, lastName, email, password } = req.body;
    if (!name || !lastName || !email || !password) {
      return res.status(400).json({ error: "require failed" });
    }
    const users = await BlogModel.find({});
    const existingUser = users.find((e) => e.email === email);
    if (existingUser) {
      return res.status(401).json({ error: "email already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new BlogModel({
      name,
      lastName,
      email,
      password: hashedPassword,
    });
    await newUser.save();

    const confirmationToken = generateConfirmationToken(newUser._id);
    const mailOptions = {
      from: "vaheshop363@gmail.com",
      to: email,
      subject: "Registration Confirmation",
      html: `Hello ${name} ${lastName} \n \n Thank you for registering! \n <a href="http://localhost:3002/confirm?token=${confirmationToken}">sxmiii</a>`,
    };
    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ error: "Internal server error" });
      }
    });

    res.redirect(`/profile?token=${confirmationToken}`);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "internal error" });
  }
});

app.get("/confirm", async (req, res) => {
  try {
    const { token } = req.query;
    if (!token) {
      return res.status(400).json({ error: "Missing confirmation token" });
    }
    const decodedToken = jwt.verify(token, "your-secret-key");
    const user = await BlogModel.findById(decodedToken.userId);
    if (user) {
      user.confirmed = true;
      await user.save();
    }
    res.redirect(`http://localhost:3000/register/confirm/succes`);
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/profile", verifyToken, async (req, res) => {
  try {
    const user = await BlogModel.findById(req.userId);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const token = req.query.token || req.headers["x-access-token"];
    res.json({
      user: user,
      token: token,
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Missing email or password" });
    }
    const user = await BlogModel.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: "invalid email or password" });
    }
    if (!user.confirmed) {
      return res.status(402).json({ error: "no confirmed email" });
    }
    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ error: "Invalid or password" });
    }
    const token = jwt.sign({ userId: user._id }, "your-secret-key", {
      expiresIn: "1h",
    });
    user.login = true;
    user.save();
    res.status(200).redirect(`/profile?token=${token}`);
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "internal server error" });
  }
});

app.post("/admin/register", async (req, res) => {
  try {
    const { name, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const admin = await new AdminModel({ name, password: hashedPassword });
    admin.save();
    jwt.sign({ userId: admin._id }, "your-secret-key", {
      expiresIn: "1h",
    });

    res.send("admin is here");
  } catch (err) {
    console.log(err);
    res.send("error");
  }
});

app.get("/admin", verifyToken, async (req, res) => {
  try {
    const user = await AdminModel.findById(req.userId);
    if (!user) {
      return res.status(404).json({ error: "user not found" });
    }
    const token = req.query.token || req.headers["x-access-token"];
    res.json({
      login: user.login,
      name: user.name,
    });
  } catch (err) {
    console.log(err);
  }
});

app.post("/admin/login", async (req, res) => {
  try {
    const { name, password } = req.body;

    if (!name || !password) {
      return res.status(400).json({ error: "Missing email or password" });
    }
    const user = await AdminModel.findOne({ name });
    if (!user) {
      return res.status(401).json({ error: "invalid email or password" });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ error: "Invalid or password" });
    }
    const token = jwt.sign({ userId: user._id }, "your-secret-key", {
      expiresIn: "1h",
    });
    user.login = true;
    await user.save();
    res.redirect(`/admin?token=${token}`);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "internal server error" });
  }
});

app.post("/rewievs", async (req, res) => {
  try {
    console.log(req.body);
    const { name, lastName, position, stars, disc, id } = req.body;
    if (!disc) {
      return res.status(400).json({ error: "Missing text" });
    }

    const rewiev = new ReviewsModel({
      name,
      lastName,
      position,
      stars,
      disc,
      id,
    });

    await rewiev.save();

    res.status(201).json({ message: "Review added successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/rewievs", async (req, res) => {
  try {
    const allReviews = await ReviewsModel.find({ confirmed: true })
      .sort({ _id: -1 })
      .limit(6);
    res.status(200).json(allReviews);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/products", async (req, res) => {
  try {
    const {
      titleRU,
      titleEN,
      titleAM,
      price,
      descriptionRU,
      descriptionEN,
      descriptionAM,
      inStock,
      type,
    } = req.body;
    const img = req.files.img;
    const imgFileName = `${Date.now()}_${img.name}`;

    img.mv(`./uploads/${imgFileName}`, async (err) => {
      if (err) {
        console.error("Error saving file:", err);

        return res.status(500).json({ error: "Internal Server Error" });
      }

      const newProduct = new AllProductsModel({
        titleRU,
        titleEN,
        titleAM,
        price,
        descriptionRU,
        descriptionEN,
        descriptionAM,
        img: imgFileName,
        type,
        inStock,
      });

      await newProduct.save();

      res.status(200).json({ message: "Product added successfully" });
    });
  } catch (err) {
    console.error("Error adding product:", err.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.get("/products", async (req, res) => {
  try {
    const allProducts = await AllProductsModel.find({})
      .sort({ createdAt: -1 })
      .limit(10);
    res.status(201).json(allProducts);
  } catch (err) {
    console.log(err);
  }
});
app.get("/productsfilter", async (req, res) => {
  try {
    const allProducts = await AllProductsModel.find({});
    res.status(201).json(allProducts);
  } catch (err) {
    console.log(err);
  }
});

app.post("/products2", async (req, res) => {
  try {
    const num = req.body.number;
    const allProducts = await AllProductsModel.find()
      .skip((num - 1) * 10)
      .limit(10);
    res.status(200).json(allProducts);
  } catch (err) {
    console.log(err);
  }
});

app.get("/rewievsAll", async (req, res) => {
  try {
    const allReviews = await ReviewsModel.find({});
    res.status(200).json(allReviews);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.patch("/updateReview/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { confirmed } = req.body;

    if (!id || confirmed === undefined) {
      return res.status(400).json({ error: "Некорректный запрос" });
    }

    const updatedReview = await ReviewsModel.findByIdAndUpdate(
      id,
      { confirmed },
      { new: true }
    );

    if (!updatedReview) {
      return res.status(404).json({ error: "Обзор не найден" });
    }

    res.json(updatedReview);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Внутренняя ошибка сервера" });
  }
});

app.delete("/deleteReview/:id", async (req, res) => {
  try {
    const reviewId = req.params.id;
    const result = await ReviewsModel.findByIdAndDelete(reviewId);

    if (result) {
      res.status(200).json({ message: "Обзор успешно удален" });
    } else {
      res.status(404).json({ message: "Обзор не найден" });
    }
  } catch (error) {
    res.status(500).json({ message: "Ошибка сервера" });
  }
});

app.get("/shop/products/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const product = await AllProductsModel.findById(id);
    res.status(200).json(product);
  } catch (err) {
    console.log(err);
  }
});

app.delete("/product/:id", async (req, res) => {
  try {
    const prodId = req.params.id;
    const result = await AllProductsModel.findByIdAndDelete(prodId);

    if (result) {
      res.status(200).json({ message: "Обзор успешно удален" });
    } else {
      res.status(404).json({ message: "Обзор не найден" });
    }
  } catch (error) {
    res.status(500).json({ message: "Ошибка сервера" });
  }
});

app.put("/product/:id", async (req, res) => {
  try {
    const existingProduct = await AllProductsModel.findById(req.params.id);
    const previousImgFileName = existingProduct.img;

    if (req.files && req.files.img) {
      const img = req.files.img;
      const imgFileName = `${Date.now()}_${img.name}`;

      if (previousImgFileName) {
        const previousImgPath = `./uploads/${previousImgFileName}`;
        fs.unlinkSync(previousImgPath);
      }

      img.mv(`./uploads/${imgFileName}`, async (err) => {
        if (err) {
          console.error("Error saving file:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
        const updatedProduct = await AllProductsModel.findByIdAndUpdate(
          req.params.id,
          { ...req.body, img: imgFileName, inStock: req.body.inStock },
          { new: true }
        );

        res.json(updatedProduct);
      });
    } else {
      const updatedProduct = await AllProductsModel.findByIdAndUpdate(
        req.params.id,
        { ...req.body, inStock: req.body.inStock },
        { new: true }
      );

      res.json(updatedProduct);
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.post("/logout", verifyToken, async (req, res) => {
  try {
    const user = await BlogModel.findById(req.userId);
    user.login = false;
    user.save();
    res.status(200).json(user);
  } catch (err) {
    console.log(err);
  }
});

app.get("/users", async (req, res) => {
  try {
    const users = await BlogModel.find({});
    res.status(200).json(users);
  } catch (err) {
    console.log(err);
  }
});

app.delete("/users/:id", async (req, res) => {
  try {
    const prodId = req.params.id;
    const result = await BlogModel.findByIdAndDelete(prodId);

    if (result) {
      res.status(200).json({ message: "Обзор успешно удален" });
    } else {
      res.status(404).json({ message: "Обзор не найден" });
    }
  } catch (error) {
    res.status(500).json({ message: "Ошибка сервера" });
  }
});
app.put("/users/:id", async (req, res) => {
  try {
    const updatedProduct = await BlogModel.findByIdAndUpdate(
      req.params.id,
      req.body
    );
    res.status(200).json(updatedProduct);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.post("/admin/adduser", async (req, res) => {
  try {
    const { name, lastName, email, password, confirmed } = req.body;

    if (!name || !lastName || !email || !password) {
      return res.status(400).json({ error: "Required fields are missing" });
    }

    const users = await BlogModel.find({});
    const existingUser = users.find((e) => e.email === email);

    if (existingUser) {
      return res.status(401).json({ error: "Email already exists" });
    }
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new BlogModel({
      name,
      lastName,
      email,
      password: hashedPassword,
      confirmed,
    });

    await newUser.save();

    res.status(201).json({ message: "User created successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/users/basket/:user", async (req, res) => {
  try {
    const id = req.params.user;
    const user = await BlogModel.findById(id);

    if (!user) {
      return res.status(404).json({ error: "Пользователь не найден" });
    }

    const productId = req.body.number;
    const product = await AllProductsModel.findById(productId);

    if (!product) {
      return res.status(404).json({ error: "Продукт не найден" });
    }

    const isProductInBasket = user.basket.some((item) =>
      item._id.equals(product._id)
    );
    if (isProductInBasket) {
      return res.status(400).json({ error: "Продукт уже добавлен в корзину" });
    }

    const maxHistoryLength = 10;
    if (user.history.length > maxHistoryLength) {
      user.history.shift();
    }
    user.basket.push(product);
    await user.save();

    res.json({
      id: productId,
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Внутренняя ошибка сервера" });
  }
});

app.get("/basket", verifyToken, async (req, res) => {
  try {
    const user = await BlogModel.findById(req.userId);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ user: user });
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.put("/basket/price/:id", async (req, res) => {
  try {
    const userId = req.body.user;
    const type = req.body.type;
    const objectIdToFind = req.params.id;

    const user = await BlogModel.findOne({
      _id: userId,
      basket: { $elemMatch: { _id: objectIdToFind } },
    }).exec();
    if (user) {
      const foundObject = user.basket.find((obj) =>
        obj._id.equals(objectIdToFind)
      );
      let num = foundObject.basketCount;
      if (type == "minus") {
        foundObject.basketCount = num - 1;
      } else {
        foundObject.basketCount = num + 1;
      }

      user.markModified("basket");
      await user.save();

      res.status(200).json(foundObject);
    } else {
      console.log("Пользователь не найден");
      res.status(404).json({ error: "Пользователь не найден" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Внутренняя ошибка сервера" });
  }
});

const ObjectId = mongoose.Types.ObjectId;

app.delete("/basket/delete/:id", async (req, res) => {
  try {
    const userId = req.body.num;
    const productIdToRemove = req.params.id;

    const result = await BlogModel.updateOne(
      { _id: userId },
      { $pull: { basket: { _id: new ObjectId(productIdToRemove) } } }
    );

    if (result.nModified > 0) {
      res.json({ success: true, message: "Продукт успешно удален" });
    } else {
      res.json({ success: false, message: "Продукт не был удален" });
    }
  } catch (err) {
    console.log("Ошибка при удалении продукта:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/users/history/:user", async (req, res) => {
  try {
    const id = req.params.user;
    const user = await BlogModel.findById(id);
    if (!user) {
      return res.status(404).json({ error: "Пользователь не найден" });
    }
    const productId = req.body.number;
    const product = await AllProductsModel.findById(productId);

    if (!product) {
      return res.status(404).json({ error: "Продукт не найден" });
    }
    const user1 = await user.history[user.history.length - 1]?._id;
    const user2 = product._id;

    if (user1?.toString() == user2?.toString()) {
      return res.status(404).json({ error: "Продукт уже сушествует" });
    }
    user.history.push(product);

    const maxHistoryLength = 10;
    if (user.history.length > maxHistoryLength) {
      user.history.shift();
    }

    await user.save();

    res.json({
      id: productId,
    });
  } catch (err) {
    res.status(500).json({ error: "Внутренняя ошибка сервера" });
  }
});

app.get("/history", verifyToken, async (req, res) => {
  try {
    const user = await BlogModel.findById(req.userId);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const productIds = user.history;
    res.json({ products: productIds });
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/users/buy/history/:user", async (req, res) => {
  try {
    const id = req.params.user;
    const user = await BlogModel.findById(id);

    if (!user) {
      return res.status(404).json({ error: "Пользователь не найден" });
    }

    const productId = req.body;
    const products = await AllProductsModel.find({ _id: { $in: productId } });
    products.forEach((e, i) => {
      user.buyHistory.push(e);
    });
    if (products.length === 0) {
      res.status(400).json({ succes: "add items" });
    }
    console.log(products);
    await user.save();

    res.status(200).json({ succes: "succes" });
  } catch (err) {
    res.status(500).json({ error: "Внутренняя ошибка сервера" });
  }
});

app.get("/buyhistory", verifyToken, async (req, res) => {
  try {
    const user = await BlogModel.findById(req.userId);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const product = user.buyHistory;
    res.json({ products: product });
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.put("/user/change/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const data = await req.body;
    if (!data) {
      return res.json({ error: "data not found" });
    }
    const user = await BlogModel.findByIdAndUpdate(id, data);
    res.status(200).json("succes");
  } catch (err) {
    console.log(err);
  }
});

app.get("/user/review/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!id) {
      return res.json("id not found");
    }
    const rev = await ReviewsModel.find({ id: id });
    res.status(200).json({ rev: rev });
  } catch (err) {
    console.log(err);
  }
});

app.post("/profile/changepassword", async (req, res) => {
  try {
    const { password, newPassword } = req.body.data;
    const { id } = req.body;
    const user = await BlogModel.findById(id);
    if (!user || !user.login) {
      return res.status(404).json({ error: "user not found" });
    }
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ error: "password invalid" });
    }
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await BlogModel.findByIdAndUpdate(id, { password: hashedPassword });
    res.status(200).json({ succes: "succes" });
  } catch (err) {
    console.log(err);
  }
});

app.post("/forgot-password", async (req, res) => {
  const { email } = req.body;

  try {
    const user = await BlogModel.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: "Пользователь не найден" });
    }

    const resetCode = crypto.randomBytes(3).toString("hex").toUpperCase();
    const resetCodeExpiration = new Date(Date.now() + 15 * 60 * 1000);

    user.resetCode = resetCode;
    user.resetCodeExpiration = resetCodeExpiration;

    await user.save();

    const mailOptions = {
      from: "vaheshop363@gmail.com",
      to: email,
      subject: "Код восстановления пароля",
      text: `Ваш код восстановления пароля: ${resetCode}`,
    };

    await transporter.sendMail(mailOptions);

    res
      .status(200)
      .json({ message: "Код восстановления отправлен на вашу почту" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Произошла ошибка" });
  }
});

app.post("/reset-password", async (req, res) => {
  const { email, code, password } = req.body;

  try {
    const user = await BlogModel.findOne({
      email,
      resetCode: code,
      resetCodeExpiration: { $gt: new Date() },
    });

    if (!user) {
      return res
        .status(400)
        .json({ message: "Неправильный код восстановления или код истек" });
    }
    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);

      user.password = hashedPassword;
      user.resetCode = null;
      user.resetCodeExpiration = null;

      await user.save();
    }

    res.status(200).json({ message: "Пароль успешно восстановлен" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Произошла ошибка" });
  }
});

app.listen(process.env.APP_LISTEN);
