﻿    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Hosting;
    using ClassLibrary1.Data;
    using MongoDB.Driver;
    using MongoDB.Bson;

    namespace WebApplication2.Controllers
    {
        [Route("api/product")]
        [ApiController]
        public class ValuesController : ControllerBase
        {
            private readonly MongoDbContext _context;
            private readonly IWebHostEnvironment _environment;

            public ValuesController(MongoDbContext context, IWebHostEnvironment environment)
            {
                _context = context;
                _environment = environment;
            }

            [HttpPost]
            public async Task<IActionResult> PostProduct([FromForm] ProductViewModel model)
            {
                try
                {
                    Console.Write("hhhh");
                    // Check if an image is uploaded
                    if (model.Image != null && model.Image.Length > 0)
                    {
                        // Generate a unique filename for the image
                        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(model.Image.FileName);

                        // Combine the filename with the "uploads" directory path
                        var filePath = Path.Combine("uploads", fileName);

                        // Save the image to the specified directory
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await model.Image.CopyToAsync(stream);
                        }

                        // Set the image filename in the product model
                        model.ImageFileName = fileName;
                    }

                    var newProduct = new ProductViewModel
                    {
                        TitleRU = model.TitleRU,
                        TitleEN = model.TitleEN,
                        TitleAM = model.TitleAM,
                        Price = model.Price,
                        DescriptionRU = model.DescriptionRU,
                        DescriptionEN = model.DescriptionEN,
                        DescriptionAM = model.DescriptionAM,
                        Type = model.Type,
                        InStock = model.InStock,
                        ImageFileName = model.ImageFileName  // Assuming you have added a property named ImageFileName in your ProductViewModel
                    };

                    // Insert the new product document into the MongoDB collection
                    await _context.AllProducts.InsertOneAsync(newProduct);

                    return Ok(new { message = "Product added successfully" });
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error adding product: {ex.Message}");
                    return StatusCode(StatusCodes.Status500InternalServerError, new { error = "Internal Server Error" });
                }
            }

            [HttpDelete("{fileName}")]
            public async Task<IActionResult> DeleteProduct(string fileName)
            {
                try
                {
                    // Trim the input fileName
                    fileName = fileName.Trim();

                    // Find the product by ImageFileName
                    var filter = Builders<ProductViewModel>.Filter.Eq("ImageFileName", fileName);
                    var productToDelete = await _context.AllProducts.FindOneAndDeleteAsync(filter);

                    if (productToDelete == null)
                    {
                        Console.WriteLine($"Product not found for ImageFileName: {fileName}");
                        return NotFound(new { message = "Product not found" });
                    }

                    return Ok(new { message = "Product deleted successfully" });
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error deleting product: {ex.Message}");
                    return StatusCode(StatusCodes.Status500InternalServerError, new { error = "Internal Server Error" });
                }
            }



        [HttpPut("{imageFileName}")]

        public async Task<IActionResult> UpdateProduct(string imageFileName, [FromBody] ProductViewModel updatedProduct)
        {
            Console.WriteLine("fff");

            try
            {
                Console.WriteLine("fff");
                // Find the product by imageFileName
                var filter = Builders<ProductViewModel>.Filter.Eq(p => p.ImageFileName, imageFileName);
                var existingProduct = await _context.AllProducts.Find(filter).FirstOrDefaultAsync();

                if (existingProduct == null)
                {
                    return NotFound(new { message = "Product not found for imageFileName: " + imageFileName });
                }

                // Update the properties of the existing product
                existingProduct.TitleRU = updatedProduct.TitleRU;
                existingProduct.TitleEN = updatedProduct.TitleEN;
                existingProduct.TitleAM = updatedProduct.TitleAM;
                existingProduct.Price = updatedProduct.Price;
                existingProduct.DescriptionRU = updatedProduct.DescriptionRU;
                existingProduct.DescriptionEN = updatedProduct.DescriptionEN;
                existingProduct.DescriptionAM = updatedProduct.DescriptionAM;

                // Save the changes to the database
                await _context.AllProducts.ReplaceOneAsync(filter, existingProduct);

                return Ok(new { message = "Product updated successfully" });
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"Error updating product: {ex.Message}");

                // Return a meaningful error response to the client
                return StatusCode(StatusCodes.Status500InternalServerError, new { error = "Failed to update product" });
            }
        }








        [HttpGet]
            public async Task<IActionResult> GetAllProducts()
            {
                try
                {
                    var products = await _context.AllProducts.Find(_ => true).ToListAsync();
                    return Ok(products);
                }
                catch (Exception ex)
                {
                    // Log the exception details
                    Console.WriteLine($"Error retrieving products: {ex.Message}");

                    Console.WriteLine($"Stack trace: {ex.StackTrace}");

                    return StatusCode(StatusCodes.Status500InternalServerError, new { error = "Internal Server Error" });
                }
            }



        [HttpGet("{fileName}")]
        public async Task<IActionResult> GetProduct(string fileName)
        {
            try
            {
                // No need to trim the filename

                var filter = Builders<ProductViewModel>.Filter.Eq("ImageFileName", fileName);
                var product = await _context.AllProducts.Find(filter).FirstOrDefaultAsync();

                if (product == null)
                {
                    return NotFound(new { message = "Product not found" });
                }

                return Ok(product);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving product: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, new { error = "Internal Server Error" });
            }
        }


    }
}
